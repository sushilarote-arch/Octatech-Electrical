# Octa Tech Electricals — Design System

## Overview
**Octa Tech Electricals** is one of India's fastest-growing distributors of industrial electrical components, headquartered in Nashik, Maharashtra. The company distributes 150+ products across 12 categories — Relays, Cable Glands, Control Panels, Conduits, Heavy Duty Connectors, Junction Boxes, Industrial Plugs & Sockets, Cable Drag Chains, Cable Ties, and SS/MS Outlet Bodies — serving Automotive & EV, Industrial & Energy, Railway & Mass Transport, and Infrastructure sectors.

**Website:** https://www.octatechelectricals.com/  
**Reference design:** https://relats.com/products/ (industry benchmark)  
**Certifications:** UL, CSA, RoHS, VDE, TÜV, ATEX, CE

---

## File Structure

```
README.md              ← This file
SKILL.md               ← Agent skill definition
colors_and_type.css    ← All CSS design tokens
assets/
  logo.svg             ← Primary logo mark
  logo-full.svg        ← Full wordmark logo
  logo-white.svg       ← Reversed logo
preview/               ← Design System tab cards
  colors-brand.html
  colors-navy.html
  colors-semantic.html
  colors-surfaces.html
  type-display.html
  type-body.html
  type-scale.html
  type-labels.html
  spacing-scale.html
  spacing-radius.html
  elevation-shadows.html
  comp-buttons.html
  comp-inputs.html
  comp-badges.html
  comp-cards.html
  comp-nav.html
  comp-product-card.html
  comp-filters.html
  comp-modals.html
  brand-logo.html
  brand-icons.html
  brand-motion.html
ui_kits/
  website/
    index.html         ← Interactive website prototype
```

---

## Content Fundamentals

### Tone & Voice
- **Professional and technical** — the audience is B2B industrial engineers and procurement managers
- **Direct and factual** — no marketing fluff; leads with specifications, certifications, applications
- **Confident, not boastful** — "India's leading distributor" backed by product breadth and certifications
- **Sentence case everywhere** — headlines, CTAs, labels all use sentence case (e.g., "Browse products", not "Browse Products")
- **Third person for company** — "Octa Tech Electricals is…" not "We are…" in formal contexts; "Our team" in conversational contexts
- **Numbers & specs always precise** — e.g., "-40°C to +120°C", "IP68 / IP69K", "16A / 250VAC"
- **No emoji** in UI — professional industrial context; emoji only in internal/dev tooling
- **Certification codes are ALL CAPS** — UL, CE, ATEX, RoHS, TÜV, VDE, CSA
- **Product names use title case** — "Brass Double Compression Gland", "Solid State Relay Module"
- **Overlines / section labels are ALL CAPS with letter-spacing** — "BY INDUSTRY", "FEATURED", "SOLUTIONS"

### Example Copy Patterns
- Hero: "Industrial Electrical Components for Every Application"
- CTA primary: "Browse catalog →" / "Request information"
- CTA secondary: "Get a quote" / "View all products →"
- PRO gating: "Technical Data Sheet · PRO" with lock icon
- Empty state: "No products match your filters. Clear filters"
- Success: "Request sent! Our team will get back to you within 24 hours."

---

## Visual Foundations

### Color System
- **Primary accent:** Orange `#e85d26` — used for CTAs, highlights, active states, underlines
- **Orange gradient:** `linear-gradient(135deg, #e85d26, #ff7a45)` — buttons, badges, hero elements
- **Deep navy (bg-1):** `#08111f` — primary page background
- **Navy (bg-2):** `#0d1929` — card backgrounds, elevated surfaces
- **Navy mid (bg-3):** `#142240` — hover states on cards, sidebars
- **Navy accent (bg-4):** `#1e2d4a` — borders, nav, pill backgrounds
- **Navy light (bg-5):** `#2a3f6a` — subtle borders, dividers
- **White:** `#ffffff` — primary text on dark
- **Text secondary:** `rgba(255,255,255,0.65)` — body text on dark
- **Text tertiary:** `rgba(255,255,255,0.35)` — labels, captions, placeholders
- **Text muted:** `rgba(255,255,255,0.15)` — disabled, very subtle text
- **Success:** `#16a34a` / `rgba(22,163,74,0.12)` — success states, "new" badges
- **Warning:** `#d97706` / `rgba(217,119,6,0.12)` — warning states
- **Error:** `#dc2626` / `rgba(220,38,38,0.12)` — error states

### Typography
- **Display / Headings:** Space Grotesk — weight 700–800, tight letter-spacing (-0.3px to -1px), white or gradient
- **Body / UI:** DM Sans — weight 300–600, normal letter-spacing, comfortable line-height 1.6–1.75
- **Monospace (specs/values):** DM Mono (fallback: `monospace`) — for spec values, code
- **Overlines:** DM Sans 11–12px, weight 600, ALL CAPS, letter-spacing 2–3px, orange `#e85d26`
- **Scale:** 10 / 11 / 12 / 13 / 14 / 15 / 16 / 18 / 20 / 22 / 24 / 28 / 32 / 36 / 44 / 56 / 72px

### Spacing
- **Base unit:** 4px
- **Scale:** 4 / 8 / 12 / 16 / 20 / 24 / 28 / 32 / 40 / 48 / 56 / 64 / 80 / 96 / 120px
- **Section padding:** 80px vertical on desktop, 48px on tablet, 32px on mobile
- **Content max-width:** 1200px centered with 48px side padding (24px mobile)
- **Card padding:** 24–32px on large cards, 14–16px on small cards
- **Grid gap:** 14–20px for product grids, 24–32px for section grids

### Border Radius
- **XS:** 4px — tags, small chips, cert badges
- **SM:** 6px — buttons (compact), table cells
- **MD:** 8px — buttons (default), inputs, small cards
- **LG:** 10–12px — cards, modals, dropdowns
- **XL:** 16px — large cards, image containers, modals
- **2XL:** 24px — hero containers (rare)
- **Full:** 9999px — pill chips, avatar

### Shadows / Elevation
- **Level 0:** No shadow — flat elements, backgrounds
- **Level 1:** `0 4px 16px rgba(0,0,0,0.2)` — default card resting state
- **Level 2:** `0 8px 32px rgba(0,0,0,0.35)` — card hover / dropdown
- **Level 3:** `0 16px 48px rgba(0,0,0,0.45)` — modals, tooltips
- **Level 4:** `0 40px 100px rgba(0,0,0,0.6)` — full-screen overlays
- **Orange glow:** `0 4px 20px rgba(232,93,38,0.3)` — primary button resting
- **Orange glow lg:** `0 8px 32px rgba(232,93,38,0.45)` — primary button hover

### Backgrounds & Textures
- **Grid overlay:** `linear-gradient(rgba(232,93,38,0.04) 1px, transparent 1px)` at 60×60px — used in hero sections for depth
- **Radial gradient:** `radial-gradient(circle, rgba(232,93,38,0.12) 0%, transparent 70%)` — decorative glowing orb in heroes
- **Surface gradient (hero):** `linear-gradient(180deg, #0d1929 0%, #08111f 100%)` — section transitions
- **Bottom fade:** `linear-gradient(transparent, #08111f)` — image overlays
- **No gradients on buttons except primary** — secondary/ghost buttons use flat colors

### Animations & Motion
- **Scroll reveal:** `opacity 0→1, translateY(32px→0), 0.7s ease` — triggered via IntersectionObserver
- **Parallax:** `translateY(scrollY × 0.2–0.3)` — hero backgrounds, floating elements
- **Hover lift:** `translateY(-4px), 0.25s ease` — product cards, category cards
- **Hover underline:** `border-bottom color change, 0.2s` — links, nav items
- **Count-up:** Numbers animate from 0 to target over ~1.2s on scroll entry
- **Modal appear:** `fadeIn 0.15s + slideUp 0.2s ease` — all modals
- **Dropdown:** `fadeDown 0.15s ease` — search, menus
- **No bounce, no spring** — industrial context favors precise, restrained motion
- **No transition on color changes > 0.3s** — stays snappy

### Hover States
- **Card:** background lightens one step (bg-2→bg-3), border color changes to orange tint, `translateY(-4px)`
- **Button primary:** opacity 0.9, `translateY(-2px)`, shadow increases
- **Button secondary/ghost:** background increases opacity
- **Nav links:** color changes to white, orange bottom border slides in
- **Icons/badges:** border-color to `rgba(232,93,38,0.35)`
- **Table rows:** background `rgba(255,255,255,0.03)`

### Borders
- **Default card border:** `1px solid rgba(255,255,255,0.06)`
- **Card hover border:** `1px solid rgba(232,93,38,0.25)`
- **Input border:** `1px solid rgba(255,255,255,0.09)` → `rgba(232,93,38,0.5)` on focus
- **Nav border (scrolled):** `1px solid rgba(255,255,255,0.07)`
- **Divider:** `1px solid rgba(255,255,255,0.05)`
- **No solid borders on light surfaces** — always use opacity-based borders for layering

### Use of Transparency & Blur
- **Nav backdrop:** `backdrop-filter: blur(12px)` when scrolled — glassmorphism on nav only
- **Modals:** `backdrop-filter: blur(4px)` on overlay — keeps focus on modal
- **No blur on cards or content** — reserved for UI chrome only
- **Tinted overlays:** `rgba(0,0,0,0.75)` for modal backdrops

### Corner Imagery & Icons
- **No photography currently** — use icon emoji / geometric placeholder
- **Icons:** No external icon library; use emoji + simple SVG shapes
- **Product icons:** Category emoji (⚡🔌🖥️) as large display icons in product cards
- **Cert badges:** Pure text in bordered boxes — `UL CE ATEX RoHS TÜV VDE CSA`
- **No illustrations or decorative SVGs** — industrial, minimal

### Card Anatomy
- `background: #0d1929` (bg-2)
- `border: 1px solid rgba(255,255,255,0.06)`
- `border-radius: 12–16px`
- `box-shadow: 0 4px 16px rgba(0,0,0,0.2)`
- On hover: bg shifts to `#142240`, border → orange tint, `translateY(-4px)`, shadow increases
- Padding: 24px for content cards, 14–16px for compact cards
- Never use colored left-borders or gradient card headers

---

## Iconography

Octa Tech uses **no external icon library**. Icons are represented by:
1. **Category emoji** — used as large (24–48px) display icons in product grid, navigation pills (⚡🔌🖥️〰️🔗📦🔋⛓️🪢🔧)
2. **Unicode symbols** — `→` for directional CTAs, `×` for close/remove, `✓` for checkboxes, `🔒` for PRO-gated content, `🔍` for search, `📍✉️📞` for contact info
3. **Cert text badges** — certification marks rendered as bold text in bordered boxes
4. **No SVG icon sprites or icon fonts** — if integrating, recommend Phosphor Icons (thin/regular weight) for their industrial/technical aesthetic

**Substitution note:** If adopting an icon library, use **Phosphor Icons** (CDN: `https://unpkg.com/phosphor-icons`) — thin stroke weight matches the precise, technical feel of the brand.

---

## Component Principles

1. **Dark-first** — all components designed for dark navy backgrounds; light mode not in scope
2. **Information-dense** — B2B users need data, not decoration; spec tables preferred over cards where detail is needed
3. **Progressive disclosure** — tab systems, accordion filters, PRO gating manage complexity without clutter
4. **Accessible contrast** — all text meets WCAG AA on dark backgrounds (verified)
5. **Touch targets ≥ 44px** — all interactive elements meet mobile touch target requirements
6. **Consistent focus ring** — `outline: 2px solid #e85d26` on keyboard focus (not implemented yet — add in production)

---

*Last updated: April 2026 · Octa Tech Design Team*
