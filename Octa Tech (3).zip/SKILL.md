---
name: octatech-design
description: Use this skill to generate well-branded interfaces and assets for Octa Tech Electricals — India's leading industrial electrical components distributor. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick Reference

**Brand:** Octa Tech Electricals — industrial electrical components distributor, Nashik, India
**Tone:** Professional, technical, B2B. Direct and factual. No fluff.
**Dark-first:** All UI is designed for dark navy backgrounds.

### Key Colors
- Primary accent: `#e85d26` (orange)
- Gradient: `linear-gradient(135deg, #e85d26, #ff7a45)`
- Page bg: `#08111f`
- Card bg: `#0d1929`
- Card hover: `#142240`
- Nav/elevated: `#1e2d4a`

### Key Fonts
- Display/headings: **Space Grotesk** — weight 700–800
- Body/UI: **DM Sans** — weight 300–600
- Specs/mono: **DM Mono**
- Google Fonts import: `https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap`

### Key Tokens (copy from colors_and_type.css)
- See `colors_and_type.css` for full CSS custom properties
- Link with: `<link rel="stylesheet" href="colors_and_type.css">`

### Logo
- Use `assets/logo.svg` for icon mark
- Use `assets/logo-full.svg` for full wordmark
- Always on dark backgrounds — never on light

### Components available in prototype
- `proto/nav.jsx` — NavBar with search, mobile menu, scroll effect
- `proto/modals.jsx` — LoginModal, EnquiryModal, CompareModal
- `proto/homepage.jsx` — HomePage with parallax, scroll animations
- `proto/catalog.jsx` — CatalogPage with sidebar filters, search
- `proto/product-detail.jsx` — ProductDetailPage with tabs
- `proto/about-contact.jsx` — AboutPage, ContactPage
- `proto/data.js` — All product data (OctaData global)

### Design Principles
1. Dark navy backgrounds, orange accent only for CTAs and highlights
2. Cards: `bg #0d1929`, `border 1px solid rgba(255,255,255,0.06)`, `border-radius 12px`
3. Hover: bg → `#142240`, border → orange tint, `translateY(-4px)`
4. Overlines: ALL CAPS, `letter-spacing: 0.15em`, orange `#e85d26`
5. No emoji in UI (except category icons and contact info)
6. No colored left-border cards, no blue-purple gradients
7. Button primary: orange gradient + `box-shadow: 0 4px 20px rgba(232,93,38,0.3)`
8. Certifications: UL, CSA, RoHS, VDE, TÜV, ATEX, CE — always ALL CAPS
