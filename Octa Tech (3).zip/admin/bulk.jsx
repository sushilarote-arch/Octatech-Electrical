// admin/bulk.jsx — CSV/Excel import/export
const { useState, useRef } = React;

function BulkPage() {
  const { isMobile } = window.useBreakpoint();
  const [step, setStep] = useState('idle');
  const [file, setFile] = useState(null);
  const fileRef = useRef(null);

  const onFile = (f) => {
    setFile(f);
    setStep('parsing');
    setTimeout(() => setStep('preview'), 800);
  };

  const importNow = () => {
    setStep('parsing');
    setTimeout(() => setStep('done'), 1200);
  };

  return (
    <>
      <PageHeader
        title="Import / Export"
        subtitle="Bulk operations on products and data"
        actions={<Btn variant="secondary" icon="?" size="md">Template Guide</Btn>}
      />
      <div style={{ padding: isMobile ? '16px 16px 60px' : '24px 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', gap: 20, maxWidth: 1100 }}>
          {/* IMPORT */}
          <Card padding={24}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, background: 'rgba(232,93,38,0.1)', border: '1px solid rgba(232,93,38,0.25)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>📥</div>
              <div>
                <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 17, fontWeight: 700, color: 'white' }}>Import Products</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Upload CSV or Excel file</div>
              </div>
            </div>

            {step === 'idle' && (
              <>
                <div onClick={() => fileRef.current?.click()} style={{
                  border: '2px dashed rgba(232,93,38,0.25)', borderRadius: 12, padding: 32,
                  textAlign: 'center', cursor: 'pointer', background: 'rgba(232,93,38,0.04)', marginBottom: 14,
                }}>
                  <input ref={fileRef} type="file" accept=".csv,.xlsx,.xls" style={{ display: 'none' }} onChange={e => e.target.files[0] && onFile(e.target.files[0])} />
                  <div style={{ fontSize: 36, marginBottom: 10 }}>📊</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, color: 'white', marginBottom: 4 }}>Drop CSV / Excel here</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>or click to browse</div>
                </div>
                <div style={{ background: 'rgba(37,99,235,0.06)', border: '1px solid rgba(37,99,235,0.15)', borderRadius: 8, padding: 12, fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.6)', lineHeight: 1.5 }}>
                  <div style={{ fontWeight: 600, color: 'white', marginBottom: 4 }}>📋 File format</div>
                  Required columns: <code style={{ background: 'rgba(255,255,255,0.05)', padding: '1px 6px', borderRadius: 3 }}>name</code>, <code style={{ background: 'rgba(255,255,255,0.05)', padding: '1px 6px', borderRadius: 3 }}>category</code>, <code style={{ background: 'rgba(255,255,255,0.05)', padding: '1px 6px', borderRadius: 3 }}>description</code><br/>
                  Optional: <code style={{ background: 'rgba(255,255,255,0.05)', padding: '1px 6px', borderRadius: 3 }}>material, temperature, ipRating, certs, industry, tagline, featured</code>
                  <div style={{ marginTop: 8 }}>
                    <a href="#" style={{ color: '#e85d26', textDecoration: 'none' }}>↓ Download sample CSV template</a>
                  </div>
                </div>
              </>
            )}

            {step === 'parsing' && (
              <div style={{ padding: '32px 20px', textAlign: 'center' }}>
                <div style={{ width: 36, height: 36, border: '3px solid rgba(255,255,255,0.1)', borderTopColor: '#e85d26', borderRadius: '50%', margin: '0 auto 14px', animation: 'spin 0.7s linear infinite' }} />
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 14, color: 'white' }}>Parsing {file?.name}...</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>Validating rows and columns</div>
              </div>
            )}

            {step === 'preview' && (
              <>
                <div style={{ background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.2)', borderRadius: 8, padding: 14, marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: '#16a34a', fontWeight: 600, marginBottom: 2 }}>✓ Ready to import</div>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.55)' }}>{file?.name} · 47 new products · 3 updates · 0 errors</div>
                  </div>
                </div>
                <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: 8, padding: 14, marginBottom: 14, maxHeight: 200, overflowY: 'auto' }}>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.3)', marginBottom: 8, fontWeight: 600 }}>FIRST 5 ROWS PREVIEW</div>
                  {['New Brass Cable Gland M30', 'EMC Shielded Connector 16P', 'PV Junction Box 1500V DC', 'Heavy Duty Conduit 50mm', 'Solid State Relay 60A'].map((r, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0' }}>
                      <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', width: 24 }}>{i+1}</span>
                      <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{r}</span>
                      <Badge variant={i === 1 ? 'warning' : 'success'} size="sm" style={{ marginLeft: 'auto' }}>{i === 1 ? 'Update' : 'New'}</Badge>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <Btn variant="ghost" style={{ flex: 1 }} onClick={() => { setStep('idle'); setFile(null); }}>Cancel</Btn>
                  <Btn variant="primary" style={{ flex: 1 }} icon="✓" onClick={importNow}>Import 50 rows</Btn>
                </div>
              </>
            )}

            {step === 'done' && (
              <div style={{ padding: '32px 20px', textAlign: 'center' }}>
                <div style={{ fontSize: 48, marginBottom: 14 }}>✅</div>
                <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 18, fontWeight: 700, color: 'white', marginBottom: 6 }}>Import complete</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.5)', marginBottom: 18 }}>47 new products added, 3 existing updated</div>
                <Btn variant="secondary" onClick={() => { setStep('idle'); setFile(null); }}>Import another file</Btn>
              </div>
            )}
          </Card>

          {/* EXPORT */}
          <Card padding={24}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
              <div style={{ width: 44, height: 44, background: 'rgba(37,99,235,0.1)', border: '1px solid rgba(37,99,235,0.25)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>📤</div>
              <div>
                <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 17, fontWeight: 700, color: 'white' }}>Export Data</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Download products, enquiries, or users</div>
              </div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>What to export</label>
              <select style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '10px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
                <option>All products (22 rows)</option>
                <option>Products by category...</option>
                <option>Enquiries (10 rows)</option>
                <option>PRO Users (8 rows)</option>
                <option>Analytics report</option>
              </select>
            </div>

            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>Format</label>
              <div style={{ display: 'flex', gap: 6 }}>
                {['CSV', 'Excel (.xlsx)', 'JSON'].map((fmt, i) => (
                  <button key={fmt} style={{ flex: 1, padding: '8px', borderRadius: 7, background: i === 0 ? 'rgba(232,93,38,0.12)' : 'rgba(255,255,255,0.04)', border: i === 0 ? '1px solid rgba(232,93,38,0.35)' : '1px solid rgba(255,255,255,0.08)', color: i === 0 ? '#e85d26' : 'rgba(255,255,255,0.55)', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>{fmt}</button>
                ))}
              </div>
            </div>

            <div style={{ marginBottom: 18 }}>
              <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 8 }}>Include columns</label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {['Basic info', 'Specifications', 'Certifications', 'Images URLs', 'SEO fields', 'Analytics data'].map((col, i) => (
                  <label key={col} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked={i < 4} style={{ accentColor: '#e85d26' }} />
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{col}</span>
                  </label>
                ))}
              </div>
            </div>

            <Btn variant="primary" icon="↓" style={{ width: '100%', justifyContent: 'center' }}>Download Export</Btn>
          </Card>
        </div>

        {/* Recent exports */}
        <div style={{ marginTop: 28, maxWidth: 1100 }}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 12 }}>Recent Activity</div>
          <Card padding={0}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  {['Type', 'File', 'By', 'When', 'Status'].map(h => <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700 }}>{h.toUpperCase()}</th>)}
                </tr>
              </thead>
              <tbody>
                {[
                  ['Export', 'products-export-2026-05-14.csv', 'Aarav Sharma', '5m ago', 'success'],
                  ['Import', 'new-products-batch-3.xlsx', 'Priya Patel', '2h ago', 'success'],
                  ['Export', 'enquiries-may-2026.xlsx', 'Aarav Sharma', '1d ago', 'success'],
                  ['Import', 'cert-updates.csv', 'Rohan Mehta', '2d ago', 'warning'],
                ].map(([type, file, by, when, status], i) => (
                  <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                    <td style={{ padding: '12px 16px' }}><Badge variant={type === 'Import' ? 'info' : 'default'}>{type === 'Import' ? '📥' : '📤'} {type}</Badge></td>
                    <td style={{ padding: '12px 16px', fontFamily: 'DM Mono, monospace', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{file}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.55)' }}>{by}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{when}</td>
                    <td style={{ padding: '12px 16px' }}><Badge variant={status === 'success' ? 'success' : 'warning'}>{status === 'success' ? '✓ Success' : '⚠ Partial'}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { BulkPage });
