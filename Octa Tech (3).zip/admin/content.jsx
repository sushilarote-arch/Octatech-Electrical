// admin/content.jsx — Homepage + About content editors
const { useState } = React;

function HomepageEditor() {
  const { isMobile } = window.useBreakpoint();
  const [c, setC] = useState(window.AdminData.homepageContent);
  const upd = (k, v) => setC(prev => ({ ...prev, [k]: v }));
  const [saved, setSaved] = useState(false);

  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2500); };

  return (
    <>
      <PageHeader title="Homepage Content" subtitle="Edit hero text, statistics, and homepage sections" actions={
        <>
          {saved && <Badge variant="success">✓ Saved</Badge>}
          <Btn variant="ghost" icon="👁">Preview</Btn>
          <Btn variant="primary" icon="✓" onClick={save}>Save Changes</Btn>
        </>
      } />
      <div style={{ padding: isMobile ? '16px 16px 60px' : '24px 32px', maxWidth: 1000 }}>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1.2fr 1fr', gap: 20 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card padding={24}>
              <SectionTitle>Hero Section</SectionTitle>
              <Input label="Overline" placeholder="INDIA'S LEADING DISTRIBUTOR" value={c.heroOverline} onChange={e => upd('heroOverline', e.target.value)} helper="Small ALL-CAPS text above headline" />
              <Input label="Main Headline" placeholder="Industrial Electrical Components..." value={c.heroHeadline} onChange={e => upd('heroHeadline', e.target.value)} required />
              <Input label="Description" type="textarea" value={c.heroDescription} onChange={e => upd('heroDescription', e.target.value)} helper="Shown below headline. Keep concise." />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <Input label="Primary CTA" value={c.ctaPrimary} onChange={e => upd('ctaPrimary', e.target.value)} />
                <Input label="Secondary CTA" value={c.ctaSecondary} onChange={e => upd('ctaSecondary', e.target.value)} />
              </div>
            </Card>

            <Card padding={24}>
              <SectionTitle>Statistics Bar</SectionTitle>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {c.stats.map((s, i) => (
                  <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <input value={s.value} onChange={e => { const ns = [...c.stats]; ns[i] = { ...s, value: e.target.value }; upd('stats', ns); }} placeholder="Value" style={{ width: 100, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '8px 12px', color: '#e85d26', fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 800, outline: 'none' }} />
                    <input value={s.label} onChange={e => { const ns = [...c.stats]; ns[i] = { ...s, label: e.target.value }; upd('stats', ns); }} placeholder="Label" style={{ flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '8px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none' }} />
                    <button onClick={() => upd('stats', c.stats.filter((_, j) => j !== i))} style={{ width: 32, height: 32, background: 'rgba(220,38,38,0.06)', border: '1px solid rgba(220,38,38,0.15)', borderRadius: 7, cursor: 'pointer', color: '#dc2626', fontSize: 13 }}>🗑</button>
                  </div>
                ))}
                <button onClick={() => upd('stats', [...c.stats, { value: '0', label: 'New stat' }])} style={{ background: 'transparent', border: '1.5px dashed rgba(255,255,255,0.12)', borderRadius: 8, padding: 10, cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontFamily: 'DM Sans, sans-serif', fontSize: 12 }}>+ Add stat</button>
              </div>
            </Card>
          </div>

          {/* Live preview */}
          <div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>LIVE PREVIEW</div>
            <div style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 12, padding: 24, position: 'sticky', top: 80 }}>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: '#e85d26', letterSpacing: 2, marginBottom: 12, fontWeight: 600 }}>{c.heroOverline}</div>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 24, fontWeight: 800, color: 'white', lineHeight: 1.1, marginBottom: 10 }}>{c.heroHeadline}</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)', lineHeight: 1.6, marginBottom: 14 }}>{c.heroDescription}</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
                <div style={{ padding: '7px 14px', background: 'linear-gradient(135deg,#e85d26,#ff7a45)', borderRadius: 7, fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600, color: 'white' }}>{c.ctaPrimary} →</div>
                <div style={{ padding: '7px 14px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.7)' }}>{c.ctaSecondary}</div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                {c.stats.map((s, i) => (
                  <div key={i} style={{ textAlign: 'center' }}>
                    <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 800, color: '#e85d26' }}>{s.value}</div>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 9, color: 'rgba(255,255,255,0.4)', marginTop: 1 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function AboutEditor() {
  const { isMobile } = window.useBreakpoint();
  const [c, setC] = useState(window.AdminData.aboutContent);
  const upd = (k, v) => setC(prev => ({ ...prev, [k]: v }));
  const [saved, setSaved] = useState(false);
  const save = () => { setSaved(true); setTimeout(() => setSaved(false), 2500); };

  return (
    <>
      <PageHeader title="About Page Content" subtitle="Edit company story and values" actions={
        <>
          {saved && <Badge variant="success">✓ Saved</Badge>}
          <Btn variant="ghost" icon="👁">Preview</Btn>
          <Btn variant="primary" icon="✓" onClick={save}>Save Changes</Btn>
        </>
      } />
      <div style={{ padding: '24px 32px', maxWidth: 900 }}>
        <Card padding={24} style={{ marginBottom: 16 }}>
          <SectionTitle>Hero Section</SectionTitle>
          <Input label="Main Headline" value={c.heroHeadline} onChange={e => upd('heroHeadline', e.target.value)} required />
          <Input label="Short Description" type="textarea" value={c.heroDescription} onChange={e => upd('heroDescription', e.target.value)} />
        </Card>

        <Card padding={24} style={{ marginBottom: 16 }}>
          <SectionTitle>Full Story</SectionTitle>
          <Input label="Company Story" type="textarea" value={c.fullStory} onChange={e => upd('fullStory', e.target.value)} helper="Longer narrative section. Use multiple paragraphs separated by double-line breaks." />
        </Card>

        <Card padding={24}>
          <SectionTitle>Values / Principles</SectionTitle>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {c.values.map((v, i) => (
              <div key={i} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', borderRadius: 10, padding: 14, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <input value={v.icon} onChange={e => { const nv = [...c.values]; nv[i] = { ...v, icon: e.target.value }; upd('values', nv); }} style={{ width: 50, height: 50, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, color: 'white', fontSize: 22, textAlign: 'center', outline: 'none' }} />
                <div style={{ flex: 1 }}>
                  <input value={v.title} onChange={e => { const nv = [...c.values]; nv[i] = { ...v, title: e.target.value }; upd('values', nv); }} placeholder="Title" style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 7, padding: '8px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, outline: 'none', marginBottom: 6, boxSizing: 'border-box' }} />
                  <textarea value={v.desc} onChange={e => { const nv = [...c.values]; nv[i] = { ...v, desc: e.target.value }; upd('values', nv); }} rows={2} placeholder="Description" style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 7, padding: '8px 12px', color: 'rgba(255,255,255,0.7)', fontFamily: 'DM Sans, sans-serif', fontSize: 12, outline: 'none', resize: 'vertical', boxSizing: 'border-box' }} />
                </div>
                <button onClick={() => upd('values', c.values.filter((_, j) => j !== i))} style={{ width: 32, height: 32, background: 'rgba(220,38,38,0.06)', border: '1px solid rgba(220,38,38,0.15)', borderRadius: 7, cursor: 'pointer', color: '#dc2626', fontSize: 13 }}>🗑</button>
              </div>
            ))}
            <button onClick={() => upd('values', [...c.values, { icon: '⭐', title: 'New value', desc: '' }])} style={{ background: 'transparent', border: '1.5px dashed rgba(255,255,255,0.12)', borderRadius: 8, padding: 12, cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontFamily: 'DM Sans, sans-serif', fontSize: 13 }}>+ Add value</button>
          </div>
        </Card>
      </div>
    </>
  );
}

function SectionTitle({ children }) {
  return <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white', marginBottom: 14, paddingBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.05)' }}>{children}</div>;
}

Object.assign(window, { HomepageEditor, AboutEditor });
