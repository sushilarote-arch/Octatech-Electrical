// Admin mock data — enquiries, users, analytics
window.AdminData = {
  /* ── Admin Users & Roles ── */
  currentUser: {
    id: 1, name: 'Aarav Sharma', email: 'aarav@octatechelectricals.com',
    role: 'super-admin', avatar: 'AS', lastLogin: '2026-05-14T08:30:00',
  },
  adminUsers: [
    { id: 1, name: 'Aarav Sharma', email: 'aarav@octatechelectricals.com', role: 'super-admin', status: 'active', lastLogin: '2026-05-14T08:30:00', created: '2024-01-15' },
    { id: 2, name: 'Priya Patel', email: 'priya@octatechelectricals.com', role: 'editor', status: 'active', lastLogin: '2026-05-13T14:20:00', created: '2024-03-22' },
    { id: 3, name: 'Rohan Mehta', email: 'rohan@octatechelectricals.com', role: 'editor', status: 'active', lastLogin: '2026-05-12T11:45:00', created: '2024-06-10' },
    { id: 4, name: 'Sneha Kulkarni', email: 'sneha@octatechelectricals.com', role: 'viewer', status: 'active', lastLogin: '2026-05-10T09:15:00', created: '2025-02-08' },
    { id: 5, name: 'Vikram Joshi', email: 'vikram@octatechelectricals.com', role: 'editor', status: 'inactive', lastLogin: '2025-12-04T16:30:00', created: '2024-11-20' },
  ],
  roles: [
    { id: 'super-admin', label: 'Super Admin', desc: 'Full access to all features and settings', perms: ['all'] },
    { id: 'editor', label: 'Editor', desc: 'Manage products, categories, content. No user management.', perms: ['products', 'content', 'taxonomy'] },
    { id: 'viewer', label: 'Viewer', desc: 'Read-only access to all data. Can view analytics and enquiries.', perms: ['view'] },
  ],

  /* ── PRO Users (customer accounts) ── */
  proUsers: [
    { id: 101, name: 'Rajesh Kumar', company: 'Tata Motors Ltd', email: 'rajesh.kumar@tatamotors.com', phone: '+91 98765 43210', status: 'active', verified: true, joined: '2024-08-15', enquiries: 12, downloads: 8 },
    { id: 102, name: 'Amit Singh', company: 'L&T Heavy Engineering', email: 'amit@larsentoubro.com', phone: '+91 99887 76655', status: 'active', verified: true, joined: '2024-09-22', enquiries: 7, downloads: 15 },
    { id: 103, name: 'Sandeep Gupta', company: 'Bharat Forge', email: 'sandeep@bharatforge.com', phone: '+91 91234 56789', status: 'pending', verified: false, joined: '2026-05-12', enquiries: 0, downloads: 0 },
    { id: 104, name: 'Meera Iyer', company: 'Siemens India', email: 'meera.iyer@siemens.com', phone: '+91 90123 45678', status: 'active', verified: true, joined: '2024-11-08', enquiries: 23, downloads: 32 },
    { id: 105, name: 'Karthik Reddy', company: 'BHEL', email: 'karthik@bhel.in', phone: '+91 93456 78901', status: 'active', verified: true, joined: '2025-01-15', enquiries: 5, downloads: 4 },
    { id: 106, name: 'Anjali Verma', company: 'Indian Railways', email: 'anjali@indianrailways.gov.in', phone: '+91 94567 89012', status: 'active', verified: true, joined: '2025-03-04', enquiries: 18, downloads: 11 },
    { id: 107, name: 'Suresh Naik', company: 'Reliance Industries', email: 'suresh@ril.com', phone: '+91 95678 90123', status: 'pending', verified: false, joined: '2026-05-13', enquiries: 0, downloads: 0 },
    { id: 108, name: 'Deepak Shah', company: 'Mahindra & Mahindra', email: 'deepak@mahindra.com', phone: '+91 96789 01234', status: 'active', verified: true, joined: '2024-12-20', enquiries: 9, downloads: 6 },
  ],

  /* ── Enquiries (inbox) ── */
  enquiries: [
    { id: 1001, from: 'Rajesh Kumar', company: 'Tata Motors Ltd', email: 'rajesh.kumar@tatamotors.com', phone: '+91 98765 43210', product: 'Brass Double Compression Gland', message: 'Need 2000 units of M20 size for our Pune EV plant. Please share quotation and lead time.', status: 'new', priority: 'high', received: '2026-05-14T09:32:00', read: false },
    { id: 1002, from: 'Amit Singh', company: 'L&T Heavy Engineering', email: 'amit@larsentoubro.com', phone: '+91 99887 76655', product: 'PCC / MCC Panel', message: 'Custom MCC panel for industrial water treatment plant. 6300A rating. Could you arrange a technical discussion?', status: 'in-progress', priority: 'high', received: '2026-05-14T08:15:00', read: true, assignedTo: 'Priya Patel' },
    { id: 1003, from: 'Meera Iyer', company: 'Siemens India', email: 'meera.iyer@siemens.com', phone: '+91 90123 45678', product: 'EMC Cable Gland', message: 'Bulk order enquiry — 5000 units mixed sizes. Need EMC datasheet and ATEX cert copy.', status: 'new', priority: 'medium', received: '2026-05-14T07:45:00', read: false },
    { id: 1004, from: 'Karthik Reddy', company: 'BHEL', email: 'karthik@bhel.in', phone: '+91 93456 78901', product: 'PV Photovoltaic Relay', message: 'For 100MW solar farm project. Need 5000 units. Send pricing in tiers.', status: 'replied', priority: 'medium', received: '2026-05-13T16:20:00', read: true, assignedTo: 'Rohan Mehta' },
    { id: 1005, from: 'Anjali Verma', company: 'Indian Railways', email: 'anjali@indianrailways.gov.in', phone: '+91 94567 89012', product: 'Heavy Duty Connector Housing', message: 'Vande Bharat coach assembly. Need B24 frame size with 16A pins. Lead time?', status: 'new', priority: 'high', received: '2026-05-13T14:10:00', read: false },
    { id: 1006, from: 'Deepak Shah', company: 'Mahindra & Mahindra', email: 'deepak@mahindra.com', phone: '+91 96789 01234', product: 'Polyamide Flexible Conduit', message: 'XEV 9e production line. PA12 slitted 16mm OD, 50,000 meters per month requirement.', status: 'in-progress', priority: 'high', received: '2026-05-13T11:30:00', read: true, assignedTo: 'Aarav Sharma' },
    { id: 1007, from: 'Vikram Joshi', company: 'JSW Steel', email: 'vikram@jsw.in', phone: '+91 97890 12345', product: 'Industrial Plug & Socket 32A', message: 'Vijaynagar plant CEE outlets required — 500 units 63A.', status: 'replied', priority: 'low', received: '2026-05-12T15:45:00', read: true, assignedTo: 'Priya Patel' },
    { id: 1008, from: 'Pooja Desai', company: 'Adani Power', email: 'pooja@adani.in', phone: '+91 98901 23456', product: 'Solid State Relay Module', message: 'Mundra power plant — 100A SSR with zero-crossing. Quantity 1200 nos. Please share BOM.', status: 'replied', priority: 'medium', received: '2026-05-12T10:20:00', read: true, assignedTo: 'Rohan Mehta' },
    { id: 1009, from: 'Manoj Kumar', company: 'Hero MotoCorp', email: 'manoj@heromotocorp.com', phone: '+91 99012 34567', product: 'Nylon Cable Ties', message: 'PA66 UV-stabilized, black, 4.8×300mm. 1 million pcs per month standing order possible?', status: 'closed', priority: 'low', received: '2026-05-11T09:00:00', read: true, assignedTo: 'Aarav Sharma' },
    { id: 1010, from: 'Sunita Rao', company: 'NTPC Ltd', email: 'sunita@ntpc.co.in', phone: '+91 91123 45678', product: 'Polycarbonate Junction Box', message: 'IP65 boxes for outdoor switchyard. 300×200mm, 200 units required.', status: 'new', priority: 'medium', received: '2026-05-11T08:30:00', read: false },
  ],

  /* ── Analytics ── */
  analytics: {
    summary: {
      totalViews: 12847, viewsDelta: '+18.4%',
      totalEnquiries: 234, enquiriesDelta: '+7.2%',
      newProUsers: 28, proUsersDelta: '+12.5%',
      catalogDownloads: 89, downloadsDelta: '-3.1%',
    },
    // Last 7 days
    viewsTrend: [
      { day: 'Mon', views: 1654, enquiries: 28 },
      { day: 'Tue', views: 1820, enquiries: 35 },
      { day: 'Wed', views: 1543, enquiries: 22 },
      { day: 'Thu', views: 2104, enquiries: 41 },
      { day: 'Fri', views: 1987, enquiries: 38 },
      { day: 'Sat', views: 1352, enquiries: 18 },
      { day: 'Sun', views: 2387, enquiries: 52 },
    ],
    topProducts: [
      { name: 'Brass Double Compression Gland', views: 1842, enquiries: 24, trend: 'up' },
      { name: 'EMC Cable Gland', views: 1567, enquiries: 19, trend: 'up' },
      { name: 'Industrial Power Relay', views: 1342, enquiries: 15, trend: 'up' },
      { name: 'PCC / MCC Panel', views: 987, enquiries: 18, trend: 'down' },
      { name: 'Polyamide Flexible Conduit', views: 876, enquiries: 12, trend: 'up' },
      { name: 'Heavy Duty Connector Housing', views: 754, enquiries: 11, trend: 'flat' },
    ],
    topIndustries: [
      { id: 'industrial', label: 'Industrial & Energy', share: 42, color: '#e85d26' },
      { id: 'automotive', label: 'Automotive & EV', share: 31, color: '#f47a45' },
      { id: 'railway', label: 'Railway', share: 16, color: '#2563eb' },
      { id: 'infrastructure', label: 'Infrastructure', share: 11, color: '#16a34a' },
    ],
    topCategories: [
      { id: 'cable-glands', label: 'Cable Glands', count: 3421 },
      { id: 'relays', label: 'Relays', count: 2842 },
      { id: 'heavy-duty', label: 'HD Connectors', count: 1654 },
      { id: 'conduits', label: 'Conduits', count: 1432 },
      { id: 'control-panels', label: 'Control Panels', count: 1218 },
    ],
    recentActivity: [
      { type: 'enquiry', message: 'New enquiry from Tata Motors — Brass Cable Gland', time: '5m ago', icon: '✉️' },
      { type: 'user', message: 'Sandeep Gupta requested PRO account', time: '24m ago', icon: '👤' },
      { type: 'product', message: 'Priya Patel updated "Solid State Relay Module"', time: '1h ago', icon: '✏️' },
      { type: 'download', message: 'Meera Iyer downloaded EMC Gland TDS', time: '2h ago', icon: '↓' },
      { type: 'enquiry', message: 'New enquiry from BHEL — PV Relay (5000 units)', time: '3h ago', icon: '✉️' },
      { type: 'user', message: '4 new PRO account requests this morning', time: '4h ago', icon: '👤' },
    ],
  },

  /* ── Editable content (homepage / about) ── */
  homepageContent: {
    heroOverline: "INDIA'S LEADING DISTRIBUTOR",
    heroHeadline: 'Industrial Electrical Components for Every Application',
    heroDescription: 'Certified industrial electrical distributor serving automotive, energy, and infrastructure sectors across India.',
    ctaPrimary: 'Browse Catalog',
    ctaSecondary: 'Get a Quote',
    stats: [
      { value: '150+', label: 'Products' },
      { value: '12', label: 'Categories' },
      { value: '7', label: 'Certifications' },
      { value: '25+', label: 'Years Experience' },
    ],
  },
  aboutContent: {
    heroHeadline: "India's Leading Industrial Electrical Distributor",
    heroDescription: 'Octa Tech Electricals is one of the fastest-growing distributors of industrial electrical components in India.',
    fullStory: 'Founded in 2001 in Nashik, Maharashtra, Octa Tech Electricals has grown to become one of India\'s most trusted distributors of industrial electrical components. We serve over 500 customers across automotive, industrial, railway, and infrastructure sectors with internationally certified products.',
    values: [
      { icon: '🏆', title: 'Quality First', desc: 'Every product carries international certifications.' },
      { icon: '🌐', title: 'Wide Spectrum', desc: '150+ products across 12 categories.' },
      { icon: '🤝', title: 'Client Partnership', desc: 'Technical guidance and responsive support.' },
      { icon: '⚡', title: 'Fast Growing', desc: 'One of India\'s fastest growing distributors.' },
    ],
  },
};
