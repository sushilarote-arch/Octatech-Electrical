// admin/login.jsx
const { useState } = React;

function AdminLogin({ onLogin }) {
  const [email, setEmail] = useState('aarav@octatechelectricals.com');
  const [password, setPassword] = useState('admin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const submit = (e) => {
    e?.preventDefault();
    setLoading(true);
    setError('');
    setTimeout(() => {
      if (email && password) onLogin();
      else { setError('Please enter email and password'); setLoading(false); }
    }, 600);
  };

  return (
    <div style={{
      minHeight: '100vh', background: '#08111f',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(rgba(232,93,38,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(232,93,38,0.04) 1px, transparent 1px)`,
        backgroundSize: '60px 60px',
      }} />
      {/* Glow orb */}
      <div style={{ position: 'absolute', top: '20%', left: '50%', transform: 'translateX(-50%)', width: 480, height: 480, borderRadius: '50%', background: 'radial-gradient(circle, rgba(232,93,38,0.1) 0%, transparent 70%)', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', width: '100%', maxWidth: 400 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ width: 56, height: 56, background: 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', boxShadow: '0 8px 32px rgba(232,93,38,0.35)' }}>
            <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 30, fontWeight: 900, color: 'white' }}>O</span>
          </div>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 20, fontWeight: 800, color: 'white', letterSpacing: -0.3, marginBottom: 4 }}>OCTA TECH</div>
          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600, color: '#e85d26', letterSpacing: 3 }}>ADMIN PORTAL</div>
        </div>

        <form onSubmit={submit} style={{
          background: '#0d1929', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16,
          padding: 32, boxShadow: '0 24px 80px rgba(0,0,0,0.5)',
        }}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 20, fontWeight: 700, color: 'white', marginBottom: 4 }}>Sign in</div>
          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.4)', marginBottom: 24 }}>Welcome back. Enter your admin credentials.</div>

          {error && (
            <div style={{ background: 'rgba(220,38,38,0.1)', border: '1px solid rgba(220,38,38,0.3)', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: '#dc2626' }}>
              {error}
            </div>
          )}

          <Input label="Email Address" type="email" placeholder="you@octatechelectricals.com" value={email} onChange={e => setEmail(e.target.value)} required />
          <Input label="Password" type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required />

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer' }}>
              <input type="checkbox" defaultChecked style={{ accentColor: '#e85d26' }} />
              <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Remember me</span>
            </label>
            <button type="button" style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: '#e85d26' }}>Forgot password?</button>
          </div>

          <button type="submit" disabled={loading} style={{
            width: '100%', padding: 12, background: 'linear-gradient(135deg, #e85d26, #ff7a45)',
            border: 'none', borderRadius: 10, cursor: loading ? 'not-allowed' : 'pointer',
            fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white',
            boxShadow: '0 4px 20px rgba(232,93,38,0.3)', opacity: loading ? 0.7 : 1,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            {loading ? (
              <>
                <span style={{ width: 14, height: 14, border: '2px solid rgba(255,255,255,0.3)', borderTopColor: 'white', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.7s linear infinite' }} />
                Signing in…
              </>
            ) : 'Sign in →'}
          </button>

          <div style={{ textAlign: 'center', marginTop: 16, fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.25)' }}>
            Pre-filled demo credentials — click Sign in to enter
          </div>
        </form>

        <div style={{ textAlign: 'center', marginTop: 20, fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>
          © 2026 Octa Tech Electricals · Secure admin access
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AdminLogin });
