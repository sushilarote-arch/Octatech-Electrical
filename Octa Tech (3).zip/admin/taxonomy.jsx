// admin/taxonomy.jsx — Categories, Industries, Certifications
const { useState } = React;

/* ── Categories ── */
function CategoriesPage() {
  const { isMobile, isTablet } = window.useBreakpoint();
  const [cats, setCats] = useState(window.OctaData.categories);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const onSave = (data) => {
    if (editing) setCats(prev => prev.map(c => c.id === editing.id ? { ...c, ...data } : c));
    else setCats(prev => [...prev, { ...data, id: data.label.toLowerCase().replace(/[^a-z0-9]+/g, '-'), count: 0 }]);
    setShowForm(false); setEditing(null);
  };
  const onDelete = (id) => { if (confirm('Delete this category?')) setCats(prev => prev.filter(c => c.id !== id)); };

  return (
    <>
      <PageHeader title="Categories" subtitle={`${cats.length} product categories`} actions={<Btn variant="primary" icon="+" onClick={() => { setEditing(null); setShowForm(true); }}>Add Category</Btn>} />
      <div style={{ padding: isMobile ? '16px 16px 60px' : '24px 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : isTablet ? 'repeat(2, 1fr)' : 'repeat(3, 1fr)', gap: 14 }}>
          {cats.map(c => (
            <Card key={c.id} padding={20}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
                <div style={{ width: 44, height: 44, background: 'rgba(232,93,38,0.1)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>{c.icon}</div>
                <Badge variant="default">{c.count} products</Badge>
              </div>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 4 }}>{c.label}</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 14 }}>{c.id}</div>
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 14 }}>
                {c.industry.map(i => {
                  const ind = window.OctaData.industries.find(x => x.id === i);
                  return ind ? <Badge key={i} variant="default" size="sm">{ind.label.split(' ')[0]}</Badge> : null;
                })}
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn variant="secondary" size="sm" style={{ flex: 1 }} onClick={() => { setEditing(c); setShowForm(true); }}>Edit</Btn>
                <Btn variant="danger" size="sm" onClick={() => onDelete(c.id)}>🗑</Btn>
              </div>
            </Card>
          ))}
          <button onClick={() => { setEditing(null); setShowForm(true); }} style={{ background: 'transparent', border: '2px dashed rgba(255,255,255,0.1)', borderRadius: 12, padding: 30, cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontFamily: 'DM Sans, sans-serif', fontSize: 14, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <span style={{ fontSize: 24 }}>+</span>
            <span>Add new category</span>
          </button>
        </div>
      </div>
      {showForm && <TaxonomyModal type="Category" editing={editing} onSave={onSave} onClose={() => { setShowForm(false); setEditing(null); }} hasIcon hasIndustry />}
    </>
  );
}

/* ── Industries ── */
function IndustriesPage() {
  const { isMobile, isTablet } = window.useBreakpoint();
  const [industries, setIndustries] = useState(window.OctaData.industries.filter(i => i.id !== 'all'));
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  const onSave = (data) => {
    if (editing) setIndustries(prev => prev.map(i => i.id === editing.id ? { ...i, ...data } : i));
    else setIndustries(prev => [...prev, { ...data, id: data.label.toLowerCase().replace(/[^a-z0-9]+/g, '-'), count: 0 }]);
    setShowForm(false); setEditing(null);
  };

  return (
    <>
      <PageHeader title="Industries" subtitle={`${industries.length} industry sectors`} actions={<Btn variant="primary" icon="+" onClick={() => { setEditing(null); setShowForm(true); }}>Add Industry</Btn>} />
      <div style={{ padding: isMobile ? '16px 16px 60px' : '24px 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr 1fr' : isTablet ? 'repeat(3, 1fr)' : 'repeat(4, 1fr)', gap: 14 }}>
          {industries.map(i => (
            <Card key={i.id} padding={20}>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 4 }}>{i.label}</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 12 }}>{i.id}</div>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 22, fontWeight: 800, color: '#e85d26', marginBottom: 14 }}>{i.count} <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', fontWeight: 500 }}>products</span></div>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn variant="secondary" size="sm" style={{ flex: 1 }} onClick={() => { setEditing(i); setShowForm(true); }}>Edit</Btn>
                <Btn variant="danger" size="sm">🗑</Btn>
              </div>
            </Card>
          ))}
        </div>
      </div>
      {showForm && <TaxonomyModal type="Industry" editing={editing} onSave={onSave} onClose={() => { setShowForm(false); setEditing(null); }} />}
    </>
  );
}

/* ── Certifications ── */
function CertificationsPage() {
  const { isMobile } = window.useBreakpoint();
  const [certs, setCerts] = useState(window.OctaData.certifications.map(c => ({ id: c, label: c, region: c === 'CE' || c === 'TÜV' || c === 'VDE' || c === 'ATEX' ? 'Europe' : c === 'UL' || c === 'CSA' ? 'North America' : 'Global', issuer: 'International standard' })));
  const [newCode, setNewCode] = useState('');

  return (
    <>
      <PageHeader title="Certifications" subtitle={`${certs.length} certification marks managed`} actions={<Btn variant="secondary" icon="↑">Upload Logo</Btn>} />
      <div style={{ padding: '24px 32px' }}>
        <Card padding={24} style={{ marginBottom: 16 }}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white', marginBottom: 12 }}>Add Certification</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <input value={newCode} onChange={e => setNewCode(e.target.value)} placeholder="Code (e.g., IECEx)" style={{ width: 200, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '9px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none' }} />
            <select style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '9px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
              <option>Region: Global</option><option>Europe</option><option>North America</option><option>Asia Pacific</option>
            </select>
            <Btn variant="primary" onClick={() => { if (newCode.trim()) { setCerts(prev => [...prev, { id: newCode, label: newCode, region: 'Global', issuer: 'New' }]); setNewCode(''); } }}>+ Add</Btn>
          </div>
        </Card>
        <Card padding={0}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                {['Cert', 'Region', 'Issuer', 'Used by', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: h === 'Actions' ? 'right' : 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700 }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {certs.map(c => {
                const usedBy = window.OctaData.products.filter(p => p.certs.includes(c.label)).length;
                return (
                  <tr key={c.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                    <td style={{ padding: '14px 16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{ width: 44, height: 44, border: '2px solid rgba(255,255,255,0.15)', borderRadius: 8, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3 }}>
                          <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 13, fontWeight: 800, color: 'white' }}>{c.label}</span>
                          <div style={{ width: 14, height: 2, background: '#e85d26', borderRadius: 1 }} />
                        </div>
                        <div>
                          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white' }}>{c.label}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '14px 16px' }}><Badge variant="info">{c.region}</Badge></td>
                    <td style={{ padding: '14px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{c.issuer}</td>
                    <td style={{ padding: '14px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{usedBy} products</td>
                    <td style={{ padding: '14px 16px', textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                        <button title="Edit" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>✏️</button>
                        <button title="Delete" style={{ width: 28, height: 28, background: 'rgba(220,38,38,0.06)', border: '1px solid rgba(220,38,38,0.15)', borderRadius: 6, cursor: 'pointer', color: '#dc2626', fontSize: 12 }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}

/* ── Modal helper ── */
function TaxonomyModal({ type, editing, onSave, onClose, hasIcon, hasIndustry }) {
  const [data, setData] = useState(editing || { label: '', icon: '⚙️', industry: [] });
  const toggle = (k, v) => setData(prev => ({ ...prev, [k]: (prev[k] || []).includes(v) ? prev[k].filter(x => x !== v) : [...(prev[k] || []), v] }));
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, zIndex: 2000, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20, animation: 'fadeIn 0.15s ease' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#0d1929', borderRadius: 14, width: '100%', maxWidth: 460, border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 40px 100px rgba(0,0,0,0.6)', animation: 'slideUp 0.2s ease' }}>
        <div style={{ padding: '20px 24px', borderBottom: '1px solid rgba(255,255,255,0.07)', display: 'flex', justifyContent: 'space-between' }}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 17, fontWeight: 700, color: 'white' }}>{editing ? `Edit ${type}` : `Add ${type}`}</div>
          <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.07)', border: 'none', borderRadius: 6, width: 28, height: 28, cursor: 'pointer', color: 'rgba(255,255,255,0.5)', fontSize: 16 }}>×</button>
        </div>
        <div style={{ padding: 24 }}>
          <Input label={`${type} Name`} required value={data.label} onChange={e => setData({ ...data, label: e.target.value })} />
          {hasIcon && (
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>Icon</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                {['⚡','🔌','🖥️','〰️','🔗','📦','🔋','⛓️','🪢','🔧','🛠️','💡','🔆','⚙️','🔩'].map(em => (
                  <button key={em} onClick={() => setData({ ...data, icon: em })} style={{ width: 38, height: 38, borderRadius: 8, background: data.icon === em ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.04)', border: data.icon === em ? '1.5px solid #e85d26' : '1px solid rgba(255,255,255,0.08)', cursor: 'pointer', fontSize: 18 }}>{em}</button>
                ))}
              </div>
            </div>
          )}
          {hasIndustry && (
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>Applicable Industries</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                {window.OctaData.industries.filter(i => i.id !== 'all').map(ind => (
                  <button key={ind.id} onClick={() => toggle('industry', ind.id)} style={{ padding: '5px 12px', borderRadius: 6, background: (data.industry || []).includes(ind.id) ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.04)', border: (data.industry || []).includes(ind.id) ? '1px solid rgba(232,93,38,0.35)' : '1px solid rgba(255,255,255,0.08)', color: (data.industry || []).includes(ind.id) ? '#e85d26' : 'rgba(255,255,255,0.6)', fontFamily: 'DM Sans, sans-serif', fontSize: 12, cursor: 'pointer' }}>{ind.label}</button>
                ))}
              </div>
            </div>
          )}
          <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
            <Btn variant="ghost" size="md" style={{ flex: 1 }} onClick={onClose}>Cancel</Btn>
            <Btn variant="primary" size="md" style={{ flex: 1 }} onClick={() => onSave(data)}>{editing ? 'Save' : 'Add'}</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CategoriesPage, IndustriesPage, CertificationsPage });
