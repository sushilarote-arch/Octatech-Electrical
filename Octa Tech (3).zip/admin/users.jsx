// admin/users.jsx — PRO users + Admin users
const { useState } = React;

/* ── PRO USERS ── */
function ProUsersPage() {
  const { isMobile } = window.useBreakpoint();
  const [users, setUsers] = useState(window.AdminData.proUsers);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = users.filter(u => {
    if (filter === 'pending' && u.status !== 'pending') return false;
    if (filter === 'active' && u.status !== 'active') return false;
    if (search && !u.name.toLowerCase().includes(search.toLowerCase()) && !u.company.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const approve = (id) => setUsers(prev => prev.map(u => u.id === id ? { ...u, status: 'active', verified: true } : u));
  const reject = (id) => setUsers(prev => prev.map(u => u.id === id ? { ...u, status: 'rejected' } : u));

  return (
    <>
      <PageHeader
        title="PRO Users"
        subtitle={`${users.filter(u => u.status === 'active').length} active · ${users.filter(u => u.status === 'pending').length} pending approval`}
        actions={
          <>
            <Btn variant="secondary" size="md" icon="↓">Export</Btn>
            <Btn variant="primary" size="md" icon="+">Invite User</Btn>
          </>
        }
      />

      <div style={{ padding: '24px 32px' }}>
        {/* Filter chips */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center' }}>
          {[['all', 'All Users'], ['active', 'Active'], ['pending', 'Pending Approval']].map(([id, label]) => (
            <button key={id} onClick={() => setFilter(id)} style={{
              padding: '6px 14px', borderRadius: 20,
              background: filter === id ? '#1e2d4a' : 'rgba(255,255,255,0.04)',
              border: filter === id ? 'none' : '1px solid rgba(255,255,255,0.08)',
              color: filter === id ? 'white' : 'rgba(255,255,255,0.55)',
              fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            }}>{label}</button>
          ))}
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '0 10px', height: 32, gap: 7, width: 240 }}>
            <span style={{ fontSize: 12, opacity: 0.4 }}>🔍</span>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name or company..." style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 12 }} />
          </div>
        </div>

        <Card padding={0}>
          <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: isMobile ? 800 : 'auto' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                {['User', 'Company', 'Joined', 'Activity', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: h === 'Actions' ? 'right' : 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700 }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 36, height: 36, borderRadius: '50%', background: `hsl(${u.id * 47}, 50%, 35%)`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Space Grotesk, sans-serif', fontSize: 13, fontWeight: 700, color: 'white' }}>{u.name.split(' ').map(n => n[0]).slice(0,2).join('')}</div>
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, color: 'white' }}>{u.name}</span>
                          {u.verified && <span title="Verified" style={{ fontSize: 11, color: '#16a34a' }}>✓</span>}
                        </div>
                        <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{u.company}</td>
                  <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{new Date(u.joined).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', gap: 10, fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>
                      <span>✉ {u.enquiries}</span>
                      <span>↓ {u.downloads}</span>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <Badge variant={u.status === 'active' ? 'success' : u.status === 'pending' ? 'warning' : 'danger'}>{u.status}</Badge>
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    {u.status === 'pending' ? (
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                        <Btn size="sm" variant="success" onClick={() => approve(u.id)}>Approve</Btn>
                        <Btn size="sm" variant="ghost" onClick={() => reject(u.id)}>Reject</Btn>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                        <button title="View" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>👁</button>
                        <button title="Edit" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>✏️</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </Card>
      </div>
    </>
  );
}

/* ── ADMIN USERS ── */
function AdminUsersPage() {
  const { isMobile } = window.useBreakpoint();
  const [admins] = useState(window.AdminData.adminUsers);
  const roles = window.AdminData.roles;

  return (
    <>
      <PageHeader
        title="Admin Users"
        subtitle={`${admins.filter(a => a.status === 'active').length} active admins · ${roles.length} roles configured`}
        actions={<Btn variant="primary" size="md" icon="+">Invite Admin</Btn>}
      />

      <div style={{ padding: '24px 32px' }}>
        {/* Roles overview */}
        <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : 'repeat(3,1fr)', gap: 14, marginBottom: 28 }}>
          {roles.map(r => {
            const count = admins.filter(a => a.role === r.id).length;
            return (
              <Card key={r.id} padding={20}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white' }}>{r.label}</div>
                  <Badge variant={r.id === 'super-admin' ? 'accent' : r.id === 'editor' ? 'info' : 'default'}>{count} user{count !== 1 ? 's' : ''}</Badge>
                </div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)', lineHeight: 1.5, marginBottom: 12 }}>{r.desc}</div>
                <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                  {r.perms.map(p => <Badge key={p} variant="default" size="sm">{p}</Badge>)}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Users table */}
        <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 12 }}>All Admin Users</div>
        <Card padding={0}>
          <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: isMobile ? 760 : 'auto' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                {['User', 'Role', 'Status', 'Last Login', 'Created', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: h === 'Actions' ? 'right' : 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700 }}>{h.toUpperCase()}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {admins.map(a => (
                <tr key={a.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Space Grotesk, sans-serif', fontSize: 13, fontWeight: 700, color: 'white' }}>{a.name.split(' ').map(n => n[0]).slice(0,2).join('')}</div>
                      <div>
                        <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, color: 'white' }}>{a.name}</div>
                        <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{a.email}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <Badge variant={a.role === 'super-admin' ? 'accent' : a.role === 'editor' ? 'info' : 'default'}>{roles.find(r => r.id === a.role)?.label}</Badge>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <Badge variant={a.status === 'active' ? 'success' : 'default'}>{a.status}</Badge>
                  </td>
                  <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{new Date(a.lastLogin).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                  <td style={{ padding: '12px 16px', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>{new Date(a.created).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button title="Edit" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>✏️</button>
                      <button title="Reset password" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>🔑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </Card>
      </div>
    </>
  );
}

Object.assign(window, { ProUsersPage, AdminUsersPage });
