// homepage.jsx — Full hi-fi homepage with parallax + scroll animations
const { useState, useEffect, useRef } = React;

function useScrollReveal(threshold = 0.15) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {setVisible(true);obs.disconnect();}
    }, { threshold });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, visible];
}

function RevealDiv({ children, delay = 0, style = {}, className }) {
  const [ref, visible] = useScrollReveal();
  return (
    <div ref={ref} className={className} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? 'translateY(0)' : 'translateY(32px)',
      transition: `opacity 0.7s ease ${delay}s, transform 0.7s ease ${delay}s`,
      ...style
    }}>{children}</div>);

}

function CountUp({ target, suffix = '' }) {
  const [val, setVal] = useState(0);
  const [ref, visible] = useScrollReveal(0.3);
  useEffect(() => {
    if (!visible) return;
    let start = 0;
    const step = target / 40;
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {setVal(target);clearInterval(timer);} else
      setVal(Math.floor(start));
    }, 30);
    return () => clearInterval(timer);
  }, [visible]);
  return <span ref={ref}>{val}{suffix}</span>;
}

function ProductCard({ product, onCompare, compareList, navigate, openEnquiry }) {
  const [hovered, setHovered] = useState(false);
  const inCompare = compareList.some((p) => p.id === product.id);
  return (
    <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
    style={{
      background: hovered ? '#1a2f50' : '#142240',
      border: `1px solid ${hovered ? 'rgba(232,93,38,0.3)' : 'rgba(255,255,255,0.06)'}`,
      borderRadius: 12, overflow: 'hidden', cursor: 'pointer',
      transition: 'all 0.25s ease',
      transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
      boxShadow: hovered ? '0 16px 40px rgba(0,0,0,0.4)' : '0 4px 16px rgba(0,0,0,0.2)'
    }}>
      {/* Image area */}
      <div onClick={() => navigate('product', product)} style={{ position: 'relative', height: 160, background: 'linear-gradient(135deg, #1e3358, #0f2040)', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
        <div style={{ width: 80, height: 80, background: 'rgba(255,255,255,0.04)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36 }}>
          {window.OctaData.categories.find((c) => c.id === product.category)?.icon || '⚙️'}
        </div>
        {product.badge &&
        <div style={{ position: 'absolute', top: 10, left: 10, background: product.badge === 'New' ? '#16a34a' : 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 4, padding: '2px 8px', fontFamily: 'DM Sans', fontSize: 10, fontWeight: 700, color: 'white' }}>{product.badge}</div>
        }
        <div style={{ position: 'absolute', top: 10, right: 10, display: 'flex', gap: 5, opacity: hovered ? 1 : 0, transition: 'opacity 0.2s' }}>
          <button onClick={(e) => {e.stopPropagation();onCompare(product);}} style={{
            width: 28, height: 28, background: inCompare ? '#e85d26' : 'rgba(255,255,255,0.1)',
            border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 12, color: 'white',
            display: 'flex', alignItems: 'center', justifyContent: 'center'
          }} title="Compare">⊞</button>
        </div>
      </div>
      {/* Info */}
      <div style={{ padding: '14px 16px' }}>
        <div onClick={() => navigate('product', product)}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 600, color: 'white', marginBottom: 4, lineHeight: 1.3 }}>{product.name}</div>
          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 10, lineHeight: 1.4 }}>{product.tagline}</div>
        </div>
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginBottom: 12 }}>
          {product.certs.slice(0, 3).map((c) =>
          <span key={c} style={{ border: '1px solid rgba(255,255,255,0.12)', borderRadius: 4, padding: '1px 6px', fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.45)' }}>{c}</span>
          )}
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={() => navigate('product', product)} style={{ flex: 1, padding: '7px 10px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 6, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.7)', transition: 'all 0.2s' }}
          onMouseOver={(e) => {e.currentTarget.style.background = 'rgba(255,255,255,0.1)';}}
          onMouseOut={(e) => {e.currentTarget.style.background = 'rgba(255,255,255,0.05)';}}>Details</button>
          <button onClick={() => openEnquiry(product)} style={{ flex: 1, padding: '7px 10px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 6, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'white' }}>Enquire</button>
        </div>
      </div>
    </div>);

}

function HomePage({ navigate, openLogin, openEnquiry, compareList, onCompare }) {
  const { isMobile, isTablet } = window.useBreakpoint();
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const featured = window.OctaData.products.filter((p) => p.featured).slice(0, 4);
  const cats = window.OctaData.categories;

  return (
    <div style={{ background: '#08111f', minHeight: '100vh', paddingTop: 0 }}>

      {/* ── HERO ── */}
      <div ref={heroRef} style={{ position: 'relative', height: isMobile ? 'auto' : '100vh', minHeight: isMobile ? 'auto' : 600, paddingTop: isMobile ? 100 : 0, paddingBottom: isMobile ? 48 : 0, overflow: 'hidden', display: 'flex', alignItems: 'center' }}>
        {/* Parallax background grid */}
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `
            linear-gradient(rgba(232,93,38,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(232,93,38,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          transform: `translateY(${scrollY * 0.3}px)`,
          transition: 'transform 0.05s linear'
        }} />
        {/* Gradient overlays */}
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 70% 60% at 60% 40%, rgba(30,50,90,0.6) 0%, transparent 70%)' }} />
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '30%', background: 'linear-gradient(transparent, #08111f)' }} />
        {/* Glowing orb */}
        <div style={{
          position: 'absolute', right: '12%', top: '20%',
          width: 400, height: 400, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(232,93,38,0.12) 0%, transparent 70%)',
          transform: `translateY(${scrollY * 0.15}px)`,
          pointerEvents: 'none'
        }} />
        {/* Floating category pills (parallax) — hidden on mobile */}
        {!isMobile && <div style={{
          position: 'absolute', right: '6%', top: '22%',
          transform: `translateY(${scrollY * 0.1}px)`,
          display: 'flex', flexDirection: 'column', gap: 10
        }}>
          {cats.slice(0, 5).map((c, i) =>
          <div key={c.id} onClick={() => navigate('catalog', { category: c.id })} style={{
            background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 8, padding: '8px 16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 10,
            transition: 'all 0.25s', backdropFilter: 'blur(4px)',
            animation: `floatIn 0.5s ease ${0.1 * i + 0.8}s both`
          }}
          onMouseOver={(e) => {e.currentTarget.style.background = 'rgba(232,93,38,0.1)';e.currentTarget.style.borderColor = 'rgba(232,93,38,0.3)';}}
          onMouseOut={(e) => {e.currentTarget.style.background = 'rgba(255,255,255,0.04)';e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';}}>
              <span style={{ fontSize: 16 }}>{c.icon}</span>
              <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.65)' }}>{c.label}</span>
              <span style={{ fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.3)', marginLeft: 4 }}>{c.count}</span>
            </div>
          )}
        </div>}

        {/* Hero text */}
        <div style={{ position: 'relative', zIndex: 2, maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px', width: '100%' }}>
          <div style={{ animation: 'fadeDown 0.6s ease 0.2s both', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
            <div style={{ width: 32, height: 2, background: '#e85d26' }} />
            <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, fontWeight: 600 }}>INDIA'S LEADING DISTRIBUTOR</span>
          </div>
          <div style={{ animation: 'fadeDown 0.6s ease 0.35s both' }}>
            <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 'clamp(40px, 6vw, 72px)', fontWeight: 800, color: 'white', lineHeight: 1.08, margin: 0, marginBottom: 8 }}>
              Industrial Electrical<br />
              <span style={{ background: 'linear-gradient(135deg, #e85d26, #ff9a6c)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Components</span>
              <br />for Every Application
            </h1>
          </div>
          <div style={{ animation: 'fadeDown 0.6s ease 0.5s both' }}>
            <p style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 17, color: 'rgba(255,255,255,0.5)', lineHeight: 1.7, maxWidth: 480, marginTop: 16, marginBottom: 32 }}>
              Certified industrial electrical distributor serving automotive, energy, and infrastructure sectors across India.
            </p>
          </div>
          <div style={{ animation: 'fadeDown 0.6s ease 0.65s both', display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <button onClick={() => navigate('catalog')} style={{
              background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 10,
              padding: '14px 32px', cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white',
              boxShadow: '0 4px 24px rgba(232,93,38,0.35)', transition: 'all 0.2s'
            }}
            onMouseOver={(e) => {e.currentTarget.style.transform = 'translateY(-2px)';e.currentTarget.style.boxShadow = '0 8px 32px rgba(232,93,38,0.45)';}}
            onMouseOut={(e) => {e.currentTarget.style.transform = 'translateY(0)';e.currentTarget.style.boxShadow = '0 4px 24px rgba(232,93,38,0.35)';}}>
              Browse Catalog →
            </button>
            <button onClick={() => openEnquiry(null)} style={{
              border: '1px solid rgba(255,255,255,0.15)',
              padding: '14px 32px', cursor: 'pointer',
              fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 600, color: 'white', transition: 'all 0.2s', background: "rgba(255, 255, 255, 0.06)", borderRadius: "10px"
            }}
            onMouseOver={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
            onMouseOut={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.06)'}>
              Get a Quote
            </button>
          </div>
          {/* Cert badges */}
          <div style={{ animation: 'fadeDown 0.6s ease 0.8s both', marginTop: 40, display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.3)', marginRight: 4 }}>CERTIFIED:</span>
            {window.OctaData.certifications.map((c) =>
            <span key={c} style={{ border: '1px solid rgba(255,255,255,0.15)', borderRadius: 4, padding: '2px 8px', fontFamily: 'DM Sans', fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.45)' }}>{c}</span>
            )}
          </div>
        </div>
        {/* Scroll indicator */}
        <div style={{ position: 'absolute', bottom: 32, left: '50%', transform: 'translateX(-50%)', animation: 'bounce 2s ease infinite', opacity: scrollY > 50 ? 0 : 0.5, transition: 'opacity 0.3s' }}>
          <div style={{ width: 20, height: 32, border: '2px solid rgba(255,255,255,0.3)', borderRadius: 10, display: 'flex', justifyContent: 'center', paddingTop: 6 }}>
            <div style={{ width: 4, height: 8, background: 'rgba(255,255,255,0.4)', borderRadius: 2, animation: 'scrollDot 1.5s ease infinite' }} />
          </div>
        </div>
      </div>

      {/* ── STATS BAR ── */}
      <div style={{ background: '#0d1929', borderTop: '1px solid rgba(255,255,255,0.05)', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px', display: 'grid', gridTemplateColumns: isMobile ? 'repeat(2,1fr)' : 'repeat(4,1fr)' }}>
          {[
          { n: 150, s: '+', l: 'Products' },
          { n: 12, s: '', l: 'Categories' },
          { n: 7, s: '', l: 'Certifications' },
          { n: 25, s: '+', l: 'Years Experience' }].
          map(({ n, s, l }, i) =>
          <RevealDiv key={l} delay={i * 0.1} style={{ padding: '28px 20px', textAlign: 'center', borderRight: i < 3 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
              <div style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: '#e85d26' }}>
                <CountUp target={n} suffix={s} />
              </div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>{l}</div>
            </RevealDiv>
          )}
        </div>
      </div>

      {/* ── INDUSTRIES ── */}
      <div style={{ background: '#08111f', padding: isMobile ? '48px 0' : '80px 0' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px' }}>
          <RevealDiv style={{ marginBottom: 48, textAlign: 'center' }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 12, fontWeight: 600 }}>BY INDUSTRY</div>
            <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: 0 }}>Solutions for Every Sector</h2>
          </RevealDiv>
          <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : isTablet ? 'repeat(2, 1fr)' : 'repeat(4, 1fr)', gap: 16 }}>
            {[
            { id: 'automotive', label: 'Automotive & EV', count: 18, icon: '🚗', desc: 'Wire harness, connectors, EMC protection for vehicles' },
            { id: 'industrial', label: 'Industrial & Energy', count: 20, icon: '🏭', desc: 'Relays, glands, panels for heavy machinery' },
            { id: 'railway', label: 'Railway & Transport', count: 6, icon: '🚂', desc: 'Vibration-proof components for rail applications' },
            { id: 'infrastructure', label: 'Infrastructure', count: 4, icon: '🏗️', desc: 'Junction boxes, plugs for civil projects' }].
            map((ind, i) =>
            <RevealDiv key={ind.id} delay={i * 0.1}>
                <div onClick={() => navigate('catalog', { industry: ind.id })} style={{
                background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 14,
                padding: '28px 24px', cursor: 'pointer', transition: 'all 0.25s', height: '100%'
              }}
              onMouseOver={(e) => {e.currentTarget.style.background = '#142240';e.currentTarget.style.borderColor = 'rgba(232,93,38,0.25)';e.currentTarget.style.transform = 'translateY(-4px)';}}
              onMouseOut={(e) => {e.currentTarget.style.background = '#0d1929';e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)';e.currentTarget.style.transform = 'translateY(0)';}}>
                  <div style={{ fontSize: 32, marginBottom: 14 }}>{ind.icon}</div>
                  <div style={{ fontFamily: 'Space Grotesk', fontSize: 16, fontWeight: 700, color: 'white', marginBottom: 6 }}>{ind.label}</div>
                  <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.4)', lineHeight: 1.5, marginBottom: 16 }}>{ind.desc}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26' }}>{ind.count} products</span>
                    <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 16 }}>→</span>
                  </div>
                </div>
              </RevealDiv>
            )}
          </div>
        </div>
      </div>

      {/* ── FEATURED PRODUCTS ── */}
      <div style={{ background: '#0a1525', padding: isMobile ? '48px 0' : '80px 0', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px' }}>
          <RevealDiv style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 40 }}>
            <div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 10, fontWeight: 600 }}>FEATURED</div>
              <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: 0 }}>Popular Products</h2>
            </div>
            <button onClick={() => navigate('catalog')} style={{ background: 'none', border: '1px solid rgba(255,255,255,0.15)', borderRadius: 8, padding: '10px 20px', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.6)', transition: 'all 0.2s' }}
            onMouseOver={(e) => {e.currentTarget.style.borderColor = '#e85d26';e.currentTarget.style.color = '#e85d26';}}
            onMouseOut={(e) => {e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)';e.currentTarget.style.color = 'rgba(255,255,255,0.6)';}}>
              View all products →
            </button>
          </RevealDiv>
          <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr 1fr' : isTablet ? 'repeat(3, 1fr)' : 'repeat(4, 1fr)', gap: isMobile ? 10 : 16 }}>
            {featured.map((p, i) =>
            <RevealDiv key={p.id} delay={i * 0.08}>
                <ProductCard product={p} onCompare={onCompare} compareList={compareList} navigate={navigate} openEnquiry={openEnquiry} />
              </RevealDiv>
            )}
          </div>
        </div>
      </div>

      {/* ── CERTIFICATIONS ── */}
      <div style={{ background: '#08111f', padding: isMobile ? '48px 0' : '80px 0', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px', textAlign: 'center' }}>
          <RevealDiv style={{ marginBottom: 48 }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 12, fontWeight: 600 }}>QUALITY ASSURED</div>
            <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: '0 0 12px' }}>International Certifications</h2>
            <p style={{ fontFamily: 'DM Sans', fontSize: 15, color: 'rgba(255,255,255,0.4)', maxWidth: 480, margin: '0 auto' }}>All products carry the necessary international approvals, ensuring quality aligned with global norms.</p>
          </RevealDiv>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 20, flexWrap: 'wrap' }}>
            {window.OctaData.certifications.map((c, i) =>
            <RevealDiv key={c} delay={i * 0.06}>
                <div style={{ width: 100, height: 100, background: '#0d1929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'all 0.25s' }}
              onMouseOver={(e) => {e.currentTarget.style.borderColor = 'rgba(232,93,38,0.4)';e.currentTarget.style.background = '#142240';}}
              onMouseOut={(e) => {e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)';e.currentTarget.style.background = '#0d1929';}}>
                  <div style={{ fontFamily: 'Space Grotesk', fontSize: 20, fontWeight: 800, color: 'white' }}>{c}</div>
                  <div style={{ width: 24, height: 2, background: '#e85d26', borderRadius: 1 }} />
                </div>
              </RevealDiv>
            )}
          </div>
        </div>
      </div>

      {/* ── CTA STRIP ── */}
      <div style={{ background: 'linear-gradient(135deg, #e85d26 0%, #c04a1a 100%)', padding: isMobile ? '40px 20px' : '60px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 24 }}>
          <RevealDiv>
            <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 32, fontWeight: 800, color: 'white', margin: '0 0 8px' }}>Ready to source smarter?</h2>
            <p style={{ fontFamily: 'DM Sans', fontSize: 15, color: 'rgba(255,255,255,0.75)', margin: 0 }}>Connect with our team for pricing, availability, and technical support.</p>
          </RevealDiv>
          <RevealDiv delay={0.2} style={{ display: 'flex', gap: 12 }}>
            <button onClick={() => navigate('contact')} style={{ background: 'white', border: 'none', borderRadius: 10, padding: '14px 28px', cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: '#e85d26', transition: 'opacity 0.2s' }}>Contact Us</button>
            <button onClick={() => openEnquiry(null)} style={{ background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 10, padding: '14px 28px', cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 600, color: 'white' }}>Request Quote</button>
          </RevealDiv>
        </div>
      </div>

      {/* ── FOOTER ── */}
      <footer style={{ background: '#050d18', padding: isMobile ? '32px 0 16px' : '48px 0 24px', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '2fr 1fr 1fr 1fr', gap: isMobile ? 24 : 40, marginBottom: isMobile ? 24 : 40 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                <div style={{ width: 28, height: 28, background: 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ fontFamily: 'Space Grotesk', fontSize: 14, fontWeight: 900, color: 'white' }}>O</span>
                </div>
                <span style={{ fontFamily: 'Space Grotesk', fontSize: 16, fontWeight: 700, color: 'white' }}>OCTA TECH</span>
              </div>
              <p style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.35)', lineHeight: 1.7, maxWidth: 280, margin: '0 0 16px' }}>India's leading distributor of industrial electrical components. Internationally certified for every application.</p>
              <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.35)' }}>
                <div>📍 401, Shreeji Vrunda Apt, Nashik — 422009</div>
                <div style={{ marginTop: 4 }}>✉ info@octatechelectricals.com</div>
                <div style={{ marginTop: 4 }}>📞 +91 70667 11811</div>
              </div>
            </div>
            {[
            { title: 'Products', links: ['Relays', 'Cable Glands', 'Control Panels', 'Conduits', 'Heavy Duty Connectors'] },
            { title: 'Company', links: ['About Us', 'Certifications', 'Contact', 'Careers'] },
            { title: 'Legal', links: ['Privacy Policy', 'Terms & Conditions', 'Cookie Policy'] }].
            map((col) =>
            <div key={col.title}>
                <div style={{ fontFamily: 'Space Grotesk', fontSize: 13, fontWeight: 700, color: 'rgba(255,255,255,0.6)', marginBottom: 14, letterSpacing: 1 }}>{col.title.toUpperCase()}</div>
                {col.links.map((l) =>
              <button key={l} onClick={() => col.title === 'Products' ? navigate('catalog') : col.title === 'Company' && l === 'About Us' ? navigate('about') : col.title === 'Company' && l === 'Contact' ? navigate('contact') : null} style={{ display: 'block', background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0', fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.35)', textAlign: 'left', transition: 'color 0.2s' }}
              onMouseOver={(e) => e.currentTarget.style.color = 'rgba(255,255,255,0.7)'}
              onMouseOut={(e) => e.currentTarget.style.color = 'rgba(255,255,255,0.35)'}>{l}</button>
              )}
              </div>
            )}
          </div>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.04)', paddingTop: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.2)' }}>© 2026 Octa Tech Electricals. All rights reserved.</span>
              <a href="Octa Tech Admin.html" style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', background: 'rgba(232,93,38,0.06)', border: '1px solid rgba(232,93,38,0.15)', borderRadius: 5, transition: 'all 0.2s' }}
                onMouseOver={e => { e.currentTarget.style.color = '#e85d26'; e.currentTarget.style.borderColor = 'rgba(232,93,38,0.4)'; }}
                onMouseOut={e => { e.currentTarget.style.color = 'rgba(255,255,255,0.35)'; e.currentTarget.style.borderColor = 'rgba(232,93,38,0.15)'; }}>
                🔐 Admin Portal
              </a>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {window.OctaData.certifications.map((c) => <span key={c} style={{ fontFamily: 'DM Sans', fontSize: 10, fontWeight: 700, color: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 3, padding: '1px 5px' }}>{c}</span>)}
            </div>
          </div>
        </div>
      </footer>
    </div>);

}

Object.assign(window, { HomePage, ProductCard });