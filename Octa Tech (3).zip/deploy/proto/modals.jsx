// modals.jsx — Login, Enquiry, Compare modals
const { useState } = React;

function Modal({ onClose, children, width = 480 }) {
  return (
    <div onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 2000,
      background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20, animation: 'fadeIn 0.15s ease',
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: '#0d1929', borderRadius: 16, width: '100%', maxWidth: width,
        border: '1px solid rgba(255,255,255,0.1)',
        boxShadow: '0 40px 100px rgba(0,0,0,0.6)',
        animation: 'slideUp 0.2s ease',
        maxHeight: '90vh', overflowY: 'auto',
      }}>
        {children}
      </div>
    </div>
  );
}

function ModalHeader({ title, subtitle, onClose }) {
  return (
    <div style={{ padding: '28px 32px 0', borderBottom: '1px solid rgba(255,255,255,0.08)', paddingBottom: 20, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <div>
        <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 22, fontWeight: 700, color: 'white', marginBottom: 4 }}>{title}</div>
        {subtitle && <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 14, color: 'rgba(255,255,255,0.45)' }}>{subtitle}</div>}
      </div>
      <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.07)', border: 'none', borderRadius: 8, width: 32, height: 32, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginLeft: 16 }}>×</button>
    </div>
  );
}

function FormField({ label, type = 'text', placeholder, required, select, options }) {
  const inputStyle = {
    width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: 8, padding: '10px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif',
    fontSize: 14, outline: 'none', transition: 'border-color 0.2s', boxSizing: 'border-box',
  };
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6, letterSpacing: 0.5 }}>
        {label}{required && <span style={{ color: '#e85d26' }}>*</span>}
      </label>
      {select ? (
        <select style={{ ...inputStyle, appearance: 'none' }}>
          <option value="">Select...</option>
          {options.map(o => <option key={o}>{o}</option>)}
        </select>
      ) : type === 'textarea' ? (
        <textarea rows={4} placeholder={placeholder} style={{ ...inputStyle, resize: 'vertical' }} />
      ) : (
        <input type={type} placeholder={placeholder} style={inputStyle}
          onFocus={e => e.target.style.borderColor = 'rgba(232,93,38,0.6)'}
          onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.1)'} />
      )}
    </div>
  );
}

function LoginModal({ onClose }) {
  const [tab, setTab] = useState('login');
  return (
    <Modal onClose={onClose} width={440}>
      <ModalHeader
        title={tab === 'login' ? 'PRO Sign In' : 'Request Account'}
        subtitle={tab === 'login' ? 'Access technical data sheets and exclusive pricing' : 'Are you an Octa Tech client?'}
        onClose={onClose} />
      <div style={{ padding: '0 32px', marginTop: 20, display: 'flex', gap: 4, marginBottom: 20 }}>
        {[['login', 'Sign In'], ['register', 'Request Account']].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} style={{
            flex: 1, padding: '8px', borderRadius: 8, border: 'none', cursor: 'pointer',
            background: tab === key ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.04)',
            color: tab === key ? '#e85d26' : 'rgba(255,255,255,0.5)',
            fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600,
            transition: 'all 0.2s',
          }}>{label}</button>
        ))}
      </div>
      <div style={{ padding: '0 32px 28px' }}>
        {tab === 'login' ? (
          <>
            <FormField label="Email Address" type="email" placeholder="you@company.com" required />
            <FormField label="Password" type="password" placeholder="••••••••" required />
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
                <input type="checkbox" />
                <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>Remember me</span>
              </label>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 13, color: '#e85d26' }}>Forgot password?</button>
            </div>
          </>
        ) : (
          <>
            <FormField label="Full Name" placeholder="Your full name" required />
            <FormField label="Company Name" placeholder="Your company" required />
            <FormField label="Email" type="email" placeholder="you@company.com" required />
            <FormField label="Phone" type="tel" placeholder="+91 XXXXX XXXXX" required />
            <FormField label="Message" type="textarea" placeholder="Tell us about your requirements..." />
          </>
        )}
        <button style={{
          width: '100%', padding: 14, background: 'linear-gradient(135deg, #e85d26, #ff7a45)',
          border: 'none', borderRadius: 10, cursor: 'pointer',
          fontFamily: 'Space Grotesk, sans-serif', fontSize: 15, fontWeight: 700, color: 'white',
          boxShadow: '0 4px 20px rgba(232,93,38,0.3)', transition: 'opacity 0.2s',
        }} onMouseOver={e => e.currentTarget.style.opacity = '0.9'} onMouseOut={e => e.currentTarget.style.opacity = '1'}>
          {tab === 'login' ? 'Sign In →' : 'Submit Request →'}
        </button>
        <p style={{ textAlign: 'center', marginTop: 14, fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>
          By continuing you accept our <span style={{ color: '#e85d26', cursor: 'pointer' }}>Terms & Conditions</span>
        </p>
      </div>
    </Modal>
  );
}

function EnquiryModal({ onClose, product }) {
  const [sent, setSent] = useState(false);
  return (
    <Modal onClose={onClose} width={500}>
      <ModalHeader title="Request Information" subtitle={product ? `About: ${product.name}` : 'Get in touch with our team'} onClose={onClose} />
      {sent ? (
        <div style={{ padding: '40px 32px', textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
          <div style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 700, color: 'white', marginBottom: 8 }}>Request Sent!</div>
          <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.5)', marginBottom: 24 }}>Our team will get back to you within 24 hours.</div>
          <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.07)', border: 'none', borderRadius: 8, padding: '10px 24px', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 14, color: 'white' }}>Close</button>
        </div>
      ) : (
        <div style={{ padding: '24px 32px 28px' }}>
          {product && (
            <div style={{ background: 'rgba(232,93,38,0.08)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 8, padding: '10px 14px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#e85d26', flexShrink: 0 }} />
              <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>{product.name}</span>
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <FormField label="Full Name" placeholder="Your name" required />
            <FormField label="Company" placeholder="Company name" required />
            <FormField label="Email" type="email" placeholder="you@company.com" required />
            <FormField label="Phone" type="tel" placeholder="+91 XXXXX XXXXX" required />
          </div>
          <FormField label="Message" type="textarea" placeholder="Describe your requirements, quantities, application..." required />
          <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 20, cursor: 'pointer' }}>
            <input type="checkbox" style={{ marginTop: 2 }} />
            <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.4)', lineHeight: 1.5 }}>
              I have read and accept the <span style={{ color: '#e85d26' }}>Terms & Conditions</span> and consent to being contacted.
            </span>
          </label>
          <button onClick={() => setSent(true)} style={{
            width: '100%', padding: 14, background: 'linear-gradient(135deg, #e85d26, #ff7a45)',
            border: 'none', borderRadius: 10, cursor: 'pointer',
            fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white',
            boxShadow: '0 4px 20px rgba(232,93,38,0.3)',
          }}>Send Request →</button>
        </div>
      )}
    </Modal>
  );
}

function CompareModal({ onClose, products, navigate }) {
  if (products.length === 0) return null;
  const specs = ['material', 'temperature', 'ipRating', 'certs'];
  const specLabels = { material: 'Material', temperature: 'Temperature', ipRating: 'IP Rating', certs: 'Certifications' };
  return (
    <Modal onClose={onClose} width={860}>
      <ModalHeader title={`Comparing ${products.length} Products`} subtitle="Side-by-side specification comparison" onClose={onClose} />
      <div style={{ padding: '20px 24px 28px', overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <td style={{ padding: '8px 12px', fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.3)', letterSpacing: 1 }}>SPECIFICATION</td>
              {products.map(p => (
                <td key={p.id} style={{ padding: '8px 12px', textAlign: 'center' }}>
                  <div style={{ fontFamily: 'Space Grotesk', fontSize: 14, fontWeight: 700, color: 'white', marginBottom: 4 }}>{p.name}</div>
                  <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{p.category.replace(/-/g, ' ')}</div>
                </td>
              ))}
            </tr>
          </thead>
          <tbody>
            {specs.map((s, i) => (
              <tr key={s} style={{ background: i % 2 === 0 ? 'rgba(255,255,255,0.02)' : 'transparent' }}>
                <td style={{ padding: '12px 12px', fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.5)', whiteSpace: 'nowrap' }}>{specLabels[s]}</td>
                {products.map(p => (
                  <td key={p.id} style={{ padding: '12px 12px', textAlign: 'center', fontFamily: 'DM Sans', fontSize: 13, color: 'white', borderLeft: '1px solid rgba(255,255,255,0.06)' }}>
                    {s === 'certs' ? p[s].join(', ') : p[s]}
                  </td>
                ))}
              </tr>
            ))}
            {/* Solutions row */}
            <tr style={{ background: 'rgba(255,255,255,0.02)' }}>
              <td style={{ padding: '12px', fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>Solutions</td>
              {products.map(p => (
                <td key={p.id} style={{ padding: '12px', textAlign: 'center', borderLeft: '1px solid rgba(255,255,255,0.06)' }}>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, justifyContent: 'center' }}>
                    {p.solutions.map(s => <span key={s} style={{ background: 'rgba(232,93,38,0.12)', border: '1px solid rgba(232,93,38,0.25)', borderRadius: 4, padding: '2px 6px', fontFamily: 'DM Sans', fontSize: 10, color: '#e85d26' }}>{s}</span>)}
                  </div>
                </td>
              ))}
            </tr>
            {/* CTA row */}
            <tr>
              <td style={{ padding: '16px 12px' }}></td>
              {products.map(p => (
                <td key={p.id} style={{ padding: '16px 12px', textAlign: 'center', borderLeft: '1px solid rgba(255,255,255,0.06)' }}>
                  <button onClick={() => { navigate('product', p); onClose(); }} style={{ background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 6, padding: '8px 16px', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'white' }}>View Details</button>
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </Modal>
  );
}

Object.assign(window, { LoginModal, EnquiryModal, CompareModal });
