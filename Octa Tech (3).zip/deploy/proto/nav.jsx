// nav.jsx — Navigation with search, mobile menu, scroll effect
const { useState, useEffect, useRef } = React;

function NavBar({ currentPage, navigate, openLogin, compareCount, openCompare }) {
  const { isMobile, isTablet } = window.useBreakpoint();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const searchRef = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (query.length > 1) {
      const q = query.toLowerCase();
      const hits = window.OctaData.products
        .filter(p => p.name.toLowerCase().includes(q) || p.category.includes(q) || p.tagline.toLowerCase().includes(q))
        .slice(0, 5);
      setSuggestions(hits);
    } else {
      setSuggestions([]);
    }
  }, [query]);

  useEffect(() => {
    const handler = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setSearchOpen(false);
        setQuery('');
        setSuggestions([]);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const cats = window.OctaData.categories;

  const navBg = scrolled
    ? 'rgba(8,17,31,0.97)'
    : currentPage === 'home' ? 'transparent' : 'rgba(8,17,31,0.97)';

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
        background: navBg,
        backdropFilter: scrolled ? 'blur(12px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(255,255,255,0.07)' : 'none',
        transition: 'all 0.3s ease',
        padding: '0 40px',
        height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        {/* Logo */}
        <button onClick={() => navigate('home')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, background: 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <span style={{ fontSize: 16, fontWeight: 900, color: 'white', fontFamily: 'Space Grotesk, sans-serif' }}>O</span>
          </div>
          <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 17, fontWeight: 700, color: 'white', letterSpacing: '-0.3px' }}>OCTA TECH</span>
        </button>

        {/* Desktop nav links */}
        <div className="nav-desktop" style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
          {[
            { label: 'Products', page: 'catalog' },
            { label: 'About', page: 'about' },
            { label: 'Contact', page: 'contact' },
          ].map(({ label, page }) => (
            <button key={page} onClick={() => navigate(page)} style={{
              background: 'none', border: 'none', cursor: 'pointer', padding: '4px 0',
              fontFamily: 'DM Sans, sans-serif', fontSize: 14, fontWeight: 500,
              color: currentPage === page ? '#e85d26' : 'rgba(255,255,255,0.78)',
              borderBottom: currentPage === page ? '1.5px solid #e85d26' : '1.5px solid transparent',
              transition: 'color 0.2s',
            }}>{label}</button>
          ))}
        </div>

        {/* Right: search + compare + login */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          {/* Search */}
          <div ref={searchRef} style={{ position: 'relative' }}>
            <button onClick={() => { setSearchOpen(!searchOpen); setTimeout(() => document.getElementById('nav-search')?.focus(), 50); }}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.7)', fontSize: 18, padding: 4, transition: 'color 0.2s' }}>
              🔍
            </button>
            {searchOpen && (
              <div style={{
                position: 'absolute', right: 0, top: '120%',
                background: '#0d1929', border: '1px solid rgba(255,255,255,0.12)',
                borderRadius: 8, overflow: 'hidden', width: 320,
                boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
                animation: 'fadeDown 0.15s ease',
              }}>
                <div style={{ padding: '10px 14px', borderBottom: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 14, opacity: 0.5 }}>🔍</span>
                  <input id="nav-search" value={query} onChange={e => setQuery(e.target.value)}
                    placeholder="Search products, categories..."
                    style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 14 }} />
                </div>
                {suggestions.length > 0 ? (
                  suggestions.map(p => (
                    <button key={p.id} onClick={() => { navigate('product', p); setSearchOpen(false); setQuery(''); }}
                      style={{ display: 'block', width: '100%', padding: '10px 14px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', borderBottom: '1px solid rgba(255,255,255,0.05)', transition: 'background 0.15s' }}
                      onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
                      onMouseOut={e => e.currentTarget.style.background = 'none'}>
                      <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'white' }}>{p.name}</div>
                      <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>{p.category.replace(/-/g, ' ').toUpperCase()}</div>
                    </button>
                  ))
                ) : query.length > 1 ? (
                  <div style={{ padding: '14px', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.4)', textAlign: 'center' }}>No results found</div>
                ) : (
                  <div style={{ padding: '12px 14px' }}>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.3)', marginBottom: 8, letterSpacing: 1 }}>POPULAR</div>
                    {['Cable Glands', 'Industrial Relays', 'Heavy Duty Connectors'].map(s => (
                      <button key={s} onClick={() => setQuery(s)} style={{ display: 'block', width: '100%', padding: '6px 0', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>
                        🕐 {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Compare button */}
          {compareCount > 0 && (
            <button onClick={openCompare} style={{
              background: 'rgba(232,93,38,0.15)', border: '1px solid rgba(232,93,38,0.4)',
              borderRadius: 6, padding: '5px 12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: '#e85d26' }}>Compare ({compareCount})</span>
            </button>
          )}

          {/* PRO Login */}
          <button onClick={openLogin} style={{
            background: 'linear-gradient(135deg, #e85d26, #ff7a45)',
            border: 'none', borderRadius: 6, padding: '7px 16px', cursor: 'pointer',
            fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, color: 'white',
            transition: 'opacity 0.2s', boxShadow: '0 2px 12px rgba(232,93,38,0.3)',
          }}>Sign in PRO</button>

          {/* Hamburger */}
          <button className="nav-mobile-btn" onClick={() => setMenuOpen(!menuOpen)} style={{ display: 'none', background: 'none', border: 'none', cursor: 'pointer', color: 'white', fontSize: 22 }}>☰</button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {menuOpen && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 999, background: '#08111f',
          paddingTop: 64, animation: 'fadeIn 0.2s ease',
        }}>
          <div style={{ padding: '24px 24px' }}>
            <div style={{ marginBottom: 8, padding: '10px 14px', background: 'rgba(255,255,255,0.05)', borderRadius: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
              <span>🔍</span>
              <input placeholder="Search..." style={{ background: 'none', border: 'none', outline: 'none', color: 'white', fontFamily: 'DM Sans', fontSize: 15, flex: 1 }} />
            </div>
            {[{ label: 'Products', page: 'catalog' }, { label: 'About', page: 'about' }, { label: 'Contact', page: 'contact' }].map(({ label, page }) => (
              <button key={page} onClick={() => { navigate(page); setMenuOpen(false); }} style={{
                display: 'block', width: '100%', padding: '16px 0', background: 'none', border: 'none', borderBottom: '1px solid rgba(255,255,255,0.06)', cursor: 'pointer', textAlign: 'left', fontFamily: 'Space Grotesk, sans-serif', fontSize: 20, fontWeight: 600, color: 'white',
              }}>{label}</button>
            ))}
            <button onClick={() => { openLogin(); setMenuOpen(false); }} style={{ marginTop: 24, width: '100%', padding: 14, background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 8, fontFamily: 'DM Sans', fontSize: 15, fontWeight: 600, color: 'white', cursor: 'pointer' }}>
              Sign in to PRO
            </button>
          </div>
        </div>
      )}
    </>
  );
}

Object.assign(window, { NavBar });
