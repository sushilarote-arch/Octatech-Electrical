// product-detail.jsx
const { useState, useEffect, useRef } = React;

function ProductDetailPage({ product, navigate, openEnquiry, openLogin, compareList, onCompare }) {
  const { isMobile, isTablet } = window.useBreakpoint();
  const [activeTab, setActiveTab] = useState('overview');
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    window.scrollTo(0, 0);
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [product]);

  const related = window.OctaData.products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const cat = window.OctaData.categories.find(c => c.id === product.category);
  const inCompare = compareList.some(p => p.id === product.id);

  return (
    <div style={{ background: '#08111f', minHeight: '100vh', paddingTop: 64 }}>
      {/* Breadcrumb */}
      <div style={{ background: '#0d1929', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: isMobile ? '12px 20px' : '12px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {[
            { label: 'Home', action: () => navigate('home') },
            { label: 'Products', action: () => navigate('catalog') },
            { label: cat?.label || product.category, action: () => navigate('catalog', { category: product.category }) },
            { label: product.name, action: null },
          ].map((b, i, arr) => (
            <span key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {b.action ? (
                <button onClick={b.action} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.4)', padding: 0, transition: 'color 0.2s' }}
                  onMouseOver={e => e.currentTarget.style.color = 'rgba(255,255,255,0.7)'}
                  onMouseOut={e => e.currentTarget.style.color = 'rgba(255,255,255,0.4)'}>{b.label}</button>
              ) : (
                <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{b.label}</span>
              )}
              {i < arr.length - 1 && <span style={{ color: 'rgba(255,255,255,0.2)', fontSize: 12 }}>›</span>}
            </span>
          ))}
        </div>
      </div>

      {/* Hero section */}
      <div style={{ background: 'linear-gradient(180deg, #0d1929 0%, #08111f 100%)', padding: isMobile ? '24px 20px 0' : '48px 48px 0' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', flexDirection: isMobile ? 'column' : 'row', gap: isMobile ? 24 : 48, alignItems: 'flex-start' }}>
          {/* Left: Image + thumbnails */}
          <div style={{ width: isMobile ? '100%' : 360, flexShrink: 0 }}>
            {/* Main image */}
            <div style={{
              height: 300, background: 'linear-gradient(135deg, #1e3358, #0f2040)',
              borderRadius: 16, border: '1px solid rgba(255,255,255,0.08)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              position: 'relative', overflow: 'hidden',
              boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
            }}>
              <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 60% 40%, rgba(232,93,38,0.06) 0%, transparent 70%)' }} />
              <div style={{ fontSize: 80, filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.4))' }}>{cat?.icon || '⚙️'}</div>
              {product.badge && (
                <div style={{ position: 'absolute', top: 14, left: 14, background: product.badge === 'New' ? '#16a34a' : 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 6, padding: '4px 10px', fontFamily: 'DM Sans', fontSize: 11, fontWeight: 700, color: 'white' }}>{product.badge}</div>
              )}
            </div>
            {/* Thumbnails */}
            <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
              {[1, 2, 3].map(i => (
                <div key={i} style={{ flex: 1, height: 70, background: '#0d1929', border: `1px solid ${i === 1 ? '#e85d26' : 'rgba(255,255,255,0.08)'}`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: 24, transition: 'border-color 0.2s' }}>{cat?.icon}</div>
              ))}
            </div>
            {/* Available sizes */}
            {product.specs && (
              <div style={{ marginTop: 20, background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 12, padding: '16px' }}>
                <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>AVAILABLE IN</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {product.industry.map(ind => {
                    const indObj = window.OctaData.industries.find(x => x.id === ind);
                    return indObj ? <span key={ind} style={{ background: 'rgba(232,93,38,0.08)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 6, padding: '3px 10px', fontFamily: 'DM Sans', fontSize: 11, color: '#e85d26' }}>{indObj.label}</span> : null;
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Right: Product info */}
          <div style={{ flex: 1, minWidth: 0, paddingBottom: 32 }}>
            {/* Tags */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
              <span style={{ background: 'rgba(232,93,38,0.12)', border: '1px solid rgba(232,93,38,0.25)', borderRadius: 6, padding: '3px 10px', fontFamily: 'DM Sans', fontSize: 11, fontWeight: 600, color: '#e85d26' }}>{cat?.label}</span>
              {product.certs.map(c => (
                <span key={c} style={{ border: '1px solid rgba(255,255,255,0.12)', borderRadius: 6, padding: '3px 10px', fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.45)' }}>{c}</span>
              ))}
            </div>

            <h1 style={{ fontFamily: 'Space Grotesk', fontSize: isMobile ? 24 : 32, fontWeight: 800, color: 'white', margin: '0 0 8px', lineHeight: 1.15 }}>{product.name}</h1>
            <p style={{ fontFamily: 'DM Sans', fontSize: 16, color: 'rgba(255,255,255,0.5)', lineHeight: 1.7, margin: '0 0 28px', maxWidth: 520 }}>{product.description}</p>

            {/* Key specs strip */}
            <div style={{ display: 'flex', gap: 16, marginBottom: 28, flexWrap: 'wrap' }}>
              {[
                ['🌡️', 'Temperature', product.temperature],
                ['🛡️', 'IP Rating', product.ipRating],
                ['🔧', 'Material', product.material.split(',')[0]],
              ].map(([icon, label, val]) => (
                <div key={label} style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 18 }}>{icon}</span>
                  <div>
                    <div style={{ fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.3)', marginBottom: 2 }}>{label}</div>
                    <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'white', fontWeight: 500 }}>{val}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 28, flexWrap: 'wrap' }}>
              <button onClick={() => openEnquiry(product)} style={{
                padding: '13px 28px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)',
                border: 'none', borderRadius: 10, cursor: 'pointer',
                fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white',
                boxShadow: '0 4px 20px rgba(232,93,38,0.3)', transition: 'all 0.2s',
              }}
                onMouseOver={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 8px 30px rgba(232,93,38,0.4)'; }}
                onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(232,93,38,0.3)'; }}>
                Request Information
              </button>
              <button onClick={() => openLogin()} style={{
                padding: '13px 20px', background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, cursor: 'pointer',
                fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.7)',
                display: 'flex', alignItems: 'center', gap: 8, transition: 'all 0.2s',
              }}
                onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.09)'}
                onMouseOut={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}>
                🔒 <span>Technical Data Sheet <span style={{ fontSize: 11, color: '#e85d26' }}>PRO</span></span>
              </button>
              <button onClick={() => onCompare(product)} style={{
                padding: '13px 16px', background: inCompare ? 'rgba(232,93,38,0.12)' : 'rgba(255,255,255,0.03)',
                border: `1px solid ${inCompare ? 'rgba(232,93,38,0.4)' : 'rgba(255,255,255,0.1)'}`,
                borderRadius: 10, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 13,
                color: inCompare ? '#e85d26' : 'rgba(255,255,255,0.5)', transition: 'all 0.2s',
              }}>
                {inCompare ? '✓ Added to Compare' : '+ Compare'}
              </button>
            </div>

            {/* Solutions */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>SOLUTIONS</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {product.solutions.map(s => (
                  <div key={s} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#e85d26' }} />
                    <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.65)' }}>{s}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Applications */}
            <div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>APPLICATIONS</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {product.applications.map(a => (
                  <span key={a} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 6, padding: '4px 10px', fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{a}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab nav */}
      <div style={{ background: '#0d1929', borderBottom: '1px solid rgba(255,255,255,0.06)', position: 'sticky', top: 64, zIndex: 100 }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px', display: 'flex', gap: 0, overflowX: 'auto' }}>
          {['overview', 'specifications', 'downloads'].map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)} style={{
              background: 'none', border: 'none', cursor: 'pointer', padding: '14px 20px',
              fontFamily: 'DM Sans', fontSize: 14, fontWeight: 500,
              color: activeTab === tab ? 'white' : 'rgba(255,255,255,0.4)',
              borderBottom: activeTab === tab ? '2px solid #e85d26' : '2px solid transparent',
              marginBottom: -1, transition: 'all 0.2s', textTransform: 'capitalize',
            }}>{tab}</button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '24px 20px' : '40px 48px' }}>
        {activeTab === 'overview' && (
          <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', gap: isMobile ? 20 : 32 }}>
            <div>
              <h3 style={{ fontFamily: 'Space Grotesk', fontSize: 20, fontWeight: 700, color: 'white', margin: '0 0 20px' }}>Technical Specifications</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {Object.entries(product.specs || {}).map(([k, v], i) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 16px', background: i % 2 === 0 ? 'rgba(255,255,255,0.02)' : 'transparent', borderRadius: 6 }}>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.45)' }}>{k}</span>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'white', fontWeight: 500, textAlign: 'right', maxWidth: '55%' }}>{v}</span>
                  </div>
                ))}
                {[['Material', product.material], ['Temperature Range', product.temperature], ['IP Rating', product.ipRating]].map(([k, v], i) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 16px', background: (Object.keys(product.specs || {}).length + i) % 2 === 0 ? 'rgba(255,255,255,0.02)' : 'transparent', borderRadius: 6 }}>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.45)' }}>{k}</span>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'white', fontWeight: 500, textAlign: 'right', maxWidth: '55%' }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 style={{ fontFamily: 'Space Grotesk', fontSize: 20, fontWeight: 700, color: 'white', margin: '0 0 20px' }}>Certifications</h3>
              <div style={{ display: 'grid', gridTemplateColumns: isMobile ? 'repeat(2,1fr)' : 'repeat(3,1fr)', gap: 10, marginBottom: 28 }}>
                {product.certs.map(c => (
                  <div key={c} style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, padding: '16px 12px', textAlign: 'center', transition: 'border-color 0.2s' }}
                    onMouseOver={e => e.currentTarget.style.borderColor = 'rgba(232,93,38,0.3)'}
                    onMouseOut={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}>
                    <div style={{ fontFamily: 'Space Grotesk', fontSize: 18, fontWeight: 800, color: 'white', marginBottom: 4 }}>{c}</div>
                    <div style={{ width: 20, height: 2, background: '#e85d26', borderRadius: 1, margin: '0 auto' }} />
                  </div>
                ))}
              </div>
              <div style={{ background: 'rgba(232,93,38,0.06)', border: '1px solid rgba(232,93,38,0.15)', borderRadius: 12, padding: '20px' }}>
                <div style={{ fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 6 }}>Need a technical data sheet?</div>
                <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.5)', marginBottom: 14, lineHeight: 1.5 }}>Full specifications are available to PRO account holders. Request access or sign in.</div>
                <button onClick={openLogin} style={{ padding: '9px 18px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 8, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 13, fontWeight: 600, color: 'white' }}>Sign in to PRO →</button>
              </div>
            </div>
          </div>
        )}
        {activeTab === 'specifications' && (
          <div style={{ maxWidth: 700 }}>
            <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', gap: 12 }}>
              {[...Object.entries(product.specs || {}), ['Material', product.material], ['Temperature', product.temperature], ['IP Rating', product.ipRating], ['Certifications', product.certs.join(', ')]].map(([k, v], i) => (
                <div key={k + i} style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 10, padding: '14px 16px' }}>
                  <div style={{ fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.3)', marginBottom: 6, letterSpacing: 1 }}>{k.toUpperCase()}</div>
                  <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'white', fontWeight: 500 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        )}
        {activeTab === 'downloads' && (
          <div style={{ maxWidth: 600 }}>
            {[['Technical Data Sheet', 'PDF · 2.4 MB', true], ['Installation Guide', 'PDF · 1.1 MB', true], ['Certification Docs', 'ZIP · 3.8 MB', false]].map(([name, size, locked]) => (
              <div key={name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#0d1929', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 10, padding: '16px 20px', marginBottom: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 36, background: locked ? 'rgba(232,93,38,0.1)' : 'rgba(255,255,255,0.05)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>{locked ? '🔒' : '📄'}</div>
                  <div>
                    <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'white', marginBottom: 2 }}>{name}</div>
                    <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)' }}>{size}</div>
                  </div>
                </div>
                <button onClick={locked ? openLogin : null} style={{ padding: '7px 16px', background: locked ? 'rgba(232,93,38,0.12)' : 'rgba(255,255,255,0.07)', border: `1px solid ${locked ? 'rgba(232,93,38,0.3)' : 'rgba(255,255,255,0.12)'}`, borderRadius: 6, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: locked ? '#e85d26' : 'white' }}>
                  {locked ? 'PRO Access' : '↓ Download'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <div style={{ background: '#0a1525', borderTop: '1px solid rgba(255,255,255,0.04)', padding: isMobile ? '32px 0 40px' : '48px 0 60px' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: isMobile ? '0 20px' : '0 48px' }}>
            <h3 style={{ fontFamily: 'Space Grotesk', fontSize: isMobile ? 20 : 24, fontWeight: 700, color: 'white', margin: '0 0 24px' }}>Related Products</h3>
            <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr 1fr' : 'repeat(4, 1fr)', gap: isMobile ? 10 : 14 }}>
              {related.map(p => <ProductCard key={p.id} product={p} onCompare={onCompare} compareList={compareList} navigate={navigate} openEnquiry={openEnquiry} />)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { ProductDetailPage });
