// responsive.jsx — Shared breakpoint hook for both public site and admin
// Provides: useBreakpoint() → returns { isMobile, isTablet, isDesktop, width }

(function() {
  if (typeof window === 'undefined') return;

  // We attach this BEFORE React is consumed so order matters.
  // Used in JSX components: const { isMobile, isTablet } = useBreakpoint();
  window.useBreakpoint = function useBreakpoint() {
    const { useState, useEffect } = React;
    const [size, setSize] = useState(() => ({
      width: typeof window !== 'undefined' ? window.innerWidth : 1440,
    }));

    useEffect(() => {
      const onResize = () => setSize({ width: window.innerWidth });
      window.addEventListener('resize', onResize, { passive: true });
      return () => window.removeEventListener('resize', onResize);
    }, []);

    return {
      width: size.width,
      isMobile: size.width < 768,
      isTablet: size.width >= 768 && size.width < 1024,
      isDesktop: size.width >= 1024,
      isMobileOrTablet: size.width < 1024,
    };
  };
})();
