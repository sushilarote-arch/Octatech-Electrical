# API Specification

Recommended REST API endpoints for the Octa Tech backend.

> **Base URL (production):** `https://api.octatechelectricals.com/v1`  
> **Base URL (dev):** `http://localhost:3000/api/v1`

---

## Authentication

All admin endpoints require JWT bearer token in the `Authorization` header.

```
Authorization: Bearer <jwt-token>
```

PRO user endpoints similarly require a JWT issued at login (`/auth/pro/login`).

Public endpoints (catalog, product detail) are open and don't require auth.

---

## Public Endpoints (No auth required)

### Products

#### GET `/products`
List all products with filters.

**Query parameters:**
- `industry` (string) — `'automotive' | 'industrial' | 'railway' | 'infrastructure'`
- `category` (string) — category slug
- `solutions` (string[]) — comma-separated
- `applications` (string[]) — comma-separated
- `search` (string) — search query
- `featured` (boolean) — only featured products
- `limit` (number, default 24) — pagination
- `offset` (number, default 0) — pagination
- `sort` (string) — `'name' | 'newest' | 'popular'`

**Response 200:**
```json
{
  "data": [
    {
      "id": 1,
      "slug": "brass-double-compression",
      "name": "Brass Double Compression Gland",
      "tagline": "IP68 rated dual-seal cable entry",
      "category": { "slug": "cable-glands", "label": "Cable Glands", "icon": "🔌" },
      "industries": ["industrial", "automotive"],
      "certifications": ["UL", "CE", "ATEX"],
      "featured": true,
      "badge": "Featured",
      "main_image_url": "https://res.cloudinary.com/...",
      "temperature": "-40°C to +120°C",
      "ip_rating": "IP68 / IP69K"
    }
  ],
  "meta": {
    "total": 150,
    "limit": 24,
    "offset": 0
  }
}
```

#### GET `/products/:slug`
Get product detail by slug.

**Response 200:**
```json
{
  "id": 1,
  "slug": "brass-double-compression",
  "name": "Brass Double Compression Gland",
  "tagline": "...",
  "description": "Full description...",
  "category": { ... },
  "industries": [ ... ],
  "certifications": [ ... ],
  "solutions": [ ... ],
  "applications": [ ... ],
  "specs": { "Thread": "M20 × 1.5", "Cable Range": "7–13mm" },
  "material": "Brass (nickel plated)",
  "temperature": "-40°C to +120°C",
  "ip_rating": "IP68 / IP69K",
  "images": [
    { "url": "...", "alt": "..." }
  ],
  "documents": [
    { "name": "TDS", "url": "...", "is_pro_only": true }
  ],
  "related": [ ... ]
}
```

#### GET `/products/:slug/related`
Related products (same category).

---

### Categories

#### GET `/categories`
List all categories.

#### GET `/categories/:slug`
Category detail + product list.

---

### Industries

#### GET `/industries`
List all industries with product counts.

---

### Enquiries (Public submission)

#### POST `/enquiries`
Submit an enquiry from the contact form or product page.

**Request body:**
```json
{
  "name": "Rajesh Kumar",
  "email": "rajesh@example.com",
  "phone": "+91 98765 43210",
  "company": "Tata Motors",
  "product_slug": "brass-double-compression",   // optional
  "message": "Need 2000 units of M20 size..."
}
```

**Response 201:**
```json
{
  "id": 1234,
  "status": "received",
  "message": "Thank you! We'll respond within 24 hours."
}
```

**Side effects:**
- Saves to `enquiries` table
- Sends email to `info@octatechelectricals.com`
- Sends confirmation email to user
- Triggers WhatsApp notification (optional)

---

### Search

#### GET `/search?q=<query>`
Live search across products.

**Response 200:**
```json
{
  "products": [ { ... }, ... ],
  "suggestions": ["brass cable gland", "industrial relay", ...]
}
```

---

## PRO User Endpoints

### Auth

#### POST `/auth/pro/login`
```json
{ "email": "user@company.com", "password": "..." }
```
**Response 200:**
```json
{ "user": { ... }, "token": "eyJhbGc..." }
```

#### POST `/auth/pro/register`
Request a PRO account (creates pending user).
```json
{ "name": "...", "email": "...", "company": "...", "phone": "...", "message": "..." }
```
**Response 201:** Confirmation message; admin must approve.

#### POST `/auth/pro/forgot-password`

#### POST `/auth/pro/reset-password`

#### POST `/auth/pro/logout`

#### GET `/auth/pro/me`
Get current logged-in PRO user.

### Downloads

#### GET `/products/:slug/documents/:doc_id/download`
Download a PRO-gated document (TDS, etc.). Requires PRO auth.

---

## Admin Endpoints (require admin JWT)

> All `/admin/*` routes require Authorization header with admin token.  
> Role-based permission middleware should enforce access per endpoint.

### Admin Auth

#### POST `/auth/admin/login`
```json
{ "email": "admin@octatechelectricals.com", "password": "..." }
```

#### POST `/auth/admin/logout`

#### GET `/auth/admin/me`

### Dashboard

#### GET `/admin/dashboard/summary`
```json
{
  "summary": {
    "total_views": 12847,
    "views_delta": 18.4,
    "total_enquiries": 234,
    "enquiries_delta": 7.2,
    "new_pro_users": 28,
    "pro_users_delta": 12.5,
    "catalog_downloads": 89,
    "downloads_delta": -3.1
  }
}
```

#### GET `/admin/dashboard/trends?range=7d`
Views & enquiries trend data.

#### GET `/admin/dashboard/top-products?limit=10`

#### GET `/admin/dashboard/industries-share`

#### GET `/admin/dashboard/activity?limit=20`
Recent activity feed.

---

### Products (Admin CRUD)

#### POST `/admin/products`
Create new product.

#### PUT `/admin/products/:id`
Update.

#### DELETE `/admin/products/:id`

#### POST `/admin/products/:id/images`
Upload images (multipart/form-data, multiple files).

#### DELETE `/admin/products/:id/images/:image_id`

#### POST `/admin/products/bulk-import`
CSV/Excel upload.

**Request:** multipart/form-data with `file` field.

**Response 200:**
```json
{
  "preview": {
    "valid_rows": 47,
    "update_rows": 3,
    "error_rows": 0,
    "sample": [ { ... }, ... ],
    "import_token": "abc-123"
  }
}
```

#### POST `/admin/products/bulk-import/confirm`
```json
{ "import_token": "abc-123" }
```

#### GET `/admin/products/export?format=csv&columns=basic,specs,certs`
Returns file download.

---

### Taxonomy (Admin)

#### CRUD `/admin/categories`
- GET (list), POST (create), PUT `/:id`, DELETE `/:id`

#### CRUD `/admin/industries`

#### CRUD `/admin/certifications`

#### CRUD `/admin/solutions`

#### CRUD `/admin/applications`

---

### Enquiries (Admin)

#### GET `/admin/enquiries?status=new&assigned_to=me&search=tata`

#### GET `/admin/enquiries/:id`

#### PATCH `/admin/enquiries/:id`
Update status, priority, assignee.
```json
{ "status": "in-progress", "assigned_to": 2, "priority": "high" }
```

#### POST `/admin/enquiries/:id/reply`
Reply via email.
```json
{ "body": "Thank you for your enquiry...", "attachments": [] }
```

#### DELETE `/admin/enquiries/:id`

---

### PRO User Management (Admin)

#### GET `/admin/pro-users?status=pending&search=tata`

#### GET `/admin/pro-users/:id`

#### POST `/admin/pro-users/:id/approve`

#### POST `/admin/pro-users/:id/reject`

#### POST `/admin/pro-users/:id/suspend`

#### POST `/admin/pro-users/invite`
```json
{ "email": "...", "name": "...", "company": "..." }
```

---

### Admin User Management

#### GET `/admin/users`

#### POST `/admin/users/invite`
```json
{ "email": "...", "name": "...", "role": "editor" }
```
Sends invite email with magic link.

#### PUT `/admin/users/:id`
```json
{ "role": "super-admin", "status": "active" }
```

#### POST `/admin/users/:id/reset-password`

---

### Content Editor

#### GET `/admin/pages/homepage`
```json
{
  "hero": {
    "overline": "INDIA'S LEADING DISTRIBUTOR",
    "headline": "...",
    "description": "...",
    "cta_primary": "Browse Catalog",
    "cta_secondary": "Get a Quote"
  },
  "stats": [
    { "value": "150+", "label": "Products" }, ...
  ]
}
```

#### PUT `/admin/pages/homepage`
Update homepage content.

#### GET `/admin/pages/about` / PUT

---

### Settings

#### GET `/admin/settings`
#### PUT `/admin/settings`

```json
{
  "company": { "name": "...", "email": "...", "phone": "...", "address": "..." },
  "notifications": {
    "email_new_enquiry": true,
    "email_new_pro_user": true,
    "weekly_summary": true
  },
  "integrations": {
    "google_analytics_id": "G-XXXXXXX",
    "whatsapp_number": "+917066711811"
  }
}
```

---

## Implementation Notes

### Pagination
Use `limit` + `offset` for simple pagination, OR cursor-based with `cursor` for infinite scroll.

### Errors
All errors follow this shape:
```json
{
  "error": {
    "code": "validation_error",
    "message": "Email is required",
    "details": { "field": "email" }
  }
}
```

HTTP status codes:
- 400 — Validation error
- 401 — Not authenticated
- 403 — Forbidden (auth'd but no permission)
- 404 — Not found
- 422 — Unprocessable (business rule violation)
- 500 — Server error

### Rate Limiting
- Public endpoints: 60 req/min per IP
- Auth endpoints: 5 req/min per IP (to prevent brute force)
- Admin endpoints: 200 req/min per user

### Caching
- Product list/detail: Cache 5 min (invalidate on edit)
- Categories/industries/certs: Cache 1 hour
- Dashboard summary: Cache 1 min

### CORS
Allow origins: `https://octatechelectricals.com`, `https://www.octatechelectricals.com`, `https://admin.octatechelectricals.com`
