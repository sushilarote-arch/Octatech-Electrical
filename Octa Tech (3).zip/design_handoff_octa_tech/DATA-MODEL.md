# Database Schema Recommendations

This document outlines the recommended database structure for the Octa Tech platform. Schema is shown in SQL-like syntax but adaptable to any RDBMS (PostgreSQL preferred, MySQL works too).

---

## Tables

### `products`
```sql
CREATE TABLE products (
    id              SERIAL PRIMARY KEY,
    slug            VARCHAR(255) UNIQUE NOT NULL,
    name            VARCHAR(255) NOT NULL,
    tagline         VARCHAR(500),
    description     TEXT,
    category_id     INTEGER REFERENCES categories(id),
    material        VARCHAR(255),
    temperature     VARCHAR(100),
    ip_rating       VARCHAR(50),
    specs           JSONB,           -- Custom key-value specs
    is_featured     BOOLEAN DEFAULT false,
    badge           VARCHAR(20),     -- 'New', 'Featured', 'Custom Built', etc.
    status          VARCHAR(20) DEFAULT 'active', -- 'active', 'draft', 'archived'
    meta_title      VARCHAR(255),
    meta_description TEXT,
    view_count      INTEGER DEFAULT 0,
    enquiry_count   INTEGER DEFAULT 0,
    created_by      INTEGER REFERENCES admin_users(id),
    updated_by      INTEGER REFERENCES admin_users(id),
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_products_slug ON products(slug);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_featured ON products(is_featured);
CREATE INDEX idx_products_status ON products(status);
```

### `categories`
```sql
CREATE TABLE categories (
    id           SERIAL PRIMARY KEY,
    slug         VARCHAR(100) UNIQUE NOT NULL,
    label        VARCHAR(255) NOT NULL,
    icon         VARCHAR(50),     -- Emoji or icon class name
    description  TEXT,
    display_order INTEGER DEFAULT 0,
    created_at   TIMESTAMP DEFAULT NOW(),
    updated_at   TIMESTAMP DEFAULT NOW()
);
```

### `industries`
```sql
CREATE TABLE industries (
    id           SERIAL PRIMARY KEY,
    slug         VARCHAR(100) UNIQUE NOT NULL,
    label        VARCHAR(255) NOT NULL,
    icon         VARCHAR(50),
    description  TEXT,
    display_order INTEGER DEFAULT 0,
    created_at   TIMESTAMP DEFAULT NOW()
);
```

### `certifications`
```sql
CREATE TABLE certifications (
    id           SERIAL PRIMARY KEY,
    code         VARCHAR(20) UNIQUE NOT NULL,  -- 'UL', 'CE', 'ATEX', etc.
    label        VARCHAR(100) NOT NULL,
    region       VARCHAR(50),     -- 'Europe', 'North America', 'Global'
    issuer       VARCHAR(255),
    logo_url     VARCHAR(500),
    description  TEXT,
    created_at   TIMESTAMP DEFAULT NOW()
);
```

### `solutions`
```sql
CREATE TABLE solutions (
    id      SERIAL PRIMARY KEY,
    slug    VARCHAR(100) UNIQUE NOT NULL,
    label   VARCHAR(255) NOT NULL,
    icon    VARCHAR(50)
);
```

### `applications`
```sql
CREATE TABLE applications (
    id      SERIAL PRIMARY KEY,
    slug    VARCHAR(100) UNIQUE NOT NULL,
    label   VARCHAR(255) NOT NULL,
    icon    VARCHAR(50)
);
```

### Pivot Tables (many-to-many)
```sql
CREATE TABLE product_categories (
    product_id  INTEGER REFERENCES products(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id),
    PRIMARY KEY (product_id, category_id)
);

CREATE TABLE product_industries (
    product_id  INTEGER REFERENCES products(id) ON DELETE CASCADE,
    industry_id INTEGER REFERENCES industries(id),
    PRIMARY KEY (product_id, industry_id)
);

CREATE TABLE product_certifications (
    product_id   INTEGER REFERENCES products(id) ON DELETE CASCADE,
    cert_id      INTEGER REFERENCES certifications(id),
    PRIMARY KEY (product_id, cert_id)
);

CREATE TABLE product_solutions (
    product_id  INTEGER REFERENCES products(id) ON DELETE CASCADE,
    solution_id INTEGER REFERENCES solutions(id),
    PRIMARY KEY (product_id, solution_id)
);

CREATE TABLE product_applications (
    product_id     INTEGER REFERENCES products(id) ON DELETE CASCADE,
    application_id INTEGER REFERENCES applications(id),
    PRIMARY KEY (product_id, application_id)
);

CREATE TABLE category_industries (
    category_id  INTEGER REFERENCES categories(id) ON DELETE CASCADE,
    industry_id  INTEGER REFERENCES industries(id),
    PRIMARY KEY (category_id, industry_id)
);
```

### `product_images`
```sql
CREATE TABLE product_images (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER REFERENCES products(id) ON DELETE CASCADE,
    url         VARCHAR(500) NOT NULL,
    alt_text    VARCHAR(255),
    is_main     BOOLEAN DEFAULT false,
    display_order INTEGER DEFAULT 0,
    file_size_kb INTEGER,
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_product_images_product ON product_images(product_id);
```

### `product_documents`
For TDS PDFs, installation guides, certs (PRO-gated)
```sql
CREATE TABLE product_documents (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER REFERENCES products(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    file_url    VARCHAR(500) NOT NULL,
    file_type   VARCHAR(20),     -- 'pdf', 'zip', etc.
    file_size_kb INTEGER,
    is_pro_only BOOLEAN DEFAULT true,
    download_count INTEGER DEFAULT 0,
    uploaded_at TIMESTAMP DEFAULT NOW()
);
```

---

### `pro_users`
```sql
CREATE TABLE pro_users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    company         VARCHAR(255),
    phone           VARCHAR(50),
    status          VARCHAR(20) DEFAULT 'pending', -- 'pending', 'active', 'rejected', 'suspended'
    is_verified     BOOLEAN DEFAULT false,
    verified_at     TIMESTAMP,
    enquiry_count   INTEGER DEFAULT 0,
    download_count  INTEGER DEFAULT 0,
    last_login_at   TIMESTAMP,
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_pro_users_email ON pro_users(email);
CREATE INDEX idx_pro_users_status ON pro_users(status);
```

### `admin_users`
```sql
CREATE TABLE admin_users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    role            VARCHAR(50) NOT NULL,   -- 'super-admin', 'editor', 'viewer'
    avatar_url      VARCHAR(500),
    status          VARCHAR(20) DEFAULT 'active', -- 'active', 'inactive', 'suspended'
    last_login_at   TIMESTAMP,
    invited_by      INTEGER REFERENCES admin_users(id),
    created_at      TIMESTAMP DEFAULT NOW()
);
```

### `roles` + `permissions`
```sql
CREATE TABLE roles (
    id          VARCHAR(50) PRIMARY KEY,    -- 'super-admin', 'editor', 'viewer'
    label       VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '[]'
);

INSERT INTO roles VALUES
    ('super-admin', 'Super Admin', 'Full access', '["all"]'),
    ('editor',      'Editor',      'Manage products, content, taxonomy', '["products:*","content:*","taxonomy:*","enquiries:read","enquiries:reply"]'),
    ('viewer',      'Viewer',      'Read-only access', '["*:read"]');
```

---

### `enquiries`
```sql
CREATE TABLE enquiries (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    email       VARCHAR(255) NOT NULL,
    phone       VARCHAR(50),
    company     VARCHAR(255),
    product_id  INTEGER REFERENCES products(id),
    message     TEXT NOT NULL,
    source_page VARCHAR(500),    -- URL where enquiry came from
    status      VARCHAR(20) DEFAULT 'new', -- 'new', 'in-progress', 'replied', 'closed'
    priority    VARCHAR(10),     -- 'high', 'medium', 'low' (auto-detected or manual)
    assigned_to INTEGER REFERENCES admin_users(id),
    is_read     BOOLEAN DEFAULT false,
    read_at     TIMESTAMP,
    ip_address  VARCHAR(45),
    user_agent  VARCHAR(500),
    created_at  TIMESTAMP DEFAULT NOW(),
    updated_at  TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_enquiries_status ON enquiries(status);
CREATE INDEX idx_enquiries_created_at ON enquiries(created_at DESC);
CREATE INDEX idx_enquiries_assigned_to ON enquiries(assigned_to);
```

### `enquiry_replies`
```sql
CREATE TABLE enquiry_replies (
    id          SERIAL PRIMARY KEY,
    enquiry_id  INTEGER REFERENCES enquiries(id) ON DELETE CASCADE,
    admin_id    INTEGER REFERENCES admin_users(id),
    body        TEXT NOT NULL,
    attachments JSONB,
    sent_via    VARCHAR(20),  -- 'email', 'note' (internal note)
    created_at  TIMESTAMP DEFAULT NOW()
);
```

---

### Site Content (CMS)
```sql
CREATE TABLE site_content (
    key         VARCHAR(100) PRIMARY KEY,    -- 'homepage_hero_headline', 'about_hero', etc.
    value       TEXT,
    value_json  JSONB,
    updated_by  INTEGER REFERENCES admin_users(id),
    updated_at  TIMESTAMP DEFAULT NOW()
);

-- Example rows:
INSERT INTO site_content VALUES
    ('homepage_hero_overline', 'INDIA''S LEADING DISTRIBUTOR', NULL, ...),
    ('homepage_hero_headline', 'Industrial Electrical Components for Every Application', NULL, ...),
    ('homepage_stats', NULL, '[{"value":"150+","label":"Products"}, ...]', ...);
```

Or use a more structured approach:
```sql
CREATE TABLE pages (
    slug        VARCHAR(100) PRIMARY KEY,    -- 'homepage', 'about', 'contact'
    title       VARCHAR(255),
    sections    JSONB,                       -- All page sections as structured data
    meta_title  VARCHAR(255),
    meta_description TEXT,
    updated_at  TIMESTAMP DEFAULT NOW()
);
```

---

### Analytics
```sql
CREATE TABLE page_views (
    id          BIGSERIAL PRIMARY KEY,
    page_url    VARCHAR(500) NOT NULL,
    product_id  INTEGER REFERENCES products(id),
    user_id     INTEGER REFERENCES pro_users(id),  -- NULL for anonymous
    ip_address  VARCHAR(45),
    user_agent  VARCHAR(500),
    referrer    VARCHAR(500),
    session_id  VARCHAR(100),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_page_views_created_at ON page_views(created_at DESC);
CREATE INDEX idx_page_views_product ON page_views(product_id);
```

### Activity log (audit trail)
```sql
CREATE TABLE activity_log (
    id          BIGSERIAL PRIMARY KEY,
    admin_id    INTEGER REFERENCES admin_users(id),
    action      VARCHAR(100) NOT NULL,       -- 'product.created', 'product.updated', 'user.approved', etc.
    entity_type VARCHAR(50),                 -- 'product', 'category', 'user', etc.
    entity_id   INTEGER,
    changes     JSONB,
    ip_address  VARCHAR(45),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_activity_log_created_at ON activity_log(created_at DESC);
CREATE INDEX idx_activity_log_admin ON activity_log(admin_id);
```

---

## Sample Seed Data

The prototype's mock data files contain the initial seed data:

- **Products:** 22 products across 10 categories (see `prototypes/proto/data.js`)
- **Categories:** 10 (Relays, Cable Glands, Control Panels, Conduits, HD Connectors, Junction Boxes, Plugs, Drag Chains, Cable Ties, Outlet Bodies)
- **Industries:** 4 (Automotive & EV, Industrial & Energy, Railway, Infrastructure)
- **Certifications:** 7 (UL, CE, ATEX, RoHS, TÜV, VDE, CSA)
- **Solutions:** 8 (EMI Shielding, Mechanical Protection, IP Sealing, Electrical Insulation, Fire Protection, High Temperature, Vibration Resistance, Cable Management)
- **Applications:** 9 (Engine Compartment, Wire Harness, Control Panels, Battery Pack, Drivetrain, Rail Vehicles, Industrial Machinery, Switchgear, Renewable Energy)

Convert these to SQL INSERT statements or run a migration seed script.

---

## File Storage

**Recommendation:** Use **Cloudinary** for product images.

- Free tier: 25 GB storage + 25 GB monthly bandwidth (enough for ~5000 product images)
- Built-in image optimization, CDN delivery, on-the-fly resizing
- Easy SDK for Node/PHP/Python

**Alternative:** AWS S3 + CloudFront, or Hostinger's built-in object storage.

Store only the URL in DB, not the binary blob.
