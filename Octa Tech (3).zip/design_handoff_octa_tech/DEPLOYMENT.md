# Hostinger Deployment Guide

Step-by-step instructions to deploy the Octa Tech platform on Hostinger.

---

## Pre-Deployment Checklist

Before starting, make sure you have:

- [ ] **Hostinger account** with an active hosting plan
- [ ] **Domain name** registered (e.g., `octatechelectricals.com`)
- [ ] **Domain pointed to Hostinger** nameservers
- [ ] **SSL certificate** enabled (free with Let's Encrypt via hPanel)
- [ ] **Database created** (if applicable to chosen stack)
- [ ] **Email accounts created** (e.g., `info@octatechelectricals.com`)

---

## Choosing a Hostinger Plan

| Plan | Best For | Monthly Cost (approx) |
|---|---|---|
| **Premium Web Hosting** | Static sites, WordPress | ₹149 |
| **Business Web Hosting** | WordPress with traffic | ₹249 |
| **Cloud Startup** | Higher traffic WordPress | ₹699 |
| **VPS KVM 2** | Custom Node.js/Laravel apps | ₹599 |
| **Cloud Hosting** | Production custom apps | ₹999+ |

**Recommendation by stack:**
- WordPress → **Business Web Hosting**
- Laravel → **Cloud Startup** or **VPS KVM 2**
- Next.js → **Vercel** (frontend) + **VPS KVM 2** (DB) OR all on **Cloud Hosting**

---

## Deployment Path A: Static Demo (Prototype As-Is)

Use only if hosting as a non-functional demo. Not recommended for production.

### Steps

1. **Login to Hostinger hPanel**
2. **File Manager** → navigate to `public_html`
3. **Delete** any default files (`default.html`, etc.)
4. **Upload** these files/folders:
   - Rename `Octa Tech Prototype.html` → `index.html`
   - Upload `proto/` folder
   - Upload `admin/` folder
   - Upload `Octa Tech Admin.html` (rename to `admin.html`)
5. **Test** by visiting your domain

### Limitations
- Form submissions don't work
- Admin changes don't persist
- Image uploads stored in browser memory only
- **Not suitable for real customers**

---

## Deployment Path B: WordPress

### 1. Install WordPress (1-Click via hPanel)

1. hPanel → **Auto Installer** → **WordPress**
2. Configure:
   - Domain: `octatechelectricals.com`
   - Admin email: your email
   - Strong admin password
3. Wait for install (~2 min)

### 2. Choose a Base Theme

Options:
- **Custom theme** (developer builds from scratch matching designs)
- **Astra Pro** + **Elementor** (developer customizes)
- **Blocksy** (free, fast)

### 3. Install Required Plugins

- **Advanced Custom Fields PRO** (for product specs)
- **Custom Post Type UI** (for products, categories)
- **WPGraphQL** (if headless approach)
- **Yoast SEO** (SEO)
- **Wordfence** (security)
- **WP Rocket** (caching, optional)
- **Contact Form 7** or **WPForms** (for enquiry forms)
- **WooCommerce** (if needed for catalog browsing)

### 4. Create Custom Post Types

Use Custom Post Type UI to create:
- `Products` (with custom fields: tagline, description, material, temperature, IP rating, certs, etc.)
- `Categories` (taxonomy)
- `Industries` (taxonomy)
- `Certifications` (taxonomy)

### 5. Build Theme

Hand the prototype to a WordPress theme developer with these specs:
- Use design tokens from `design-system/colors_and_type.css`
- Match the page structure described in `SPEC.md`
- Use ACF for product detail fields
- Implement search via WP_Query
- Use AJAX for filters

### 6. Configure Email

1. hPanel → **Email Accounts** → Create `info@octatechelectricals.com`
2. Install **WP Mail SMTP** plugin
3. Configure SMTP with Hostinger email server settings
4. Test by submitting a form

### 7. SSL & Security

1. hPanel → **SSL** → Install Free SSL Certificate (auto)
2. Force HTTPS redirect
3. Enable Wordfence firewall
4. Set strong passwords for all admin users

### 8. Go Live

1. Test all forms, products, search, mobile responsive
2. Submit sitemap to Google Search Console
3. Configure Google Analytics
4. Announce launch!

---

## Deployment Path C: Next.js + Hostinger VPS (Recommended for Scale)

### 1. Provision VPS

1. hPanel → **VPS** → **Create VPS**
2. Choose **KVM 2** plan (4 GB RAM)
3. OS: **Ubuntu 22.04 LTS**
4. Region: **Mumbai** or **Bangalore** (closest to India users)

### 2. Initial Server Setup

SSH into VPS:
```bash
ssh root@your-vps-ip
```

Install essentials:
```bash
apt update && apt upgrade -y
apt install -y curl git build-essential nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
npm install -g pm2
```

### 3. Install PostgreSQL

```bash
apt install -y postgresql postgresql-contrib
sudo -u postgres psql -c "CREATE USER octatech WITH PASSWORD 'STRONG_PASSWORD_HERE';"
sudo -u postgres psql -c "CREATE DATABASE octatech_prod OWNER octatech;"
```

### 4. Clone & Build the App

```bash
mkdir -p /var/www
cd /var/www
git clone <your-repo>.git octatech
cd octatech
npm install
npm run build
```

### 5. Configure Environment

Create `.env.production`:
```
DATABASE_URL=postgresql://octatech:PASSWORD@localhost:5432/octatech_prod
JWT_SECRET=<long random string>
NEXTAUTH_SECRET=<long random string>
NEXTAUTH_URL=https://octatechelectricals.com
CLOUDINARY_CLOUD_NAME=your-cloud
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
RESEND_API_KEY=...
EMAIL_FROM=info@octatechelectricals.com
ADMIN_EMAIL=info@octatechelectricals.com
```

### 6. Run Migrations + Seed

```bash
npm run db:migrate
npm run db:seed
```

### 7. Start with PM2

```bash
pm2 start npm --name "octatech" -- start
pm2 startup
pm2 save
```

### 8. Configure Nginx Reverse Proxy

Create `/etc/nginx/sites-available/octatech`:
```nginx
server {
    listen 80;
    server_name octatechelectricals.com www.octatechelectricals.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Static asset caching
    location /_next/static/ {
        proxy_pass http://localhost:3000;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

Enable:
```bash
ln -s /etc/nginx/sites-available/octatech /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

### 9. SSL with Let's Encrypt

```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d octatechelectricals.com -d www.octatechelectricals.com
```

Auto-renew is set up by default.

### 10. Point Domain

In Hostinger DNS settings:
- `A` record → `octatechelectricals.com` → `<your-vps-ip>`
- `A` record → `www.octatechelectricals.com` → `<your-vps-ip>`
- Optional: `A` record → `admin.octatechelectricals.com` → `<your-vps-ip>`

DNS propagation takes 1–24 hours.

### 11. Backups

Set up automatic database backups:
```bash
# /etc/cron.daily/backup-octatech
#!/bin/bash
pg_dump octatech_prod | gzip > /backups/octatech-$(date +\%F).sql.gz
find /backups -mtime +30 -delete
```

```bash
chmod +x /etc/cron.daily/backup-octatech
```

Use Hostinger's built-in backup feature too, OR rsync to another location.

---

## Deployment Path D: Laravel + Hostinger Cloud

### 1. Cloud Hosting Setup

1. hPanel → **Cloud Hosting** plan
2. Auto-installs LAMP stack (Linux, Apache, MySQL, PHP 8.2)
3. Create MySQL DB via hPanel

### 2. Clone via Git (or SFTP upload)

```bash
cd public_html
git clone <repo>.git temp
mv temp/* .
mv temp/.* . 2>/dev/null
rm -rf temp
```

### 3. Install Dependencies

```bash
composer install --no-dev --optimize-autoloader
```

### 4. Configure `.env`

Copy `.env.example` to `.env` and edit:
```
APP_ENV=production
APP_URL=https://octatechelectricals.com
DB_CONNECTION=mysql
DB_HOST=localhost
DB_DATABASE=u123456_octatech
DB_USERNAME=u123456_octa
DB_PASSWORD=YOUR_PASSWORD
MAIL_HOST=smtp.hostinger.com
MAIL_PORT=465
MAIL_USERNAME=info@octatechelectricals.com
MAIL_PASSWORD=YOUR_MAIL_PASSWORD
MAIL_ENCRYPTION=ssl
```

### 5. Generate App Key

```bash
php artisan key:generate
```

### 6. Migrate + Seed

```bash
php artisan migrate --force
php artisan db:seed --force
```

### 7. Set Permissions

```bash
chmod -R 775 storage bootstrap/cache
```

### 8. Symlink Storage

```bash
php artisan storage:link
```

### 9. Configure `.htaccess`

In `public_html/.htaccess`:
```apache
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews -Indexes
    </IfModule>

    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

### 10. Cache Configuration

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

---

## Post-Deployment Checklist

After deploying, verify everything works:

- [ ] **Homepage** loads at https://octatechelectricals.com
- [ ] **SSL certificate** active (padlock shows in browser)
- [ ] **Mobile responsive** — test on phone
- [ ] **Search** returns results
- [ ] **Filters** work in product catalog
- [ ] **Product detail** pages load
- [ ] **Enquiry form** sends email to admin inbox
- [ ] **Admin login** works at /admin
- [ ] **Admin can create/edit/delete** products
- [ ] **Image upload** saves to cloud storage
- [ ] **Bulk import** processes CSV correctly
- [ ] **Email notifications** received by admin
- [ ] **Google Analytics** tracking page views
- [ ] **Sitemap** submitted to Google Search Console
- [ ] **Page load time** < 3s on 4G connection
- [ ] **Backups** running daily
- [ ] **Error monitoring** configured (Sentry recommended)

---

## Performance Optimization

### Image Optimization
- Use **Cloudinary auto format/quality**: `f_auto,q_auto`
- Lazy load all below-the-fold images: `loading="lazy"`
- Use WebP format with JPG fallback

### Caching
- Enable **WP Rocket** (WordPress) or **Redis** (Laravel/Next.js)
- Set proper Cache-Control headers on static assets

### CDN
Optional: Add **Cloudflare** in front of Hostinger for global CDN + DDoS protection (free tier sufficient).

### Database
- Add indexes on commonly-queried columns (see `DATA-MODEL.md`)
- Use connection pooling
- Run `ANALYZE` regularly

---

## Monitoring & Alerting

- **Uptime monitoring:** [UptimeRobot](https://uptimerobot.com) (free, 5-min checks)
- **Error tracking:** [Sentry](https://sentry.io) (free for small apps)
- **Performance:** Google PageSpeed Insights + Lighthouse CI
- **Analytics:** Google Analytics 4 + Google Search Console

---

## Going Live Day Steps

1. **Final backup** of old site (if any)
2. **Switch DNS** to point to new server
3. **Wait for propagation** (1–24 hours)
4. **Send test enquiry** to confirm email works
5. **Test from mobile networks** (4G, not just WiFi)
6. **Submit sitemap** to Google: `https://search.google.com/search-console`
7. **Submit to Bing Webmaster Tools**
8. **Set up Google Business Profile** for "Octa Tech Electricals Nashik"
9. **Update business cards / signage** with new URL
10. **Announce on LinkedIn**, WhatsApp Business, email to customers

---

## Cost Estimate (Annual)

### Path B (WordPress)
- Hostinger Business: ₹3,000/year (₹249/mo billed annually)
- Domain: ₹800/year
- Pro plugins (ACF Pro, WP Rocket): ₹5,000/year
- **Total: ~₹9,000/year**

### Path C (Next.js VPS)
- Hostinger VPS KVM 2: ₹7,200/year
- Domain: ₹800/year
- Cloudinary: Free tier (or ₹6,000/year for higher tier)
- Resend (email): Free tier
- **Total: ~₹8,000–₹14,000/year**

### Path D (Laravel Cloud)
- Hostinger Cloud Startup: ₹8,400/year
- Domain: ₹800/year
- **Total: ~₹9,200/year**

---

## Support Contacts

- **Hostinger Support:** 24/7 live chat in hPanel
- **Domain issues:** Hostinger Domains team
- **Email problems:** Check MX records + SMTP settings
- **SSL issues:** hPanel → SSL → reinstall

---

*Need help? Feel free to ask the developer building your platform to follow this guide.*
