# Octa Tech Electricals — Developer Handoff Package

> **Project:** Industrial electrical components B2B distributor website + admin portal  
> **Client:** Octa Tech Electricals Pvt. Ltd., Nashik, Maharashtra, India  
> **Reference:** [octatechelectricals.com](https://www.octatechelectricals.com) (legacy site) · [relats.com](https://relats.com) (design inspiration)  
> **Created:** May 2026

---

## Quick Links

- [📁 Design files (HTML prototypes)](#files-in-this-package)
- [🎨 Design system (colors, type, spacing)](#design-tokens)
- [📋 Feature requirements](#feature-requirements)
- [🚀 Recommended tech stack](#recommended-tech-stack)
- [📐 Page-by-page specs](#page-specifications)

---

## About the Design Files

The files in this bundle are **design references created in HTML/CSS/JS** — high-fidelity prototypes showing intended look and behavior. They are **not production code** and should not be shipped as-is.

The task is to **recreate these HTML designs in a proper production codebase** using your chosen framework (React, Next.js, Laravel, WordPress, etc.) following its established patterns, libraries, and best practices.

The prototypes use:
- React 18 (loaded via CDN)
- Babel JSX transformation at runtime (development-only — must be replaced with a real build pipeline)
- Hardcoded mock data in JS files (must be replaced with database + API)
- Browser-only image uploads (must be replaced with real cloud storage)

---

## Fidelity

🔥 **High-fidelity (hi-fi)** — Pixel-perfect mockups with final colors, typography, spacing, animations, and interactions. The developer should:

- ✅ Recreate the UI pixel-perfectly using the codebase's framework and component library
- ✅ Use exact design tokens (color hex codes, font sizes, spacing values) as specified in `design-system/colors_and_type.css`
- ✅ Match all animations (parallax, scroll reveal, hover states, transitions)
- ✅ Implement all interactive behaviors documented below

---

## Project Scope — Two Sites

### 1. **Public-Facing Website** (`Octa Tech Prototype.html`)
The customer-facing product catalog for B2B industrial buyers.

### 2. **Admin Portal** (`Octa Tech Admin.html`)
Internal management dashboard for content team and sales staff.

---

## Recommended Tech Stack

For a **Hostinger-hosted production deployment**, we recommend:

### Option A — WordPress + WooCommerce (Easiest)
- **Frontend:** Custom WordPress theme replicating designs
- **Backend:** WordPress + WooCommerce (lite)
- **DB:** MySQL (included with Hostinger)
- **Plugins:** Advanced Custom Fields Pro, Yoast SEO, Wordfence
- **Best for:** Budget-conscious, non-technical team can update content
- **Timeline:** 3–4 weeks for one developer

### Option B — Next.js Full-Stack (Recommended for Scale)
- **Frontend:** Next.js 14 (App Router) + React 18 + TypeScript
- **Styling:** Tailwind CSS (with design tokens from `colors_and_type.css`)
- **Backend:** Next.js API routes (or separate Node/Express)
- **DB:** PostgreSQL via Supabase / Hostinger Cloud
- **Auth:** NextAuth (or Clerk for admin role management)
- **Storage:** Cloudinary / UploadThing for product images
- **Email:** Resend / SendGrid for enquiry notifications
- **Hosting:** Vercel (frontend) + Hostinger Cloud (DB) OR fully on Hostinger VPS
- **Best for:** Modern, fast, scalable
- **Timeline:** 6–8 weeks for one full-stack developer

### Option C — Laravel (PHP)
- **Frontend:** Blade templates + Alpine.js + Tailwind CSS
- **Backend:** Laravel 11 with Filament admin panel
- **DB:** MySQL (Hostinger shared hosting compatible)
- **Best for:** Native PHP team, existing Hostinger shared hosting plan
- **Timeline:** 5–7 weeks

---

## Files in This Package

| File / Folder | Purpose |
|---|---|
| `README.md` | This document |
| `prototypes/Octa Tech Prototype.html` | Public website prototype (entry point) |
| `prototypes/Octa Tech Admin.html` | Admin portal prototype (entry point) |
| `prototypes/proto/` | Source JSX files for public site |
| `prototypes/admin/` | Source JSX files for admin portal |
| `design-system/` | Color tokens, type tokens, CSS variables |
| `design-system/preview/` | Visual specimens (~20 cards) of every design pattern |
| `design-system/assets/` | Logo SVGs |
| `SPEC.md` | Detailed page-by-page specifications |
| `DATA-MODEL.md` | Database schema recommendations |
| `API.md` | Recommended REST API endpoints |
| `DEPLOYMENT.md` | Hostinger deployment guide |

---

## Design Tokens

All design tokens are defined as CSS custom properties in `design-system/colors_and_type.css`. See that file for the complete machine-readable list. Summary:

### Color Palette

#### Brand — Orange
```
--color-orange-500: #e85d26   /* PRIMARY ACCENT */
--color-orange-400: #f47a45   /* Hover state */
--color-orange-600: #c44d1c   /* Active state */
--gradient-brand:   linear-gradient(135deg, #e85d26, #ff7a45)
```

#### Brand — Navy (Dark Surfaces)
```
--color-navy-900: #08111f   /* PAGE BACKGROUND (bg-1) */
--color-navy-850: #0a1525   /* Alt section bg */
--color-navy-800: #0d1929   /* Card background (bg-2) */
--color-navy-700: #142240   /* Card hover (bg-3) */
--color-navy-600: #1e2d4a   /* Pills, elevated (bg-4) */
--color-navy-500: #2a3f6a   /* Borders, dividers (bg-5) */
```

#### Text Hierarchy (on dark)
```
--fg-primary:    rgba(255, 255, 255, 1.00)   /* Body text, headings */
--fg-secondary:  rgba(255, 255, 255, 0.65)   /* Subtitles, descriptions */
--fg-tertiary:   rgba(255, 255, 255, 0.40)   /* Labels, captions */
--fg-muted:      rgba(255, 255, 255, 0.20)   /* Placeholders, very subtle */
--fg-disabled:   rgba(255, 255, 255, 0.12)   /* Disabled state */
```

#### Semantic Colors
```
--color-success: #16a34a   (light: rgba(22,163,74,0.12))
--color-warning: #d97706   (light: rgba(217,119,6,0.12))
--color-error:   #dc2626   (light: rgba(220,38,38,0.12))
--color-info:    #2563eb   (light: rgba(37,99,235,0.12))
```

#### Borders
```
--border-subtle:  rgba(255,255,255,0.05)   /* Dividers */
--border-default: rgba(255,255,255,0.09)   /* Cards, inputs */
--border-strong:  rgba(255,255,255,0.15)   /* Ghost buttons */
--border-orange:  rgba(232,93,38,0.35)     /* Active/hover */
```

---

### Typography

#### Font Families (Google Fonts)
```
Display / Headings: Space Grotesk  (weights: 400, 500, 600, 700, 800)
Body / UI:          DM Sans         (weights: 300, 400, 500, 600, 700)
Mono / Specs:       DM Mono         (weights: 400, 500)
```

Google Fonts import:
```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700;800&family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
```

#### Type Scale (px)
```
Display 2XL: 72px / 800 / line-height 1.1   (hero headlines)
Display XL:  56px / 800 / line-height 1.1
Display LG:  44px / 800 / line-height 1.1   (page headlines)
Display MD:  36px / 700 / line-height 1.15
Display SM:  32px / 700 / line-height 1.25  (section headlines)

H1: 28px / 700
H2: 24px / 700
H3: 22px / 700
H4: 20px / 600
H5: 18px / 600

Body LG: 16px / 400 / line-height 1.75
Body MD: 16px / 400 / line-height 1.6
Body SM: 14px / 400 / line-height 1.6
Body XS: 13px / 400 / line-height 1.6

Label LG: 14px / 600
Label SM: 12px / 600
Overline: 11px / 600 / ALL CAPS / letter-spacing 0.15em / color: orange-500
Caption:  10px / 400
```

---

### Spacing Scale (4px grid)
```
--space-1:  4px
--space-2:  8px
--space-3:  12px
--space-4:  16px
--space-5:  20px
--space-6:  24px
--space-7:  28px
--space-8:  32px
--space-10: 40px
--space-12: 48px   /* Section side padding (desktop) */
--space-16: 64px
--space-20: 80px   /* Section vertical padding */
--space-24: 96px
```

### Border Radius
```
--radius-xs:   4px    /* Tags, badges */
--radius-sm:   6px    /* Small buttons */
--radius-md:   8px    /* Buttons, inputs */
--radius-lg:   10px   /* Compact cards */
--radius-xl:   12px   /* Default cards */
--radius-2xl:  16px   /* Large cards, modals */
--radius-full: 9999px /* Pills, avatars */
```

### Shadow / Elevation
```
--shadow-1:  0 4px 16px rgba(0,0,0,0.20)    /* Card resting */
--shadow-2:  0 8px 32px rgba(0,0,0,0.35)    /* Card hover, dropdown */
--shadow-3:  0 16px 48px rgba(0,0,0,0.45)   /* Modals */
--shadow-orange: 0 4px 20px rgba(232,93,38,0.30)  /* Primary CTA button */
```

### Layout Constants
```
Content max-width: 1200px (centered)
Side padding (desktop): 48px
Side padding (mobile): 24px
Nav height: 64px
```

---

## Feature Requirements

### Public Website Features (Must Have)

| # | Feature | Priority |
|---|---|---|
| 1 | Responsive layout (mobile, tablet, desktop) | P0 |
| 2 | Product catalog with filters (industry, category, solutions, applications) | P0 |
| 3 | Product detail page with full specs | P0 |
| 4 | Enquiry form (sends email to admin) | P0 |
| 5 | Live search with suggestions | P0 |
| 6 | Product comparison (up to 6 products side-by-side) | P0 |
| 7 | Industry segmentation (Automotive, Industrial, Railway, Infrastructure) | P0 |
| 8 | PRO user login (gated technical data sheets) | P0 |
| 9 | About page (editable content) | P0 |
| 10 | Contact page with form | P0 |
| 11 | Parallax scroll animations on homepage | P1 |
| 12 | Hover effects on product cards | P1 |
| 13 | Mobile hamburger menu | P0 |
| 14 | SEO-friendly URLs (e.g., `/products/cable-glands/brass-double-compression`) | P0 |
| 15 | Sitemap.xml + robots.txt | P0 |
| 16 | Google Analytics / GTM integration | P1 |
| 17 | WhatsApp click-to-chat button | P2 |

### Admin Portal Features (Must Have)

| # | Feature | Priority |
|---|---|---|
| 1 | Admin login with 3 roles (Super Admin / Editor / Viewer) | P0 |
| 2 | Dashboard with analytics (views, enquiries, users) | P0 |
| 3 | Product CRUD (add/edit/delete with images, specs, certs) | P0 |
| 4 | Bulk CSV/Excel import & export | P0 |
| 5 | Category management | P0 |
| 6 | Industry management | P0 |
| 7 | Certification management | P0 |
| 8 | Enquiry inbox (with reply, status, assignment) | P0 |
| 9 | PRO user approval workflow | P0 |
| 10 | Admin user management (invite, role assignment) | P0 |
| 11 | Homepage content editor (hero text, stats) | P0 |
| 12 | About page content editor | P0 |
| 13 | Email notifications (new enquiry, new PRO request) | P0 |
| 14 | Activity audit log | P1 |
| 15 | Image upload with Cloudinary/S3 | P0 |
| 16 | Real-time search across all entities | P1 |

---

## Page Specifications

> See `SPEC.md` for detailed page-by-page specs.

### Quick Page Index

#### Public Site (5 pages)
- `/` — Homepage (hero + featured products + industries + certifications)
- `/products` — Product catalog with filters
- `/products/[category]/[slug]` — Product detail
- `/about` — About company
- `/contact` — Contact form

#### Admin Portal (12 pages)
- `/admin/login` — Sign in
- `/admin` — Dashboard
- `/admin/products` — Product list
- `/admin/products/new` — Add product
- `/admin/products/[id]/edit` — Edit product
- `/admin/categories` — Manage categories
- `/admin/industries` — Manage industries
- `/admin/certifications` — Manage certs
- `/admin/enquiries` — Enquiry inbox
- `/admin/pro-users` — PRO user management
- `/admin/admins` — Admin user management
- `/admin/homepage` — Homepage content editor
- `/admin/about` — About page editor
- `/admin/bulk` — CSV import/export
- `/admin/settings` — Settings

---

## Animations & Motion

| Element | Animation | Specs |
|---|---|---|
| Scroll reveal | Fade-up | `opacity 0→1 + translateY(32→0)`, 0.7s ease, triggered via IntersectionObserver |
| Hero parallax | Background shift | `translateY(scrollY × 0.2-0.3)`, requestAnimationFrame |
| Card hover | Lift | `translateY(-4px)`, border-color → orange, 0.25s ease |
| Button hover | Lift + shadow | `translateY(-2px)`, shadow increases, 0.2s ease |
| Counter animation | Count-up | 0 → target over 1.2s, on viewport entry |
| Modal appear | Fade + slide | `fadeIn 0.15s` + `slideUp 0.2s` |
| Dropdown | Fade-down | `fadeDown 0.15s` |
| Loading spinner | Rotate | `0 → 360deg`, infinite, 0.7s linear |

---

## Iconography

Currently uses **emoji** for category icons (⚡🔌🖥️〰️🔗📦🔋⛓️🪢🔧).

**Production recommendation:** Replace emoji with proper SVG icons from one of:
- [Phosphor Icons](https://phosphoricons.com) (recommended — thin stroke, technical look)
- [Lucide Icons](https://lucide.dev) 
- [Heroicons](https://heroicons.com)

For certifications, use the **actual logo SVGs** of: UL, CSA, RoHS, VDE, TÜV, ATEX, CE — these need to be sourced separately (not included in this package due to trademark).

---

## Content & Copy Guidelines

- **Tone:** Professional, technical, B2B. Direct and factual. No marketing fluff.
- **Casing:** Sentence case for headings and CTAs ("Browse catalog", not "Browse Catalog"). Cert codes always ALL CAPS (UL, CE, ATEX).
- **Numbers:** Always precise — `-40°C to +120°C`, `IP68 / IP69K`, `16A / 250VAC`
- **Voice:** "Octa Tech Electricals is…" in formal context; "Our team" in conversational
- **No emoji in production UI** — except contact info icons (📍✉📞) and category cards (in MVP only — replace with SVG icons)

---

## Critical Implementation Notes

### 1. Dark Mode Only
All UI is dark-first. No light mode required for v1. Don't add one unless explicitly asked.

### 2. Cards Are Defined Clearly
- Background: `--color-navy-800` (#0d1929)
- Border: `1px solid rgba(255,255,255,0.06)`
- Border-radius: 12px
- Hover: bg → `--color-navy-700`, border → `--border-orange`, `translateY(-4px)`
- **Never use:** colored left-border accents, blue-purple gradients, gradient card headers

### 3. Buttons Have 3 Variants
- **Primary:** Orange gradient + shadow (CTAs, "Save", "Submit")
- **Secondary:** `rgba(255,255,255,0.05)` bg + subtle border (alternative actions)
- **Ghost:** transparent + border (tertiary actions, "Cancel")
- **Danger:** red tint (destructive actions only — "Delete", "Reject")

### 4. Overlines Are a Pattern
ALL-CAPS, `letter-spacing: 0.15em`, color `#e85d26`, size 11-12px. Used above every section headline. Example: `INDIA'S LEADING DISTRIBUTOR`, `BY INDUSTRY`, `FEATURED`.

### 5. Mobile-First Required
- Mobile: 1-column, hamburger menu, full-width touch targets (≥44px)
- Tablet (768px+): 2-column grids, sidebar appears
- Desktop (1024px+): full layout

### 6. Accessibility (WCAG AA Minimum)
- All text meets contrast ratio 4.5:1 on backgrounds (verified)
- Focus rings: `outline: 2px solid #e85d26; outline-offset: 2px`
- All interactive elements keyboard-navigable
- Forms have proper labels and aria attributes
- Modals trap focus and close with Escape key

---

## Mock Data Structure (Replace with DB)

See `DATA-MODEL.md` for recommended database schema. Mock data files in this package:
- `prototypes/proto/data.js` — Products, categories, industries, certifications
- `prototypes/admin/data.js` — Admin users, PRO users, enquiries, analytics

---

## Deployment

See `DEPLOYMENT.md` for step-by-step Hostinger deployment guide for each tech stack option.

---

## Questions for the Developer

Before starting, the developer should clarify with the client:

1. **Domain:** Confirm `octatechelectricals.com` will be used (already owned?)
2. **Email host:** Where will enquiry emails go? (e.g., `info@octatechelectricals.com`)
3. **Real product photos:** When will high-res product images be provided?
4. **Certification logos:** Client must provide official cert logos (UL, CE, ATEX, etc.)
5. **Pricing display:** Should the public catalog show prices, or stay quote-on-request?
6. **Multilingual?** English only, or also Hindi/Marathi?
7. **Payment integration?** Not in v1, but plan for Razorpay/PayU in future?
8. **WhatsApp integration?** Should "Request Quote" buttons open WhatsApp chat?

---

## Project Manager Contact

**Client:** Octa Tech Electricals  
**Address:** 401, Shreeji Vrunda Apt, Indira Nagar, Nashik — 422009, Maharashtra, India  
**Email:** info@octatechelectricals.com  
**Phone:** +91 70667 11811

---

*This handoff package was generated based on the prototype designs created in May 2026.*
