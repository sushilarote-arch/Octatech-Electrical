# Page Specifications

Detailed page-by-page implementation guide.

---

## 🌐 PUBLIC WEBSITE

### Page 1: Homepage (`/`)

**Reference:** `prototypes/Octa Tech Prototype.html` → "home" page

#### Layout (Top → Bottom)

##### Section 1: Hero (full viewport, ~600-800px height)
- **Background:** Dark navy (`#08111f`) with parallax grid lines overlay
- **Parallax effect:** Grid translates Y by `scrollY × 0.3` on scroll
- **Glow orb:** Decorative `radial-gradient(circle, rgba(232,93,38,0.12) 0%, transparent 70%)` 400×400px positioned top-right, translates by `scrollY × 0.15`
- **Left side (60%):**
  - Overline: "INDIA'S LEADING DISTRIBUTOR" (orange, 11px, ALL CAPS, letter-spacing 3px)
  - H1 headline (72px on desktop, clamp(40px, 6vw, 72px)): "Industrial Electrical Components for Every Application" — middle word "Components" has gradient text fill (`linear-gradient(135deg, #e85d26, #ff9a6c)`)
  - Description (17px, secondary text): "Certified industrial electrical distributor serving automotive, energy, and infrastructure sectors across India."
  - Two CTAs side-by-side:
    - Primary: "Browse Catalog →" (orange gradient, shadow)
    - Secondary: "Get a Quote" (ghost style)
  - Cert badges row: UL, CE, ATEX, RoHS, TÜV, VDE, CSA (bordered text chips)
- **Right side (40%):** 5 floating category pills (rgba(255,255,255,0.04) bg) — "Relays", "Cable Glands", "Heavy Duty Connectors", "Control Panels", "Conduits" — animate in staggered (each 100ms apart)
- **Scroll indicator:** Animated bouncing chevron at bottom-center

##### Section 2: Stats Bar (full-width, navy-900, ~120px tall)
- 4 columns with count-up animation:
  - `150+` Products
  - `12` Categories
  - `7` Certifications  
  - `25+` Years Experience
- Number color: `#e85d26`, font: Space Grotesk 800 36px
- Label below in `--fg-tertiary`, font: DM Sans 13px
- Border between columns: `1px solid rgba(255,255,255,0.05)`

##### Section 3: Industries Grid
- Section padding: 80px vertical
- Header: Overline "BY INDUSTRY" + H2 "Solutions for Every Sector" (centered)
- Grid: 4 cards × 1 row
  - Each card: icon, title, description, "X products" + arrow
  - Card hover: bg → `#142240`, border → orange tint, `translateY(-4px)`
- Cards: Automotive & EV / Industrial & Energy / Railway / Infrastructure

##### Section 4: Featured Products
- Background: `#0a1525`
- Header: Overline "FEATURED" + H2 "Popular Products" + "View all →" button (right-aligned)
- Grid: 4 product cards × 1 row (responsive: 1 col mobile, 2 tablet, 4 desktop)
- Each card:
  - Image area (gradient bg + category emoji, 160px tall)
  - "Featured" badge (top-left, orange gradient)
  - Compare button (top-right, only visible on hover)
  - Product name (Space Grotesk 14px 600)
  - Tagline (DM Sans 12px, tertiary)
  - Cert chips
  - Two buttons: "Details" + "Enquire"

##### Section 5: Certifications
- Centered overline "QUALITY ASSURED" + H2 "International Certifications"
- Subtitle (DM Sans 15px, max-width 480px, centered)
- Row of 7 cert badges (100×100px squares, navy-800 bg, border on hover)

##### Section 6: CTA Strip
- Background: `linear-gradient(135deg, #e85d26, #c04a1a)`
- Padding: 60px 48px
- Headline + description on left, two buttons on right (white "Contact Us" + ghost "Request Quote")

##### Section 7: Footer
- Background: `#050d18`
- 4-column grid: Brand info / Products / Company / Legal
- Brand column has logo + address + email + phone
- Bottom row: copyright + cert badges + Admin Portal link

---

### Page 2: Product Catalog (`/products`)

**Reference:** `prototypes/Octa Tech Prototype.html` → "catalog" page

#### Layout

##### Header (sticky, below nav)
- Background: `linear-gradient(180deg, #0d1929 0%, #08111f 100%)`
- Padding: 40px 48px 32px
- Breadcrumb: "Home › Products"
- H1: "Product Catalog" (Space Grotesk 36px 800)
- Search bar (max-width 520px):
  - Height 48px, border-radius 10px
  - Background: `rgba(255,255,255,0.05)`
  - Border: `1px solid rgba(255,255,255,0.1)` (focus: `rgba(232,93,38,0.5)`)
  - Search icon left, input field, X clear button when has text
- Industry tabs:
  - All (150) / Automotive & EV (86) / Industrial (46) / Railway (18) / Infrastructure
  - Active tab: white text + 2px orange bottom border
  - Inactive: `rgba(255,255,255,0.4)` text

##### Main Content (2-column: 220px sidebar + grid)

###### Sidebar (sticky on scroll, top: 80px)
- **Categories list** (collapsible):
  - Each row: icon + label + count
  - Active: orange bg tint + orange text + orange border
- **Filter groups** (collapsible accordions):
  - "Solutions" (10 checkboxes)
  - "Applications" (9 checkboxes)
  - Custom checkbox style (16×16px, orange when checked with ✓)
- **Clear all filters** button (orange tint, full width)

###### Product Grid
- Toolbar:
  - Left: "Showing X products" + active filter chips
  - Right: View toggle (Normal / Technical)
- Active filter chips: pill style, orange tinted, with × to remove
- **Normal view:** Grid with `repeat(auto-fill, minmax(220px, 1fr))`, gap 14px
- **Technical view:** Stacked rows showing spec data inline
- Pagination at bottom (1, 2, 3, … 8 with prev/next)

##### Floating Compare Bar
- Position: fixed bottom 24px, centered
- Slides up animation when first product added
- Shows 6 slot avatars + "X/6 selected" + "Compare →" button + close X
- Only visible when compareList.length > 0

---

### Page 3: Product Detail (`/products/[category]/[slug]`)

**Reference:** `prototypes/Octa Tech Prototype.html` → "product" page

#### Layout

##### Breadcrumb Bar
- `Home › Products › [Category] › [Product Name]`

##### Hero Section (2-column: 360px image + flex info)
###### Left
- Main image: 300px tall, gradient bg, large category icon (placeholder)
- 3 thumbnail squares below (70px)
- "Available in" card: shows industries as orange pill tags

###### Right
- Tags row: category badge (orange) + cert badges (default)
- H1 product name (Space Grotesk 32px 800)
- Description paragraph (DM Sans 16px, secondary, max-width 520px)
- **Key specs strip** (3 cards inline):
  - Each: icon + label (tertiary, 10px ALL CAPS) + value (white, 13px, monospace)
- **CTAs row:**
  - "Request Information" (primary orange)
  - "🔒 Technical Data Sheet PRO" (secondary, locked icon, opens login modal)
  - "+ Compare" (toggle button — shows ✓ Added when active)
- **Solutions section:** Chips with orange dot indicator
- **Applications section:** Default chips

##### Sticky Tab Nav (below hero, sticky top: 64px)
- Background: `#0d1929`
- Tabs: Overview / Specifications / Downloads
- Active: white text + 2px orange bottom border

##### Tab Content
- **Overview:** 2-column — left: striped spec table | right: cert badges grid + "Need TDS?" PRO gate card
- **Specifications:** Grid of 2 columns of spec cards
- **Downloads:** List of file rows, locked files show "PRO Access" button

##### Related Products
- Background: `#0a1525`
- Grid of 4 product cards from same category

---

### Page 4: About (`/about`)

**Reference:** `prototypes/Octa Tech Prototype.html` → "about" page

#### Sections (top to bottom)
1. **Hero:** Overline + H1 + paragraph + 2 CTAs (max-width 600px, left-aligned)
2. **Stats bar** (4 cols): 150+ Products, 12 Categories, 7 Certifications, 25+ Years
3. **Values grid** (4 cards): Quality First / Wide Spectrum / Client Partnership / Fast Growing
4. **Certifications section** (2-col):
   - Left: heading + description
   - Right: 6 cert badges grid (3×2, each 1:1 aspect ratio)
5. **Timeline** (vertical, alternating left/right):
   - 2001 Founded → 2008 First certs → 2014 100+ products → 2019 Digital catalog → 2024 ATEX & TÜV added → 2026 Platform redesign
6. **CTA strip** (orange gradient, full width)

---

### Page 5: Contact (`/contact`)

**Reference:** `prototypes/Octa Tech Prototype.html` → "contact" page

#### Layout
- Dark hero with overline + H1 + subtitle (only)
- 2-column body:
  - **Left:** Form card with name, company, email, phone, category select, message, T&C checkbox, submit button
  - **Right:** Info cards (address, email, phone, hours) + map placeholder

---

## 🔐 ADMIN PORTAL

### Admin Page 1: Login (`/admin/login`)

**Reference:** `prototypes/Octa Tech Admin.html` → login screen

- Centered 400px wide card on dark bg with grid overlay
- Logo at top (56×56 orange gradient with "O")
- "OCTA TECH" wordmark + "ADMIN PORTAL" subtitle
- Form: Email + Password
- "Remember me" checkbox + "Forgot password?" link
- Primary button: "Sign in →"
- Disclaimer below: "© 2026 Octa Tech Electricals · Secure admin access"

---

### Admin Page 2: Dashboard (`/admin`)

**Reference:** `prototypes/Octa Tech Admin.html` → dashboard

#### Layout: Sidebar (240px) + Main content

##### Sidebar
- Logo + "OCTA TECH" + "ADMIN PORTAL" subtitle
- Nav sections:
  - **CATALOG:** Dashboard / Products / Categories / Industries / Certifications
  - **CUSTOMER:** Enquiries / PRO Users (badges for unread)
  - **CONTENT:** Homepage / About Page
  - **DATA:** Import / Export
  - **SYSTEM:** Admin Users / Settings
- Each nav item: icon + label + (count badge)
- Active item: orange tint bg + orange text + 3px orange left bar
- Collapsible (sidebar can collapse to 64px)
- User profile at bottom

##### Topbar (sticky, h: 60px)
- Search bar (360px) with ⌘K shortcut hint
- "+ New Product" primary button
- 🔔 Notifications icon (with red dot)
- "View Site ↗" link to public website
- User avatar + name + role + logout

##### Dashboard Content
- **Page header:** "Dashboard" + greeting + Date range picker + Export button
- **4 stat cards (grid):**
  - Each: icon, big number, label, sparkline (last 7 days), delta badge
- **2-column section:**
  - Left (2/3): "Views & Enquiries" bar chart (custom SVG)
  - Right (1/3): "Traffic by Industry" donut chart + legend
- **2-column section:**
  - Left: "Top Products" table (product, views, enquiries, trend arrow)
  - Right: "Recent Activity" feed (icon + message + timestamp)

---

### Admin Page 3: Products List (`/admin/products`)

**Reference:** `prototypes/Octa Tech Admin.html` → products list

- Page header with: search + category filter dropdown + status filter dropdown + count
- Bulk action bar (visible when items selected): "Mark Featured", "Change category", "Delete"
- Table columns: ☑ / Product (image+name+slug) / Category / Industry / Certifications / Status / Actions (edit/delete)

---

### Admin Page 4: Product Form (`/admin/products/new` and `/admin/products/[id]/edit`)

**Reference:** `prototypes/Octa Tech Admin.html` → product form

#### Layout: 2-column (2:1 ratio)

##### Left Column (main form)
- **Basic Information card:** Name, Slug (auto from name), Tagline, Full Description
- **Product Images card:**
  - Drag-and-drop zone (large, dashed border, opens file picker on click)
  - Multi-file upload (image/*)
  - Preview grid (4 cols) with first image marked "MAIN" (orange border)
  - Each preview has X button to remove
- **Technical Specifications card:**
  - Standard fields: Material, Temperature Range, IP Rating
  - Custom specs key-value editor:
    - List of existing specs (with × to delete)
    - "Spec name" + "Value" inputs + "Add" button
- **SEO card:** Meta Title + Meta Description (with character count helpers)

##### Right Column (sidebar)
- **Status card:** Featured Product checkbox / Mark as New checkbox
- **Category & Industry card:** Single-select category dropdown + multi-checkbox industries
- **Certifications card:** Toggle chips for each cert (UL, CE, ATEX, etc.)
- **Solutions card:** Toggle chips (10 options)
- **Applications card:** Toggle chips (9 options)

##### Header Actions
- "Cancel" (ghost) / "Preview" (secondary) / "Save Changes" or "Create Product" (primary)

---

### Admin Page 5: Categories / Industries / Certifications

**Reference:** `prototypes/Octa Tech Admin.html` → taxonomy pages

#### Categories
- Grid of cards (3 cols)
- Each card: icon, name, slug, count, applicable industries (chips), Edit + Delete buttons
- "+ Add new category" dashed-border card at end
- Modal form: Name + Icon picker (emoji grid) + Industry checkboxes

#### Industries
- Similar grid but simpler (no icon picker)

#### Certifications
- Inline add form at top (code + region select + add button)
- Table of certs with logo placeholder, region, issuer, usage count

---

### Admin Page 6: Enquiries Inbox (`/admin/enquiries`)

**Reference:** `prototypes/Octa Tech Admin.html` → enquiries

#### Layout: 2-pane email-like (380px list + flex detail)

##### List Pane
- Search input
- Filter tabs: All / Unread / New / In progress
- Enquiry list items: unread dot + sender + timestamp + company + message preview + status badge + priority badge
- Active item: orange tint bg + 3px orange left border

##### Detail Pane
- Top: badges (status, priority) + product name (H2) + meta info
- "From" card: avatar + name + company + email + phone
- "Message" card: full message text
- Quick reply textarea + Attach + Templates + "Send Reply" button
- Action buttons: Mark in-progress / Mark replied / Close enquiry / Assign / Delete

---

### Admin Page 7: PRO Users (`/admin/pro-users`)

**Reference:** `prototypes/Octa Tech Admin.html` → PRO users

- Filter chips: All / Active / Pending Approval
- Search input (right-aligned)
- Table: User (avatar+name+email) / Company / Joined / Activity (enquiries+downloads) / Status / Actions
- Pending users have **Approve / Reject** buttons; active users have View / Edit icons

---

### Admin Page 8: Admin Users (`/admin/admins`)

- 3 role overview cards (Super Admin / Editor / Viewer) with descriptions and permission badges
- Admin users table: User / Role / Status / Last Login / Created / Actions
- "+ Invite Admin" primary button in header

---

### Admin Page 9 & 10: Content Editors

**Reference:** `prototypes/Octa Tech Admin.html` → homepage/about editors

#### Homepage Editor
- 2-column: Form (left) + Live Preview (right, sticky)
- Form sections: Hero Section / Statistics Bar
- Hero: Overline / Headline / Description / CTA Primary text / CTA Secondary text
- Stats: editable list of {value, label} pairs with delete + add buttons
- Live preview updates on every keystroke

#### About Editor
- Hero section (headline + description)
- Full Story textarea (large)
- Values list editable: each row has icon picker + title + description + delete

---

### Admin Page 11: Bulk Import/Export (`/admin/bulk`)

**Reference:** `prototypes/Octa Tech Admin.html` → bulk

- 2-column: Import card + Export card

#### Import Card (multi-step)
1. **Idle:** Drop zone for CSV/Excel + format requirements + sample template download
2. **Parsing:** Spinner + "Parsing filename..."
3. **Preview:** Validation results + first 5 rows preview + Cancel/Import buttons
4. **Done:** Success message + count + "Import another" button

#### Export Card
- What to export (dropdown: products / by category / enquiries / users / analytics)
- Format selector: CSV / Excel / JSON
- Include columns checkboxes
- Download button

#### Recent Activity Table
- Type (Import/Export) / File / By / When / Status

---

### Admin Page 12: Settings (`/admin/settings`)

- Company Information card (name, email, phone, address)
- Notifications card (checkboxes for email alerts)
- Additional sections to add: API keys, integrations, branding settings

---

## Component Library Summary

Reusable components used across all pages:

| Component | Used in |
|---|---|
| `<NavBar>` | All public pages |
| `<Footer>` | All public pages |
| `<ProductCard>` | Catalog, Homepage, Related |
| `<FilterSidebar>` | Catalog |
| `<Modal>` | Login, Enquiry, Compare |
| `<AdminLayout>` (sidebar+topbar) | All admin pages |
| `<PageHeader>` | All admin pages |
| `<Card>` | Admin pages |
| `<Btn>` (5 variants) | All pages |
| `<Input>` (text/textarea/select) | Forms |
| `<Badge>` (6 variants) | Status, tags, badges |
| `<DataTable>` | Admin lists |
