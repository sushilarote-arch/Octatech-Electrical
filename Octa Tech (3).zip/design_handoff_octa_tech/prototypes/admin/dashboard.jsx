// admin/dashboard.jsx
const { useState, useEffect } = React;

function Dashboard({ navigate }) {
  const a = window.AdminData.analytics;

  const Sparkline = ({ data, height = 60 }) => {
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min || 1;
    const w = 100;
    const points = data.map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = height - ((v - min) / range) * height * 0.85 - 8;
      return `${x},${y}`;
    }).join(' ');
    return (
      <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" style={{ width: '100%', height }}>
        <defs>
          <linearGradient id="sparkGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#e85d26" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#e85d26" stopOpacity="0" />
          </linearGradient>
        </defs>
        <polygon points={`0,${height} ${points} ${w},${height}`} fill="url(#sparkGrad)" />
        <polyline points={points} fill="none" stroke="#e85d26" strokeWidth="1.5" />
      </svg>
    );
  };

  const Donut = ({ segments, size = 140 }) => {
    let cumulative = 0;
    const radius = size / 2 - 12;
    const strokeWidth = 18;
    const circumference = 2 * Math.PI * radius;
    return (
      <div style={{ position: 'relative', width: size, height: size }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          {segments.map((seg, i) => {
            const dash = (seg.share / 100) * circumference;
            const offset = (cumulative / 100) * circumference;
            cumulative += seg.share;
            return (
              <circle key={i} cx={size/2} cy={size/2} r={radius} fill="none"
                stroke={seg.color} strokeWidth={strokeWidth}
                strokeDasharray={`${dash} ${circumference}`}
                strokeDashoffset={-offset}
              />
            );
          })}
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 22, fontWeight: 800, color: 'white' }}>100%</div>
          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.4)' }}>Industries</div>
        </div>
      </div>
    );
  };

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle="Welcome back, Aarav. Here's what's happening today."
        actions={
          <>
            <Btn variant="ghost" size="md" icon="📅">Last 7 days</Btn>
            <Btn variant="secondary" size="md" icon="↓">Export</Btn>
          </>
        }
      />

      <div style={{ padding: '24px 32px' }}>
        {/* Summary cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
          {[
            { label: 'Total Page Views', value: a.summary.totalViews.toLocaleString(), delta: a.summary.viewsDelta, deltaPos: true, icon: '👁️', spark: [120, 145, 132, 167, 154, 178, 195] },
            { label: 'New Enquiries', value: a.summary.totalEnquiries, delta: a.summary.enquiriesDelta, deltaPos: true, icon: '✉️', spark: [22, 28, 25, 35, 32, 38, 41] },
            { label: 'New PRO Users', value: a.summary.newProUsers, delta: a.summary.proUsersDelta, deltaPos: true, icon: '👥', spark: [3, 5, 4, 6, 5, 8, 7] },
            { label: 'Catalog Downloads', value: a.summary.catalogDownloads, delta: a.summary.downloadsDelta, deltaPos: false, icon: '↓', spark: [18, 15, 17, 12, 14, 11, 13] },
          ].map(stat => (
            <Card key={stat.label} padding={18}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 8 }}>
                <div style={{ width: 36, height: 36, background: 'rgba(232,93,38,0.1)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>{stat.icon}</div>
                <Badge variant={stat.deltaPos ? 'success' : 'danger'} size="sm">{stat.delta}</Badge>
              </div>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 28, fontWeight: 800, color: 'white', lineHeight: 1, marginBottom: 4 }}>{stat.value}</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 10 }}>{stat.label}</div>
              <Sparkline data={stat.spark} height={36} />
            </Card>
          ))}
        </div>

        {/* Main chart + activity */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16, marginBottom: 24 }}>
          {/* Views & Enquiries trend */}
          <Card padding={24}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <div>
                <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white' }}>Views & Enquiries</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Last 7 days</div>
              </div>
              <div style={{ display: 'flex', gap: 14 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 9, height: 9, borderRadius: 2, background: '#e85d26' }} />
                  <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Views</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ width: 9, height: 9, borderRadius: 2, background: '#2563eb' }} />
                  <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.5)' }}>Enquiries</span>
                </div>
              </div>
            </div>
            <BarChart data={a.viewsTrend} />
          </Card>

          {/* Top industries donut */}
          <Card padding={24}>
            <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white', marginBottom: 4 }}>Traffic by Industry</div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 20 }}>This month</div>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
              <Donut segments={a.topIndustries} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {a.topIndustries.map(ind => (
                <div key={ind.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: 2, background: ind.color }} />
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{ind.label}</span>
                  </div>
                  <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'white' }}>{ind.share}%</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Top products + recent activity */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
          <Card padding={24}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <div>
                <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white' }}>Top Products</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Most viewed in last 30 days</div>
              </div>
              <button onClick={() => navigate('products')} style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: '#e85d26', fontWeight: 600 }}>View all →</button>
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                  <td style={{ padding: '8px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700 }}>PRODUCT</td>
                  <td style={{ padding: '8px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700, textAlign: 'right' }}>VIEWS</td>
                  <td style={{ padding: '8px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700, textAlign: 'right' }}>ENQUIRIES</td>
                  <td style={{ padding: '8px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700, textAlign: 'right' }}>TREND</td>
                </tr>
              </thead>
              <tbody>
                {a.topProducts.map((p, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                    <td style={{ padding: '12px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'white' }}>{p.name}</td>
                    <td style={{ padding: '12px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.7)', textAlign: 'right' }}>{p.views.toLocaleString()}</td>
                    <td style={{ padding: '12px 0', fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.7)', textAlign: 'right' }}>{p.enquiries}</td>
                    <td style={{ padding: '12px 0', textAlign: 'right' }}>
                      <span style={{ color: p.trend === 'up' ? '#16a34a' : p.trend === 'down' ? '#dc2626' : 'rgba(255,255,255,0.3)', fontSize: 13 }}>{p.trend === 'up' ? '▲' : p.trend === 'down' ? '▼' : '─'}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          <Card padding={24}>
            <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white', marginBottom: 4 }}>Recent Activity</div>
            <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>Live admin feed</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {a.recentActivity.map((act, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                  <div style={{ width: 28, height: 28, borderRadius: 7, background: 'rgba(232,93,38,0.1)', border: '1px solid rgba(232,93,38,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, flexShrink: 0 }}>{act.icon}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.75)', lineHeight: 1.5 }}>{act.message}</div>
                    <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', marginTop: 2 }}>{act.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}

function BarChart({ data }) {
  const maxViews = Math.max(...data.map(d => d.views));
  const maxEnq = Math.max(...data.map(d => d.enquiries));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12, height: 180, padding: '8px 0' }}>
      {data.map((d, i) => (
        <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: 150, width: '100%', justifyContent: 'center' }}>
            <div style={{ width: '40%', height: `${(d.views / maxViews) * 100}%`, background: 'linear-gradient(180deg, #ff7a45, #e85d26)', borderRadius: '4px 4px 0 0', minHeight: 2, transition: 'height 0.5s ease', position: 'relative' }} title={`${d.views} views`}>
              <div style={{ position: 'absolute', top: -22, left: '50%', transform: 'translateX(-50%)', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.5)', whiteSpace: 'nowrap' }}>{d.views}</div>
            </div>
            <div style={{ width: '30%', height: `${(d.enquiries / maxViews) * 100 * 3}%`, background: 'linear-gradient(180deg, #4d8bf0, #2563eb)', borderRadius: '4px 4px 0 0', minHeight: 2, transition: 'height 0.5s ease' }} title={`${d.enquiries} enquiries`} />
          </div>
          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{d.day}</div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { Dashboard });
