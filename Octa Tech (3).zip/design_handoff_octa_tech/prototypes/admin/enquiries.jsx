// admin/enquiries.jsx — Enquiry inbox
const { useState } = React;

function EnquiriesPage() {
  const [enquiries, setEnquiries] = useState(window.AdminData.enquiries);
  const [selected, setSelected] = useState(enquiries[0]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const filtered = enquiries.filter(e => {
    if (filter === 'unread' && e.read) return false;
    if (filter === 'new' && e.status !== 'new') return false;
    if (filter === 'in-progress' && e.status !== 'in-progress') return false;
    if (search && !e.from.toLowerCase().includes(search.toLowerCase()) && !e.company.toLowerCase().includes(search.toLowerCase()) && !e.product.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const updateStatus = (status) => {
    setEnquiries(prev => prev.map(e => e.id === selected.id ? { ...e, status, read: true } : e));
    setSelected({ ...selected, status, read: true });
  };

  const markRead = (enq) => {
    if (!enq.read) {
      setEnquiries(prev => prev.map(e => e.id === enq.id ? { ...e, read: true } : e));
    }
    setSelected(enq);
  };

  const statusColors = {
    new: 'accent', 'in-progress': 'info', replied: 'success', closed: 'default',
  };
  const priorityColors = { high: 'danger', medium: 'warning', low: 'default' };

  return (
    <>
      <PageHeader
        title="Enquiries Inbox"
        subtitle={`${enquiries.filter(e => !e.read).length} unread · ${enquiries.length} total`}
        actions={
          <>
            <Btn variant="secondary" size="md" icon="↓">Export CSV</Btn>
            <Btn variant="ghost" size="md" icon="🔄">Refresh</Btn>
          </>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: '380px 1fr', height: 'calc(100vh - 60px - 90px)' }}>
        {/* LIST */}
        <div style={{ borderRight: '1px solid rgba(255,255,255,0.05)', display: 'flex', flexDirection: 'column' }}>
          {/* Filters */}
          <div style={{ padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
            <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '0 10px', height: 32, gap: 7, marginBottom: 10 }}>
              <span style={{ fontSize: 12, opacity: 0.4 }}>🔍</span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search enquiries..." style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 12 }} />
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {[['all', 'All'], ['unread', 'Unread'], ['new', 'New'], ['in-progress', 'In progress']].map(([id, label]) => {
                const count = id === 'all' ? enquiries.length : id === 'unread' ? enquiries.filter(e => !e.read).length : enquiries.filter(e => e.status === id).length;
                return (
                  <button key={id} onClick={() => setFilter(id)} style={{
                    flex: 1, padding: '5px 4px', borderRadius: 6, border: 'none', cursor: 'pointer',
                    background: filter === id ? 'rgba(232,93,38,0.12)' : 'transparent',
                    color: filter === id ? '#e85d26' : 'rgba(255,255,255,0.5)',
                    fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600,
                  }}>{label} {count > 0 && <span style={{ opacity: 0.6, fontSize: 10 }}>({count})</span>}</button>
                );
              })}
            </div>
          </div>

          {/* List items */}
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {filtered.map(enq => {
              const isActive = selected?.id === enq.id;
              return (
                <button key={enq.id} onClick={() => markRead(enq)} style={{
                  display: 'block', width: '100%', padding: '14px 16px',
                  border: 'none', borderBottom: '1px solid rgba(255,255,255,0.04)',
                  background: isActive ? 'rgba(232,93,38,0.06)' : 'transparent',
                  borderLeft: isActive ? '3px solid #e85d26' : '3px solid transparent',
                  cursor: 'pointer', textAlign: 'left', transition: 'all 0.15s',
                }}
                  onMouseOver={e => { if (!isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.02)'; }}
                  onMouseOut={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                      {!enq.read && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#e85d26', flexShrink: 0 }} />}
                      <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: enq.read ? 500 : 700, color: 'white' }}>{enq.from}</span>
                    </div>
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.35)' }}>{timeAgo(enq.received)}</span>
                  </div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 6 }}>{enq.company}</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.6)', marginBottom: 8, lineHeight: 1.4, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{enq.message}</div>
                  <div style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
                    <Badge size="sm" variant={statusColors[enq.status]}>{enq.status}</Badge>
                    {enq.priority === 'high' && <Badge size="sm" variant="danger">High priority</Badge>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* DETAIL */}
        <div style={{ overflowY: 'auto' }}>
          {selected ? (
            <div style={{ padding: 32, maxWidth: 760 }}>
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
                <div>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                    <Badge variant={statusColors[selected.status]}>{selected.status}</Badge>
                    {selected.priority === 'high' && <Badge variant="danger">High priority</Badge>}
                  </div>
                  <h2 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 22, fontWeight: 700, color: 'white', margin: 0, marginBottom: 6 }}>{selected.product}</h2>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>
                    Received {new Date(selected.received).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    {selected.assignedTo && <> · Assigned to <span style={{ color: '#e85d26' }}>{selected.assignedTo}</span></>}
                  </div>
                </div>
              </div>

              {/* From card */}
              <Card padding={20} style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white', flexShrink: 0 }}>{selected.from.split(' ').map(n => n[0]).slice(0,2).join('')}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', gap: 12, marginBottom: 6 }}>
                      <div>
                        <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 700, color: 'white' }}>{selected.from}</div>
                        <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.45)' }}>{selected.company}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 16, marginTop: 10 }}>
                      <a href={`mailto:${selected.email}`} style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: '#e85d26', textDecoration: 'none' }}>✉ {selected.email}</a>
                      <a href={`tel:${selected.phone}`} style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: '#e85d26', textDecoration: 'none' }}>📞 {selected.phone}</a>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Message */}
              <Card padding={20} style={{ marginBottom: 16 }}>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>MESSAGE</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 14, color: 'rgba(255,255,255,0.8)', lineHeight: 1.7 }}>{selected.message}</div>
              </Card>

              {/* Reply box */}
              <Card padding={20} style={{ marginBottom: 16 }}>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 700, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 10 }}>QUICK REPLY</div>
                <textarea rows={5} placeholder="Type your response..." style={{ width: '100%', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 8, padding: '12px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', resize: 'vertical', boxSizing: 'border-box', marginBottom: 12 }} />
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button style={{ padding: '5px 10px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>📎 Attach</button>
                    <button style={{ padding: '5px 10px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', fontSize: 11, color: 'rgba(255,255,255,0.5)' }}>📋 Templates</button>
                  </div>
                  <Btn variant="primary" size="md" icon="✓" onClick={() => updateStatus('replied')}>Send Reply</Btn>
                </div>
              </Card>

              {/* Actions */}
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <Btn variant="secondary" size="sm" onClick={() => updateStatus('in-progress')}>Mark in-progress</Btn>
                <Btn variant="success" size="sm" onClick={() => updateStatus('replied')}>Mark replied</Btn>
                <Btn variant="ghost" size="sm" onClick={() => updateStatus('closed')}>Close enquiry</Btn>
                <Btn variant="ghost" size="sm" icon="👤">Assign to…</Btn>
                <Btn variant="danger" size="sm">Delete</Btn>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'rgba(255,255,255,0.3)', fontFamily: 'DM Sans, sans-serif' }}>Select an enquiry to view</div>
          )}
        </div>
      </div>
    </>
  );
}

function timeAgo(iso) {
  const now = new Date();
  const then = new Date(iso);
  const diff = Math.floor((now - then) / 1000);
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff/60)}m`;
  if (diff < 86400) return `${Math.floor(diff/3600)}h`;
  return `${Math.floor(diff/86400)}d`;
}

Object.assign(window, { EnquiriesPage });
