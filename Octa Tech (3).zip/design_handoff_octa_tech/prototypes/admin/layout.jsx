// admin/layout.jsx — Sidebar + topbar
const { useState, useEffect } = React;

function AdminLayout({ currentPage, navigate, children, user, onLogout }) {
  const [collapsed, setCollapsed] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊', section: 'main' },
    { id: 'products', label: 'Products', icon: '📦', section: 'main', count: window.OctaData.products.length },
    { id: 'categories', label: 'Categories', icon: '🗂️', section: 'main', count: window.OctaData.categories.length },
    { id: 'industries', label: 'Industries', icon: '🏭', section: 'main', count: window.OctaData.industries.length - 1 },
    { id: 'certifications', label: 'Certifications', icon: '✓', section: 'main', count: window.OctaData.certifications.length },
    { id: 'enquiries', label: 'Enquiries', icon: '✉️', section: 'crm', count: window.AdminData.enquiries.filter(e => !e.read).length, badge: true },
    { id: 'pro-users', label: 'PRO Users', icon: '👥', section: 'crm', count: window.AdminData.proUsers.filter(u => u.status === 'pending').length, badge: true },
    { id: 'homepage', label: 'Homepage', icon: '🏠', section: 'content' },
    { id: 'about', label: 'About Page', icon: '📄', section: 'content' },
    { id: 'bulk', label: 'Import / Export', icon: '⇅', section: 'data' },
    { id: 'admins', label: 'Admin Users', icon: '🔐', section: 'system' },
    { id: 'settings', label: 'Settings', icon: '⚙️', section: 'system' },
  ];

  const sections = {
    main: 'CATALOG',
    crm: 'CUSTOMER',
    content: 'CONTENT',
    data: 'DATA',
    system: 'SYSTEM',
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#08111f' }}>
      {/* ── SIDEBAR ── */}
      <aside style={{
        width: collapsed ? 64 : 240, flexShrink: 0,
        background: '#050d18', borderRight: '1px solid rgba(255,255,255,0.05)',
        display: 'flex', flexDirection: 'column',
        transition: 'width 0.2s ease',
        position: 'sticky', top: 0, height: '100vh', overflowY: 'auto',
      }}>
        {/* Logo */}
        <div style={{ padding: collapsed ? '20px 12px' : '20px 18px', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', gap: 10, justifyContent: collapsed ? 'center' : 'flex-start' }}>
          <div style={{ width: 32, height: 32, background: 'linear-gradient(135deg, #e85d26, #ff7a45)', borderRadius: 7, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <span style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 16, fontWeight: 900, color: 'white' }}>O</span>
          </div>
          {!collapsed && (
            <div>
              <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white', lineHeight: 1.1 }}>OCTA TECH</div>
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 9, fontWeight: 600, color: '#e85d26', letterSpacing: 1.5, marginTop: 2 }}>ADMIN PORTAL</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          {Object.entries(sections).map(([sectionKey, sectionLabel]) => {
            const items = navItems.filter(i => i.section === sectionKey);
            return (
              <div key={sectionKey} style={{ marginBottom: 16 }}>
                {!collapsed && (
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 9, fontWeight: 700, color: 'rgba(255,255,255,0.25)', letterSpacing: 2, padding: '8px 12px 4px' }}>{sectionLabel}</div>
                )}
                {items.map(item => {
                  const isActive = currentPage === item.id;
                  return (
                    <button key={item.id} onClick={() => navigate(item.id)}
                      title={collapsed ? item.label : ''}
                      style={{
                        width: '100%', display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'space-between',
                        padding: collapsed ? '10px' : '9px 12px', marginBottom: 2,
                        background: isActive ? 'rgba(232,93,38,0.12)' : 'transparent',
                        border: 'none', borderRadius: 8, cursor: 'pointer',
                        color: isActive ? '#e85d26' : 'rgba(255,255,255,0.6)',
                        transition: 'all 0.15s', position: 'relative',
                      }}
                      onMouseOver={e => { if (!isActive) { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.color = 'rgba(255,255,255,0.85)'; } }}
                      onMouseOut={e => { if (!isActive) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.6)'; } }}>
                      {isActive && <div style={{ position: 'absolute', left: -8, top: 6, bottom: 6, width: 3, background: '#e85d26', borderRadius: '0 3px 3px 0' }} />}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ fontSize: 14, width: 18, textAlign: 'center' }}>{item.icon}</span>
                        {!collapsed && <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: isActive ? 600 : 500 }}>{item.label}</span>}
                      </div>
                      {!collapsed && item.count !== undefined && item.count > 0 && (
                        <span style={{
                          background: item.badge ? '#e85d26' : 'rgba(255,255,255,0.08)',
                          color: item.badge ? 'white' : 'rgba(255,255,255,0.5)',
                          padding: '1px 7px', borderRadius: 10, fontSize: 10, fontFamily: 'DM Sans, sans-serif', fontWeight: 600,
                        }}>{item.count}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            );
          })}
        </nav>

        {/* Collapse toggle + User */}
        <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
          <button onClick={() => setCollapsed(!collapsed)} style={{
            width: '100%', padding: '8px', background: 'rgba(255,255,255,0.04)', border: 'none', borderRadius: 7,
            cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontFamily: 'DM Sans, sans-serif', fontSize: 12,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <span style={{ fontSize: 12, transform: collapsed ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>«</span>
            {!collapsed && <span>Collapse</span>}
          </button>
        </div>
      </aside>

      {/* ── MAIN ── */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* Topbar */}
        <header style={{
          position: 'sticky', top: 0, zIndex: 100,
          background: 'rgba(8,17,31,0.92)', backdropFilter: 'blur(12px)',
          borderBottom: '1px solid rgba(255,255,255,0.05)',
          height: 60, padding: '0 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 8, padding: '0 12px', height: 36, gap: 8, width: 360 }}>
              <span style={{ fontSize: 13, opacity: 0.4 }}>🔍</span>
              <input placeholder="Search products, enquiries, users..." style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13 }} />
              <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 3, padding: '1px 5px' }}>⌘K</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {/* Quick add */}
            <button style={{ background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 7, padding: '7px 14px', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'white', display: 'flex', alignItems: 'center', gap: 5 }} onClick={() => navigate('products', { action: 'new' })}>
              <span style={{ fontSize: 14, lineHeight: 1 }}>+</span> New Product
            </button>
            {/* Notifications */}
            <button style={{ position: 'relative', width: 36, height: 36, background: 'rgba(255,255,255,0.04)', border: 'none', borderRadius: 8, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 16 }}>
              🔔
              <span style={{ position: 'absolute', top: 6, right: 7, width: 7, height: 7, background: '#e85d26', borderRadius: '50%', border: '2px solid #08111f' }} />
            </button>
            {/* View site */}
            <a href="Octa Tech Prototype.html" target="_blank" rel="noopener" style={{ padding: '7px 14px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 7, fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.7)', textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 5 }}>
              View Site ↗
            </a>
            {/* User menu */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 12, borderLeft: '1px solid rgba(255,255,255,0.07)' }}>
              <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Space Grotesk, sans-serif', fontSize: 12, fontWeight: 700, color: 'white' }}>{user.avatar}</div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'white', lineHeight: 1.2 }}>{user.name}</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{user.role.replace('-', ' ')}</div>
              </div>
              <button onClick={onLogout} title="Sign out" style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.3)', fontSize: 16, padding: 4 }}>⎋</button>
            </div>
          </div>
        </header>

        {/* Content */}
        <main style={{ flex: 1, overflowY: 'auto' }}>
          {children}
        </main>
      </div>
    </div>
  );
}

/* Reusable bits */
function PageHeader({ title, subtitle, actions }) {
  return (
    <div style={{ padding: '28px 32px 20px', borderBottom: '1px solid rgba(255,255,255,0.05)', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
      <div>
        <h1 style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 26, fontWeight: 800, color: 'white', margin: 0, marginBottom: 4 }}>{title}</h1>
        {subtitle && <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 14, color: 'rgba(255,255,255,0.45)' }}>{subtitle}</div>}
      </div>
      {actions && <div style={{ display: 'flex', gap: 8 }}>{actions}</div>}
    </div>
  );
}

function Card({ children, padding = 24, style = {} }) {
  return (
    <div style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 12, padding, ...style }}>
      {children}
    </div>
  );
}

function Btn({ children, onClick, variant = 'primary', size = 'md', icon, style = {} }) {
  const sizes = {
    sm: { padding: '6px 12px', fontSize: 12, gap: 5 },
    md: { padding: '8px 16px', fontSize: 13, gap: 6 },
    lg: { padding: '11px 22px', fontSize: 14, gap: 7 },
  };
  const variants = {
    primary: { background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', color: 'white', boxShadow: '0 2px 12px rgba(232,93,38,0.25)' },
    secondary: { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.7)' },
    ghost: { background: 'transparent', border: '1px solid rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)' },
    danger: { background: 'rgba(220,38,38,0.1)', border: '1px solid rgba(220,38,38,0.3)', color: '#dc2626' },
    success: { background: 'rgba(22,163,74,0.1)', border: '1px solid rgba(22,163,74,0.3)', color: '#16a34a' },
  };
  return (
    <button onClick={onClick} style={{
      ...sizes[size], ...variants[variant], borderRadius: 8, cursor: 'pointer',
      fontFamily: 'DM Sans, sans-serif', fontWeight: 600, display: 'inline-flex', alignItems: 'center',
      transition: 'all 0.15s', whiteSpace: 'nowrap', ...style,
    }}
      onMouseOver={e => { if (variant === 'primary') { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(232,93,38,0.4)'; } else { e.currentTarget.style.background = variant === 'secondary' ? 'rgba(255,255,255,0.09)' : variant === 'ghost' ? 'rgba(255,255,255,0.04)' : variants[variant].background; } }}
      onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = variants[variant].boxShadow || 'none'; e.currentTarget.style.background = variants[variant].background; }}>
      {icon && <span>{icon}</span>}{children}
    </button>
  );
}

function Input({ label, placeholder, type = 'text', value, onChange, required, helper, error }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && (
        <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6, letterSpacing: 0.3 }}>
          {label}{required && <span style={{ color: '#e85d26', marginLeft: 4 }}>*</span>}
        </label>
      )}
      {type === 'textarea' ? (
        <textarea rows={4} placeholder={placeholder} value={value || ''} onChange={onChange} style={{
          width: '100%', background: 'rgba(255,255,255,0.04)', border: `1px solid ${error ? 'rgba(220,38,38,0.5)' : 'rgba(255,255,255,0.09)'}`,
          borderRadius: 8, padding: '10px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13,
          outline: 'none', resize: 'vertical', boxSizing: 'border-box',
        }} onFocus={e => e.target.style.borderColor = error ? 'rgba(220,38,38,0.5)' : 'rgba(232,93,38,0.5)'}
          onBlur={e => e.target.style.borderColor = error ? 'rgba(220,38,38,0.5)' : 'rgba(255,255,255,0.09)'} />
      ) : (
        <input type={type} placeholder={placeholder} value={value || ''} onChange={onChange} style={{
          width: '100%', background: 'rgba(255,255,255,0.04)', border: `1px solid ${error ? 'rgba(220,38,38,0.5)' : 'rgba(255,255,255,0.09)'}`,
          borderRadius: 8, padding: '10px 14px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13,
          outline: 'none', boxSizing: 'border-box', transition: 'border-color 0.15s',
        }} onFocus={e => e.target.style.borderColor = error ? 'rgba(220,38,38,0.5)' : 'rgba(232,93,38,0.5)'}
          onBlur={e => e.target.style.borderColor = error ? 'rgba(220,38,38,0.5)' : 'rgba(255,255,255,0.09)'} />
      )}
      {helper && !error && <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.3)', marginTop: 4 }}>{helper}</div>}
      {error && <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: '#dc2626', marginTop: 4 }}>{error}</div>}
    </div>
  );
}

function Badge({ children, variant = 'default', size = 'md' }) {
  const sizes = { sm: { padding: '1px 7px', fontSize: 10 }, md: { padding: '3px 9px', fontSize: 11 } };
  const variants = {
    default: { background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.1)' },
    accent:  { background: 'rgba(232,93,38,0.12)', color: '#e85d26', border: '1px solid rgba(232,93,38,0.25)' },
    success: { background: 'rgba(22,163,74,0.12)', color: '#16a34a', border: '1px solid rgba(22,163,74,0.25)' },
    warning: { background: 'rgba(217,119,6,0.12)', color: '#d97706', border: '1px solid rgba(217,119,6,0.25)' },
    danger:  { background: 'rgba(220,38,38,0.12)', color: '#dc2626', border: '1px solid rgba(220,38,38,0.25)' },
    info:    { background: 'rgba(37,99,235,0.12)', color: '#2563eb', border: '1px solid rgba(37,99,235,0.25)' },
  };
  return <span style={{ ...sizes[size], ...variants[variant], borderRadius: 4, fontFamily: 'DM Sans, sans-serif', fontWeight: 600, display: 'inline-block', whiteSpace: 'nowrap' }}>{children}</span>;
}

Object.assign(window, { AdminLayout, PageHeader, Card, Btn, Input, Badge });
