// admin/products.jsx — Product list + form with image upload
const { useState, useMemo, useRef } = React;

function ProductsPage({ navigate, pageData }) {
  const [view, setView] = useState(pageData?.action === 'new' || pageData?.action === 'edit' ? 'form' : 'list');
  const [editingProduct, setEditingProduct] = useState(pageData?.action === 'edit' ? pageData.product : null);
  const [products, setProducts] = useState(window.OctaData.products);

  const openNew = () => { setEditingProduct(null); setView('form'); };
  const openEdit = (p) => { setEditingProduct(p); setView('form'); };
  const back = () => { setView('list'); setEditingProduct(null); };

  const onSave = (p) => {
    if (editingProduct) {
      setProducts(prev => prev.map(x => x.id === p.id ? p : x));
    } else {
      setProducts(prev => [{ ...p, id: Math.max(...prev.map(x => x.id)) + 1 }, ...prev]);
    }
    back();
  };

  const onDelete = (id) => {
    if (confirm('Delete this product? This cannot be undone.')) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };

  return view === 'form'
    ? <ProductForm product={editingProduct} onSave={onSave} onCancel={back} />
    : <ProductList products={products} openNew={openNew} openEdit={openEdit} onDelete={onDelete} navigate={navigate} />;
}

/* ── LIST VIEW ── */
function ProductList({ products, openNew, openEdit, onDelete, navigate }) {
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selected, setSelected] = useState(new Set());

  const filtered = useMemo(() => {
    return products.filter(p => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterCat !== 'all' && p.category !== filterCat) return false;
      if (filterStatus === 'featured' && !p.featured) return false;
      return true;
    });
  }, [products, search, filterCat, filterStatus]);

  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <>
      <PageHeader
        title="Products"
        subtitle={`${products.length} total products across ${window.OctaData.categories.length} categories`}
        actions={
          <>
            <Btn variant="secondary" size="md" icon="↓" onClick={() => navigate('bulk')}>Export</Btn>
            <Btn variant="secondary" size="md" icon="↑" onClick={() => navigate('bulk')}>Import CSV</Btn>
            <Btn variant="primary" size="md" icon="+" onClick={openNew}>Add Product</Btn>
          </>
        }
      />

      <div style={{ padding: '24px 32px' }}>
        {/* Filters bar */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 16, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '0 12px', height: 36, gap: 8, flex: 1, minWidth: 240, maxWidth: 400 }}>
            <span style={{ fontSize: 13, opacity: 0.4 }}>🔍</span>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..." style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13 }} />
          </div>
          <select value={filterCat} onChange={e => setFilterCat(e.target.value)} style={{
            padding: '8px 12px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)',
            borderRadius: 8, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', cursor: 'pointer',
          }}>
            <option value="all">All categories</option>
            {window.OctaData.categories.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} style={{
            padding: '8px 12px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)',
            borderRadius: 8, color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', cursor: 'pointer',
          }}>
            <option value="all">All status</option>
            <option value="featured">Featured only</option>
            <option value="new">New only</option>
          </select>
          <div style={{ marginLeft: 'auto', fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>
            Showing <span style={{ color: 'white', fontWeight: 600 }}>{filtered.length}</span> of {products.length}
          </div>
        </div>

        {/* Bulk action bar */}
        {selected.size > 0 && (
          <div style={{ background: 'rgba(232,93,38,0.08)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 8, padding: '10px 16px', marginBottom: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: '#e85d26' }}>{selected.size} selected</span>
            <div style={{ display: 'flex', gap: 8 }}>
              <Btn size="sm" variant="secondary">Mark as Featured</Btn>
              <Btn size="sm" variant="secondary">Change category</Btn>
              <Btn size="sm" variant="danger" icon="🗑️">Delete</Btn>
              <Btn size="sm" variant="ghost" onClick={() => setSelected(new Set())}>Clear</Btn>
            </div>
          </div>
        )}

        {/* Table */}
        <Card padding={0}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', width: 36 }}>
                  <input type="checkbox" checked={selected.size === filtered.length && filtered.length > 0}
                    onChange={() => { if (selected.size === filtered.length) setSelected(new Set()); else setSelected(new Set(filtered.map(f => f.id))); }}
                    style={{ accentColor: '#e85d26' }} />
                </th>
                {['Product', 'Category', 'Industry', 'Certifications', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '12px 16px', textAlign: h === 'Actions' ? 'right' : 'left', fontFamily: 'DM Sans, sans-serif', fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1, fontWeight: 700, textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => {
                const cat = window.OctaData.categories.find(c => c.id === p.category);
                return (
                  <tr key={p.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)', transition: 'background 0.15s' }}
                    onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.02)'}
                    onMouseOut={e => e.currentTarget.style.background = 'transparent'}>
                    <td style={{ padding: '14px 16px' }}>
                      <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggleSelect(p.id)} style={{ accentColor: '#e85d26' }} />
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{ width: 40, height: 40, background: 'linear-gradient(135deg, #1e3358, #0f2040)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>{cat?.icon}</div>
                        <div>
                          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: 600, color: 'white', marginBottom: 2 }}>{p.name}</div>
                          <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{p.slug}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <Badge variant="default">{cat?.label || p.category}</Badge>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {p.industry.map(i => {
                          const ind = window.OctaData.industries.find(x => x.id === i);
                          return ind ? <Badge key={i} variant="default" size="sm">{ind.label.split(' ')[0]}</Badge> : null;
                        })}
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
                        {p.certs.slice(0, 4).map(c => <Badge key={c} variant="default" size="sm">{c}</Badge>)}
                        {p.certs.length > 4 && <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>+{p.certs.length - 4}</span>}
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      {p.featured && <Badge variant="accent" size="sm">★ Featured</Badge>}
                      {p.badge === 'New' && <Badge variant="success" size="sm">New</Badge>}
                      {!p.featured && p.badge !== 'New' && <Badge variant="default" size="sm">Active</Badge>}
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                        <button onClick={() => openEdit(p)} title="Edit" style={{ width: 28, height: 28, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>✏️</button>
                        <button onClick={() => onDelete(p.id)} title="Delete" style={{ width: 28, height: 28, background: 'rgba(220,38,38,0.06)', border: '1px solid rgba(220,38,38,0.15)', borderRadius: 6, cursor: 'pointer', color: '#dc2626', fontSize: 12 }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}

/* ── FORM VIEW ── */
function ProductForm({ product, onSave, onCancel }) {
  const isNew = !product;
  const [f, setF] = useState(product || {
    name: '', slug: '', category: 'relays', industry: ['industrial'],
    tagline: '', description: '', material: '', temperature: '', ipRating: '',
    certs: [], solutions: [], applications: [], featured: false, badge: null,
    specs: {}, images: [],
  });

  const upd = (k, v) => setF(prev => ({ ...prev, [k]: v }));
  const toggle = (k, v) => upd(k, (f[k] || []).includes(v) ? f[k].filter(x => x !== v) : [...(f[k] || []), v]);

  // Image upload
  const fileRef = useRef(null);
  const onFiles = (files) => {
    const newImages = Array.from(files).map(file => ({
      id: Date.now() + Math.random(),
      name: file.name,
      url: URL.createObjectURL(file),
      size: (file.size / 1024).toFixed(1) + ' KB',
    }));
    upd('images', [...(f.images || []), ...newImages]);
  };

  const onDrop = (e) => {
    e.preventDefault();
    if (e.dataTransfer.files?.length) onFiles(e.dataTransfer.files);
  };

  // Specs editor
  const [specKey, setSpecKey] = useState('');
  const [specVal, setSpecVal] = useState('');
  const addSpec = () => {
    if (!specKey.trim()) return;
    upd('specs', { ...(f.specs || {}), [specKey]: specVal });
    setSpecKey(''); setSpecVal('');
  };
  const removeSpec = (k) => {
    const newSpecs = { ...(f.specs || {}) };
    delete newSpecs[k];
    upd('specs', newSpecs);
  };

  return (
    <>
      <PageHeader
        title={isNew ? 'Add New Product' : `Edit: ${product.name}`}
        subtitle={isNew ? 'Create a new product entry for the catalog' : 'Update product details and specifications'}
        actions={
          <>
            <Btn variant="ghost" onClick={onCancel}>Cancel</Btn>
            <Btn variant="secondary" icon="👁️">Preview</Btn>
            <Btn variant="primary" icon="✓" onClick={() => onSave(f)}>{isNew ? 'Create Product' : 'Save Changes'}</Btn>
          </>
        }
      />

      <div style={{ padding: '24px 32px', maxWidth: 1200 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 20 }}>
          {/* LEFT — main form */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Basic Info */}
            <Card padding={24}>
              <FormSectionTitle>Basic Information</FormSectionTitle>
              <Input label="Product Name" placeholder="e.g. Brass Double Compression Gland" required value={f.name} onChange={e => { upd('name', e.target.value); if (isNew) upd('slug', e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-')); }} />
              <Input label="URL Slug" placeholder="brass-double-compression-gland" required value={f.slug} onChange={e => upd('slug', e.target.value)} helper="Auto-generated from name. Used in product URL." />
              <Input label="Short Tagline" placeholder="IP68 rated dual-seal cable entry..." value={f.tagline} onChange={e => upd('tagline', e.target.value)} helper="1-line summary shown on product cards" />
              <Input label="Full Description" type="textarea" placeholder="Detailed product description for product page..." value={f.description} onChange={e => upd('description', e.target.value)} />
            </Card>

            {/* Images */}
            <Card padding={24}>
              <FormSectionTitle>Product Images</FormSectionTitle>
              <div onDragOver={e => e.preventDefault()} onDrop={onDrop} style={{
                border: '2px dashed rgba(255,255,255,0.12)', borderRadius: 12, padding: 32,
                textAlign: 'center', cursor: 'pointer', transition: 'border-color 0.15s',
                background: 'rgba(255,255,255,0.02)', marginBottom: 16,
              }}
                onClick={() => fileRef.current?.click()}
                onMouseOver={e => e.currentTarget.style.borderColor = 'rgba(232,93,38,0.4)'}
                onMouseOut={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'}>
                <input ref={fileRef} type="file" multiple accept="image/*" style={{ display: 'none' }} onChange={e => onFiles(e.target.files)} />
                <div style={{ fontSize: 32, marginBottom: 8 }}>📸</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 14, color: 'white', fontWeight: 600, marginBottom: 4 }}>Drop images here or click to upload</div>
                <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>JPG, PNG, WebP · Up to 5MB each · First image is the main one</div>
              </div>
              {(f.images || []).length > 0 && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
                  {f.images.map((img, i) => (
                    <div key={img.id} style={{ position: 'relative', aspectRatio: '1', borderRadius: 8, overflow: 'hidden', border: `2px solid ${i === 0 ? '#e85d26' : 'rgba(255,255,255,0.07)'}` }}>
                      <img src={img.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      {i === 0 && <div style={{ position: 'absolute', top: 4, left: 4, background: '#e85d26', borderRadius: 3, padding: '1px 6px', fontFamily: 'DM Sans, sans-serif', fontSize: 9, fontWeight: 700, color: 'white' }}>MAIN</div>}
                      <button onClick={() => upd('images', f.images.filter(x => x.id !== img.id))} style={{ position: 'absolute', top: 4, right: 4, width: 22, height: 22, background: 'rgba(0,0,0,0.7)', border: 'none', borderRadius: 4, cursor: 'pointer', color: 'white', fontSize: 12 }}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Specs */}
            <Card padding={24}>
              <FormSectionTitle>Technical Specifications</FormSectionTitle>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
                <Input label="Material" placeholder="Brass, Nickel plated" value={f.material} onChange={e => upd('material', e.target.value)} />
                <Input label="Temperature Range" placeholder="-40°C to +120°C" value={f.temperature} onChange={e => upd('temperature', e.target.value)} />
                <Input label="IP Rating" placeholder="IP68 / IP69K" value={f.ipRating} onChange={e => upd('ipRating', e.target.value)} />
              </div>
              {/* Custom specs key-value */}
              <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.4)', marginTop: 16, marginBottom: 8, letterSpacing: 0.5 }}>CUSTOM SPECIFICATIONS</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
                {Object.entries(f.specs || {}).map(([k, v]) => (
                  <div key={k} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '8px 12px', background: 'rgba(255,255,255,0.03)', borderRadius: 7 }}>
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.45)', minWidth: 120 }}>{k}</span>
                    <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'white', flex: 1 }}>{v}</span>
                    <button onClick={() => removeSpec(k)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.3)', fontSize: 14 }}>×</button>
                  </div>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input value={specKey} onChange={e => setSpecKey(e.target.value)} placeholder="Spec name (e.g. Thread)" style={{ flex: 1, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '8px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none' }} />
                <input value={specVal} onChange={e => setSpecVal(e.target.value)} placeholder="Value (e.g. M20 × 1.5)" style={{ flex: 1.5, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 7, padding: '8px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none' }} onKeyDown={e => e.key === 'Enter' && addSpec()} />
                <Btn variant="secondary" size="md" onClick={addSpec}>+ Add</Btn>
              </div>
            </Card>

            {/* SEO */}
            <Card padding={24}>
              <FormSectionTitle>SEO</FormSectionTitle>
              <Input label="Meta Title" placeholder="Brass Cable Gland | Octa Tech" value={f.metaTitle} onChange={e => upd('metaTitle', e.target.value)} helper="Recommended: 50–60 characters" />
              <Input label="Meta Description" type="textarea" placeholder="Heavy-duty brass cable gland with IP68 sealing..." value={f.metaDescription} onChange={e => upd('metaDescription', e.target.value)} helper="Recommended: 150–160 characters" />
            </Card>
          </div>

          {/* RIGHT — sidebar */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Card padding={20}>
              <FormSectionTitle>Status</FormSectionTitle>
              <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 10, borderRadius: 8, background: f.featured ? 'rgba(232,93,38,0.08)' : 'transparent', cursor: 'pointer', marginBottom: 6 }}>
                <input type="checkbox" checked={!!f.featured} onChange={e => upd('featured', e.target.checked)} style={{ accentColor: '#e85d26' }} />
                <div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'white', fontWeight: 600 }}>Featured Product</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Show on homepage and top of category</div>
                </div>
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 10, borderRadius: 8, cursor: 'pointer' }}>
                <input type="checkbox" checked={f.badge === 'New'} onChange={e => upd('badge', e.target.checked ? 'New' : null)} style={{ accentColor: '#e85d26' }} />
                <div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 13, color: 'white', fontWeight: 600 }}>Mark as New</div>
                  <div style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 11, color: 'rgba(255,255,255,0.4)', marginTop: 2 }}>Show "New" badge on cards</div>
                </div>
              </label>
            </Card>

            <Card padding={20}>
              <FormSectionTitle>Category & Industry</FormSectionTitle>
              <div style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 6 }}>Category <span style={{ color: '#e85d26' }}>*</span></label>
                <select value={f.category} onChange={e => upd('category', e.target.value)} style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '9px 12px', color: 'white', fontFamily: 'DM Sans, sans-serif', fontSize: 13, outline: 'none', cursor: 'pointer' }}>
                  {window.OctaData.categories.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontFamily: 'DM Sans, sans-serif', fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.5)', marginBottom: 8 }}>Industries</label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {window.OctaData.industries.filter(i => i.id !== 'all').map(ind => (
                    <label key={ind.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', borderRadius: 6, cursor: 'pointer' }}>
                      <input type="checkbox" checked={(f.industry || []).includes(ind.id)} onChange={() => toggle('industry', ind.id)} style={{ accentColor: '#e85d26' }} />
                      <span style={{ fontFamily: 'DM Sans, sans-serif', fontSize: 12, color: 'rgba(255,255,255,0.65)' }}>{ind.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </Card>

            <Card padding={20}>
              <FormSectionTitle>Certifications</FormSectionTitle>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {window.OctaData.certifications.map(c => (
                  <button key={c} onClick={() => toggle('certs', c)} style={{
                    padding: '6px 12px', borderRadius: 6,
                    background: (f.certs || []).includes(c) ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.04)',
                    border: (f.certs || []).includes(c) ? '1px solid rgba(232,93,38,0.4)' : '1px solid rgba(255,255,255,0.1)',
                    color: (f.certs || []).includes(c) ? '#e85d26' : 'rgba(255,255,255,0.5)',
                    fontFamily: 'DM Sans, sans-serif', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  }}>{c}</button>
                ))}
              </div>
            </Card>

            <Card padding={20}>
              <FormSectionTitle>Solutions</FormSectionTitle>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                {window.OctaData.solutions.map(s => (
                  <button key={s} onClick={() => toggle('solutions', s)} style={{
                    padding: '5px 10px', borderRadius: 14, fontSize: 11,
                    background: (f.solutions || []).includes(s) ? 'rgba(232,93,38,0.12)' : 'rgba(255,255,255,0.04)',
                    border: (f.solutions || []).includes(s) ? '1px solid rgba(232,93,38,0.3)' : '1px solid rgba(255,255,255,0.08)',
                    color: (f.solutions || []).includes(s) ? '#e85d26' : 'rgba(255,255,255,0.55)',
                    fontFamily: 'DM Sans, sans-serif', cursor: 'pointer',
                  }}>{s}</button>
                ))}
              </div>
            </Card>

            <Card padding={20}>
              <FormSectionTitle>Applications</FormSectionTitle>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                {window.OctaData.applications.map(a => (
                  <button key={a} onClick={() => toggle('applications', a)} style={{
                    padding: '5px 10px', borderRadius: 14, fontSize: 11,
                    background: (f.applications || []).includes(a) ? 'rgba(232,93,38,0.12)' : 'rgba(255,255,255,0.04)',
                    border: (f.applications || []).includes(a) ? '1px solid rgba(232,93,38,0.3)' : '1px solid rgba(255,255,255,0.08)',
                    color: (f.applications || []).includes(a) ? '#e85d26' : 'rgba(255,255,255,0.55)',
                    fontFamily: 'DM Sans, sans-serif', cursor: 'pointer',
                  }}>{a}</button>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}

function FormSectionTitle({ children }) {
  return <div style={{ fontFamily: 'Space Grotesk, sans-serif', fontSize: 14, fontWeight: 700, color: 'white', marginBottom: 14, paddingBottom: 10, borderBottom: '1px solid rgba(255,255,255,0.05)' }}>{children}</div>;
}

Object.assign(window, { ProductsPage });
