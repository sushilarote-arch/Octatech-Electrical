// about.jsx + contact.jsx combined
const { useState, useEffect, useRef } = React;

/* ── ABOUT PAGE ── */
function AboutPage({ navigate, openEnquiry }) {
  const [scrollY, setScrollY] = useState(0);
  useEffect(() => {
    window.scrollTo(0, 0);
    const fn = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  const values = [
    { icon: '🏆', title: 'Quality First', desc: 'Every product carries international certifications — UL, CE, ATEX, RoHS, TÜV, VDE, CSA — ensuring adherence to global standards.' },
    { icon: '🌐', title: 'Wide Spectrum', desc: '150+ products across 12 categories covering automotive, industrial, railway and infrastructure sectors.' },
    { icon: '🤝', title: 'Client Partnership', desc: 'From enquiry to delivery, our team provides technical guidance and responsive support for every application.' },
    { icon: '⚡', title: 'Fast Growing', desc: 'One of India\'s fastest growing industrial electrical distributors, with a rapidly expanding product portfolio.' },
  ];

  const timeline = [
    { year: '2001', event: 'Founded in Nashik, Maharashtra' },
    { year: '2008', event: 'First international certifications — UL & CE' },
    { year: '2014', event: 'Expanded to 100+ product lines' },
    { year: '2019', event: 'Digital catalogue launched' },
    { year: '2024', event: 'ATEX & TÜV certified product range added' },
    { year: '2026', event: 'Platform redesign — serving pan-India' },
  ];

  return (
    <div style={{ background: '#08111f', minHeight: '100vh', paddingTop: 64 }}>
      {/* Hero */}
      <div style={{ position: 'relative', background: '#0d1929', padding: '72px 48px', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(rgba(232,93,38,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(232,93,38,0.03) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
          transform: `translateY(${scrollY * 0.2}px)`,
        }} />
        <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: '40%', background: 'linear-gradient(90deg, transparent, rgba(232,93,38,0.04))' }} />
        <div style={{ maxWidth: 1200, margin: '0 auto', position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: 600 }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 14, fontWeight: 600, animation: 'fadeDown 0.5s ease both' }}>ABOUT US</div>
            <h1 style={{ fontFamily: 'Space Grotesk', fontSize: 44, fontWeight: 800, color: 'white', lineHeight: 1.1, margin: '0 0 20px', animation: 'fadeDown 0.5s ease 0.1s both' }}>
              India's Leading<br />Industrial Electrical<br />Distributor
            </h1>
            <p style={{ fontFamily: 'DM Sans', fontSize: 16, color: 'rgba(255,255,255,0.5)', lineHeight: 1.75, margin: '0 0 32px', animation: 'fadeDown 0.5s ease 0.2s both' }}>
              Octa Tech Electricals is one of the fastest-growing distributors of industrial electrical components in India. We carry a wide range of internationally certified products to serve automotive, industrial, railway, and infrastructure clients.
            </p>
            <div style={{ display: 'flex', gap: 10, animation: 'fadeDown 0.5s ease 0.3s both' }}>
              <button onClick={() => navigate('catalog')} style={{ padding: '12px 24px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 10, cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 14, fontWeight: 700, color: 'white' }}>Browse Products →</button>
              <button onClick={() => navigate('contact')} style={{ padding: '12px 24px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.7)' }}>Contact Us</button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div style={{ background: '#0a1525', borderTop: '1px solid rgba(255,255,255,0.04)', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)' }}>
          {[['150+', 'Products'], ['12', 'Categories'], ['7', 'Certifications'], ['25+', 'Years Experience']].map(([n, l], i) => (
            <div key={l} style={{ padding: '32px 20px', textAlign: 'center', borderRight: i < 3 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
              <div style={{ fontFamily: 'Space Grotesk', fontSize: 40, fontWeight: 800, color: '#e85d26' }}>{n}</div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Values */}
      <div style={{ padding: '80px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 12, fontWeight: 600 }}>OUR PRINCIPLES</div>
            <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: 0 }}>Why Choose Octa Tech</h2>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 20 }}>
            {values.map((v, i) => (
              <div key={v.title} style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 16, padding: '28px 24px', transition: 'all 0.3s' }}
                onMouseOver={e => { e.currentTarget.style.borderColor = 'rgba(232,93,38,0.25)'; e.currentTarget.style.transform = 'translateY(-4px)'; }}
                onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'; e.currentTarget.style.transform = 'none'; }}>
                <div style={{ fontSize: 32, marginBottom: 16 }}>{v.icon}</div>
                <div style={{ fontFamily: 'Space Grotesk', fontSize: 17, fontWeight: 700, color: 'white', marginBottom: 10 }}>{v.title}</div>
                <div style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.45)', lineHeight: 1.65 }}>{v.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Certifications */}
      <div style={{ background: '#0a1525', padding: '80px 48px', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
            <div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 14, fontWeight: 600 }}>QUALITY ASSURED</div>
              <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: '0 0 16px' }}>International Certifications</h2>
              <p style={{ fontFamily: 'DM Sans', fontSize: 15, color: 'rgba(255,255,255,0.45)', lineHeight: 1.75, margin: '0 0 28px' }}>All products carry the necessary international approvals and certifications, ensuring our quality level is aligned with global standards to serve our wide customer base.</p>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {window.OctaData.certifications.map(c => (
                  <div key={c} style={{ border: '1.5px solid rgba(255,255,255,0.15)', borderRadius: 8, padding: '8px 16px', fontFamily: 'Space Grotesk', fontSize: 16, fontWeight: 800, color: 'white', transition: 'all 0.2s' }}
                    onMouseOver={e => { e.currentTarget.style.borderColor = '#e85d26'; e.currentTarget.style.color = '#e85d26'; }}
                    onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'; e.currentTarget.style.color = 'white'; }}>{c}</div>
                ))}
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
              {window.OctaData.certifications.map((c, i) => (
                <div key={c} style={{ aspectRatio: '1', background: '#0d1929', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, transition: 'all 0.25s' }}
                  onMouseOver={e => { e.currentTarget.style.borderColor = 'rgba(232,93,38,0.35)'; e.currentTarget.style.background = '#142240'; }}
                  onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.07)'; e.currentTarget.style.background = '#0d1929'; }}>
                  <div style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 800, color: 'white' }}>{c}</div>
                  <div style={{ width: 24, height: 2, background: '#e85d26', borderRadius: 1 }} />
                  <div style={{ fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>Certified</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div style={{ padding: '80px 48px' }}>
        <div style={{ maxWidth: 800, margin: '0 auto' }}>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 12, fontWeight: 600 }}>OUR JOURNEY</div>
            <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: 0 }}>25+ Years of Growth</h2>
          </div>
          <div style={{ position: 'relative' }}>
            <div style={{ position: 'absolute', left: '50%', top: 0, bottom: 0, width: 1, background: 'rgba(255,255,255,0.06)', transform: 'translateX(-50%)' }} />
            {timeline.map((t, i) => (
              <div key={t.year} style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 32, flexDirection: i % 2 === 0 ? 'row' : 'row-reverse' }}>
                <div style={{ flex: 1, textAlign: i % 2 === 0 ? 'right' : 'left' }}>
                  <div style={{ fontFamily: 'Space Grotesk', fontSize: 13, fontWeight: 700, color: '#e85d26', marginBottom: 4 }}>{t.year}</div>
                  <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.6)', lineHeight: 1.5 }}>{t.event}</div>
                </div>
                <div style={{ width: 12, height: 12, borderRadius: '50%', background: '#e85d26', border: '3px solid #08111f', boxShadow: '0 0 0 2px #e85d26', flexShrink: 0, zIndex: 1 }} />
                <div style={{ flex: 1 }} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ background: 'linear-gradient(135deg, #e85d26, #c04a1a)', padding: '60px 48px', textAlign: 'center' }}>
        <div style={{ maxWidth: 600, margin: '0 auto' }}>
          <h2 style={{ fontFamily: 'Space Grotesk', fontSize: 32, fontWeight: 800, color: 'white', margin: '0 0 12px' }}>Ready to work with us?</h2>
          <p style={{ fontFamily: 'DM Sans', fontSize: 15, color: 'rgba(255,255,255,0.75)', margin: '0 0 28px' }}>Let us help you find the right electrical components for your application.</p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button onClick={() => navigate('contact')} style={{ padding: '13px 28px', background: 'white', border: 'none', borderRadius: 10, cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: '#e85d26' }}>Contact Us</button>
            <button onClick={() => navigate('catalog')} style={{ padding: '13px 28px', background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 10, cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 600, color: 'white' }}>Browse Products</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── CONTACT PAGE ── */
function ContactPage({ openEnquiry }) {
  const [sent, setSent] = useState(false);
  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <div style={{ background: '#08111f', minHeight: '100vh', paddingTop: 64 }}>
      {/* Header */}
      <div style={{ background: '#0d1929', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '48px 48px 40px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', letterSpacing: 3, marginBottom: 12, fontWeight: 600 }}>GET IN TOUCH</div>
          <h1 style={{ fontFamily: 'Space Grotesk', fontSize: 44, fontWeight: 800, color: 'white', margin: '0 0 12px' }}>Contact Us</h1>
          <p style={{ fontFamily: 'DM Sans', fontSize: 16, color: 'rgba(255,255,255,0.45)', margin: 0 }}>Our team is ready to help with product enquiries, technical questions, and orders.</p>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '48px 48px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48 }}>
        {/* Form */}
        <div>
          <div style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 700, color: 'white', marginBottom: 24 }}>Send an Enquiry</div>
          {sent ? (
            <div style={{ background: 'rgba(22,163,74,0.08)', border: '1px solid rgba(22,163,74,0.25)', borderRadius: 14, padding: '40px', textAlign: 'center' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
              <div style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 700, color: 'white', marginBottom: 8 }}>Message Sent!</div>
              <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.5)' }}>We'll get back to you within 24 hours.</div>
            </div>
          ) : (
            <div style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, padding: '32px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                {[['Full Name', 'Your name', 'text'], ['Company', 'Company name', 'text'], ['Email', 'you@company.com', 'email'], ['Phone', '+91 XXXXX XXXXX', 'tel']].map(([label, ph, type]) => (
                  <div key={label}>
                    <label style={{ display: 'block', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.4)', marginBottom: 6, letterSpacing: 0.5 }}>{label} <span style={{ color: '#e85d26' }}>*</span></label>
                    <input type={type} placeholder={ph} style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '10px 14px', color: 'white', fontFamily: 'DM Sans', fontSize: 14, outline: 'none', boxSizing: 'border-box', transition: 'border-color 0.2s' }}
                      onFocus={e => e.target.style.borderColor = 'rgba(232,93,38,0.5)'}
                      onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.09)'} />
                  </div>
                ))}
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.4)', marginBottom: 6 }}>Product Category</label>
                <select style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '10px 14px', color: 'rgba(255,255,255,0.7)', fontFamily: 'DM Sans', fontSize: 14, outline: 'none', boxSizing: 'border-box' }}>
                  <option value="">Select category...</option>
                  {window.OctaData.categories.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
                </select>
              </div>
              <div style={{ marginBottom: 18 }}>
                <label style={{ display: 'block', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'rgba(255,255,255,0.4)', marginBottom: 6 }}>Message <span style={{ color: '#e85d26' }}>*</span></label>
                <textarea rows={5} placeholder="Describe your requirements, quantities, application details..." style={{ width: '100%', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.09)', borderRadius: 8, padding: '10px 14px', color: 'white', fontFamily: 'DM Sans', fontSize: 14, outline: 'none', resize: 'vertical', boxSizing: 'border-box', transition: 'border-color 0.2s' }}
                  onFocus={e => e.target.style.borderColor = 'rgba(232,93,38,0.5)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.09)'} />
              </div>
              <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer', marginBottom: 18 }}>
                <input type="checkbox" style={{ marginTop: 3 }} />
                <span style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.35)', lineHeight: 1.5 }}>I accept the <span style={{ color: '#e85d26' }}>Terms & Conditions</span> and consent to being contacted.</span>
              </label>
              <button onClick={() => setSent(true)} style={{ width: '100%', padding: '14px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 10, cursor: 'pointer', fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white', boxShadow: '0 4px 20px rgba(232,93,38,0.3)', transition: 'all 0.2s' }}
                onMouseOver={e => { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.boxShadow = '0 8px 30px rgba(232,93,38,0.4)'; }}
                onMouseOut={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 4px 20px rgba(232,93,38,0.3)'; }}>
                Send Enquiry →
              </button>
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <div style={{ fontFamily: 'Space Grotesk', fontSize: 22, fontWeight: 700, color: 'white', marginBottom: 24 }}>Our Details</div>
          {[
            { icon: '📍', label: 'Address', val: '401, Shreeji Vrunda Apt, Indira Nagar, Nashik — 422009, Maharashtra, India' },
            { icon: '✉️', label: 'Email', val: 'info@octatechelectricals.com' },
            { icon: '📞', label: 'Phone', val: '+91 70667 11811' },
            { icon: '🕐', label: 'Working Hours', val: 'Mon–Sat, 9:00 AM – 6:00 PM IST' },
          ].map(item => (
            <div key={item.label} style={{ display: 'flex', gap: 16, padding: '18px 20px', background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 12, marginBottom: 10, transition: 'border-color 0.2s' }}
              onMouseOver={e => e.currentTarget.style.borderColor = 'rgba(232,93,38,0.2)'}
              onMouseOut={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'}>
              <div style={{ width: 40, height: 40, background: 'rgba(232,93,38,0.1)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>{item.icon}</div>
              <div>
                <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', marginBottom: 4, letterSpacing: 0.5 }}>{item.label.toUpperCase()}</div>
                <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.75)', lineHeight: 1.5 }}>{item.val}</div>
              </div>
            </div>
          ))}

          {/* Map placeholder */}
          <div style={{ marginTop: 24, height: 220, background: '#0d1929', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 16, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <div style={{ fontSize: 36 }}>📍</div>
            <div style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.35)' }}>Nashik, Maharashtra, India</div>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.2)' }}>[ Map embed ]</div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AboutPage, ContactPage });
