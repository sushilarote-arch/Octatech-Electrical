// catalog.jsx — Product catalog with sidebar filters, search, compare
const { useState, useEffect, useMemo } = React;

function CatalogPage({ navigate, openEnquiry, compareList, onCompare, openCompare, initIndustry, initCategory }) {
  const [selectedIndustry, setSelectedIndustry] = useState(initIndustry || 'all');
  const [selectedCategory, setSelectedCategory] = useState(initCategory || null);
  const [selectedSolutions, setSelectedSolutions] = useState([]);
  const [selectedApps, setSelectedApps] = useState([]);
  const [query, setQuery] = useState('');
  const [view, setView] = useState('normal'); // 'normal' | 'technical'
  const [filterOpen, setFilterOpen] = useState(false); // mobile

  const allProducts = window.OctaData.products;
  const industries = window.OctaData.industries;
  const categories = window.OctaData.categories;

  const filtered = useMemo(() => {
    return allProducts.filter(p => {
      if (selectedIndustry !== 'all' && !p.industry.includes(selectedIndustry)) return false;
      if (selectedCategory && p.category !== selectedCategory) return false;
      if (selectedSolutions.length > 0 && !selectedSolutions.every(s => p.solutions.includes(s))) return false;
      if (selectedApps.length > 0 && !selectedApps.every(a => p.applications.includes(a))) return false;
      if (query && !p.name.toLowerCase().includes(query.toLowerCase()) && !p.tagline.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [selectedIndustry, selectedCategory, selectedSolutions, selectedApps, query]);

  const toggleSolution = (s) => setSelectedSolutions(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  const toggleApp = (a) => setSelectedApps(prev => prev.includes(a) ? prev.filter(x => x !== a) : [...prev, a]);
  const clearAll = () => { setSelectedIndustry('all'); setSelectedCategory(null); setSelectedSolutions([]); setSelectedApps([]); setQuery(''); };

  const activeFilters = [
    selectedIndustry !== 'all' && industries.find(i => i.id === selectedIndustry)?.label,
    selectedCategory && categories.find(c => c.id === selectedCategory)?.label,
    ...selectedSolutions, ...selectedApps,
  ].filter(Boolean);

  return (
    <div style={{ background: '#08111f', minHeight: '100vh', paddingTop: 64 }}>
      {/* Page header */}
      <div style={{ background: 'linear-gradient(180deg, #0d1929 0%, #08111f 100%)', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '40px 48px 32px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.35)', marginBottom: 8, letterSpacing: 1 }}>
            <span style={{ cursor: 'pointer', transition: 'color 0.2s' }} onClick={() => navigate('home')}>Home</span>
            <span style={{ margin: '0 8px' }}>›</span>
            <span style={{ color: 'rgba(255,255,255,0.7)' }}>Products</span>
          </div>
          <h1 style={{ fontFamily: 'Space Grotesk', fontSize: 36, fontWeight: 800, color: 'white', margin: '0 0 16px' }}>Product Catalog</h1>
          {/* Search bar */}
          <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, padding: '0 16px', height: 48, maxWidth: 520, gap: 10, transition: 'border-color 0.2s' }}
            onFocusCapture={e => e.currentTarget.style.borderColor = 'rgba(232,93,38,0.5)'}
            onBlurCapture={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'}>
            <span style={{ fontSize: 16, opacity: 0.4 }}>🔍</span>
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by product name or application..."
              style={{ background: 'none', border: 'none', outline: 'none', flex: 1, color: 'white', fontFamily: 'DM Sans', fontSize: 14 }} />
            {query && <button onClick={() => setQuery('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.4)', fontSize: 16 }}>×</button>}
          </div>
          {/* Industry tabs */}
          <div style={{ display: 'flex', gap: 0, marginTop: 24, borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
            {industries.map(ind => (
              <button key={ind.id} onClick={() => { setSelectedIndustry(ind.id); setSelectedCategory(null); }} style={{
                background: 'none', border: 'none', cursor: 'pointer', padding: '10px 18px',
                fontFamily: 'DM Sans', fontSize: 14, fontWeight: 500,
                color: selectedIndustry === ind.id ? 'white' : 'rgba(255,255,255,0.4)',
                borderBottom: selectedIndustry === ind.id ? '2px solid #e85d26' : '2px solid transparent',
                marginBottom: -1, transition: 'all 0.2s', whiteSpace: 'nowrap',
              }}>{ind.label} <span style={{ opacity: 0.5, fontSize: 12 }}>({ind.count})</span></button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1260, margin: '0 auto', padding: '24px 48px', display: 'flex', gap: 24 }}>
        {/* ── SIDEBAR ── */}
        <div style={{ width: 220, flexShrink: 0 }}>
          <div style={{ position: 'sticky', top: 80 }}>
            {/* Categories */}
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5, marginBottom: 12 }}>CATEGORIES</div>
              {categories
                .filter(c => selectedIndustry === 'all' || c.industry.includes(selectedIndustry))
                .map(cat => (
                <button key={cat.id} onClick={() => setSelectedCategory(selectedCategory === cat.id ? null : cat.id)} style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%',
                  padding: '8px 10px', borderRadius: 8, background: selectedCategory === cat.id ? 'rgba(232,93,38,0.12)' : 'transparent',
                  border: selectedCategory === cat.id ? '1px solid rgba(232,93,38,0.25)' : '1px solid transparent',
                  cursor: 'pointer', marginBottom: 2, transition: 'all 0.2s', textAlign: 'left',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 14 }}>{cat.icon}</span>
                    <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: selectedCategory === cat.id ? '#e85d26' : 'rgba(255,255,255,0.65)' }}>{cat.label}</span>
                  </div>
                  <span style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.25)' }}>{cat.count}</span>
                </button>
              ))}
            </div>

            {/* Solutions filter */}
            <FilterGroup title="Solutions" items={window.OctaData.solutions} selected={selectedSolutions} toggle={toggleSolution} />
            <FilterGroup title="Applications" items={window.OctaData.applications} selected={selectedApps} toggle={toggleApp} />

            {activeFilters.length > 0 && (
              <button onClick={clearAll} style={{ width: '100%', padding: '8px', background: 'rgba(232,93,38,0.08)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 8, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 13, color: '#e85d26', marginTop: 8 }}>
                Clear all filters
              </button>
            )}
          </div>
        </div>

        {/* ── MAIN GRID ── */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Toolbar */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <span style={{ fontFamily: 'DM Sans', fontSize: 14, color: 'rgba(255,255,255,0.5)' }}>
                Showing <span style={{ color: 'white', fontWeight: 600 }}>{filtered.length}</span> products
              </span>
              {activeFilters.map(f => (
                <span key={f} style={{ background: 'rgba(232,93,38,0.12)', border: '1px solid rgba(232,93,38,0.2)', borderRadius: 20, padding: '2px 10px', fontFamily: 'DM Sans', fontSize: 12, color: '#e85d26', display: 'flex', alignItems: 'center', gap: 5 }}>
                  {f} <span style={{ cursor: 'pointer', opacity: 0.7 }} onClick={() => {
                    if (industries.find(i => i.label === f)) setSelectedIndustry('all');
                    else if (categories.find(c => c.label === f)) setSelectedCategory(null);
                    else if (window.OctaData.solutions.includes(f)) toggleSolution(f);
                    else toggleApp(f);
                  }}>×</span>
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              {['normal', 'technical'].map(v => (
                <button key={v} onClick={() => setView(v)} style={{
                  padding: '6px 14px', borderRadius: 6, border: '1px solid', cursor: 'pointer',
                  borderColor: view === v ? 'rgba(232,93,38,0.4)' : 'rgba(255,255,255,0.1)',
                  background: view === v ? 'rgba(232,93,38,0.1)' : 'transparent',
                  fontFamily: 'DM Sans', fontSize: 12, color: view === v ? '#e85d26' : 'rgba(255,255,255,0.5)',
                  transition: 'all 0.2s',
                }}>{v === 'normal' ? '⊞ Normal' : '⊟ Technical'}</button>
              ))}
            </div>
          </div>

          {/* Grid */}
          {filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '60px 0', color: 'rgba(255,255,255,0.3)', fontFamily: 'DM Sans', fontSize: 15 }}>
              No products match your filters. <button onClick={clearAll} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#e85d26', fontFamily: 'DM Sans', fontSize: 15, textDecoration: 'underline' }}>Clear filters</button>
            </div>
          ) : view === 'normal' ? (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 14 }}>
              {filtered.map(p => (
                <ProductCard key={p.id} product={p} onCompare={onCompare} compareList={compareList} navigate={navigate} openEnquiry={openEnquiry} />
              ))}
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {filtered.map(p => <TechnicalRow key={p.id} product={p} navigate={navigate} openEnquiry={openEnquiry} onCompare={onCompare} compareList={compareList} />)}
            </div>
          )}

          {/* Compare floating bar */}
          {compareList.length > 0 && (
            <div style={{
              position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
              background: '#0d1929', border: '1px solid rgba(232,93,38,0.3)', borderRadius: 14,
              padding: '12px 20px', display: 'flex', alignItems: 'center', gap: 16,
              boxShadow: '0 8px 40px rgba(0,0,0,0.5)', zIndex: 500,
              animation: 'slideUp 0.2s ease',
            }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                {[0,1,2,3,4,5].map(i => (
                  <div key={i} style={{ width: 36, height: 36, borderRadius: 8, background: compareList[i] ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.04)', border: `1px solid ${compareList[i] ? 'rgba(232,93,38,0.4)' : 'rgba(255,255,255,0.08)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: 'rgba(255,255,255,0.3)' }}>
                    {compareList[i] ? <span style={{ fontSize: 16 }}>{window.OctaData.categories.find(c => c.id === compareList[i].category)?.icon}</span> : '+'}
                  </div>
                ))}
              </div>
              <span style={{ fontFamily: 'DM Sans', fontSize: 13, color: 'rgba(255,255,255,0.6)' }}>{compareList.length}/6 selected</span>
              <button onClick={openCompare} style={{ background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 8, padding: '8px 18px', cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 13, fontWeight: 600, color: 'white' }}>Compare →</button>
              <button onClick={() => compareList.forEach((_, i) => onCompare(compareList[i]))} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.35)', fontSize: 18 }}>×</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ title, items, selected, toggle }) {
  const [open, setOpen] = useState(true);
  return (
    <div style={{ marginBottom: 20 }}>
      <button onClick={() => setOpen(!open)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '0 0 10px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <span style={{ fontFamily: 'DM Sans', fontSize: 11, color: 'rgba(255,255,255,0.35)', letterSpacing: 1.5 }}>{title.toUpperCase()}</span>
        <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 12, transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>▾</span>
      </button>
      {open && (
        <div style={{ marginTop: 8 }}>
          {items.map(item => (
            <label key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0', cursor: 'pointer' }}>
              <div onClick={() => toggle(item)} style={{
                width: 16, height: 16, borderRadius: 4, border: '1.5px solid',
                borderColor: selected.includes(item) ? '#e85d26' : 'rgba(255,255,255,0.2)',
                background: selected.includes(item) ? '#e85d26' : 'transparent',
                flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.15s',
              }}>
                {selected.includes(item) && <span style={{ color: 'white', fontSize: 10 }}>✓</span>}
              </div>
              <span onClick={() => toggle(item)} style={{ fontFamily: 'DM Sans', fontSize: 12, color: selected.includes(item) ? '#e85d26' : 'rgba(255,255,255,0.5)', lineHeight: 1.3, transition: 'color 0.15s' }}>{item}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

function TechnicalRow({ product, navigate, openEnquiry, onCompare, compareList }) {
  const inCompare = compareList.some(p => p.id === product.id);
  return (
    <div style={{ background: '#0d1929', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 10, padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 20, transition: 'all 0.2s' }}
      onMouseOver={e => { e.currentTarget.style.borderColor = 'rgba(232,93,38,0.2)'; e.currentTarget.style.background = '#142240'; }}
      onMouseOut={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'; e.currentTarget.style.background = '#0d1929'; }}>
      <div style={{ width: 52, height: 52, background: '#1a2f50', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, flexShrink: 0 }}>
        {window.OctaData.categories.find(c => c.id === product.category)?.icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'Space Grotesk', fontSize: 15, fontWeight: 700, color: 'white', marginBottom: 2 }}>{product.name}</div>
        <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{product.tagline}</div>
      </div>
      <div style={{ display: 'flex', gap: 24, flexShrink: 0 }}>
        {[['Temp', product.temperature], ['IP', product.ipRating]].map(([k, v]) => (
          <div key={k} style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.3)', marginBottom: 2 }}>{k}</div>
            <div style={{ fontFamily: 'DM Sans', fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
        {product.certs.slice(0, 3).map(c => <span key={c} style={{ border: '1px solid rgba(255,255,255,0.1)', borderRadius: 4, padding: '1px 6px', fontFamily: 'DM Sans', fontSize: 10, color: 'rgba(255,255,255,0.4)' }}>{c}</span>)}
      </div>
      <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
        <button onClick={() => onCompare(product)} style={{ padding: '6px 10px', background: inCompare ? 'rgba(232,93,38,0.15)' : 'rgba(255,255,255,0.05)', border: `1px solid ${inCompare ? 'rgba(232,93,38,0.4)' : 'rgba(255,255,255,0.1)'}`, borderRadius: 6, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, color: inCompare ? '#e85d26' : 'rgba(255,255,255,0.5)' }}>Compare</button>
        <button onClick={() => navigate('product', product)} style={{ padding: '6px 14px', background: 'linear-gradient(135deg, #e85d26, #ff7a45)', border: 'none', borderRadius: 6, cursor: 'pointer', fontFamily: 'DM Sans', fontSize: 12, fontWeight: 600, color: 'white' }}>Details →</button>
      </div>
    </div>
  );
}

Object.assign(window, { CatalogPage });
